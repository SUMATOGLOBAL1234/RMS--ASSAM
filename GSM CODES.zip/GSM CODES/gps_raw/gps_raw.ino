#include <TinyGPS++.h>

HardwareSerial GPS(2);

void setup() {
  Serial.begin(115200);
  GPS.begin(9600, SERIAL_8N1, 16, 17);
}

void loop() {
  while (GPS.available()) {
    String line = GPS.readStringUntil('\n');
    line.trim();

    if (line.length())
      Serial.println(line);
  }
}