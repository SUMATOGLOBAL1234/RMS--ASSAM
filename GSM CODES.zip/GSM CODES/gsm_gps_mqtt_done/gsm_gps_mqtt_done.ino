#include <SoftwareSerial.h>
#include <string.h>
#include <stdlib.h>

// =====================================================
// A7672S <-> ARDUINO UNO
// =====================================================
//
// A7672S TX -> Arduino D2
// A7672S RX -> Arduino D3
// GND       -> Arduino GND
//
// =====================================================

#define GSM_RX 2
#define GSM_TX 3

SoftwareSerial gsm(GSM_RX, GSM_TX);


// =====================================================
// SETTINGS
// =====================================================

const char APN[] = "JioNet"; //"airtelgprs.com";

const char MQTT_SERVER[] = "mqtt.sumato.tech";
const int MQTT_PORT = 1883;

const char MQTT_USERNAME[] = "user1";
const char MQTT_PASSWORD[] = "secret";

const char MQTT_CLIENT_ID[] = "RMS001";

const char MQTT_TOPIC[] = "test/device";


// =====================================================
// GPS VARIABLES
// =====================================================

double gpsLatitude = 0.0;
double gpsLongitude = 0.0;
double gpsAltitude = 0.0;
double gpsSpeed = 0.0;
double gpsCourse = 0.0;

int gpsSatellites = 0;

char gpsDate[12] = "";
char gpsTime[16] = "";

bool gpsFix = false;


// =====================================================
// CLEAR MODEM BUFFER
// =====================================================

void clearModem()
{
  while (gsm.available())
  {
    gsm.read();
  }
}


// =====================================================
// SEND AT COMMAND
// =====================================================

bool sendAT(
  const char *cmd,
  const char *expected,
  unsigned long timeout)
{
  clearModem();

  Serial.print(F(">> "));
  Serial.println(cmd);

  gsm.println(cmd);

  unsigned long start = millis();

  char buffer[100];

  byte pos = 0;

  buffer[0] = '\0';

  while (millis() - start < timeout)
  {
    while (gsm.available())
    {
      char c = gsm.read();

      Serial.write(c);

      if (pos < sizeof(buffer) - 1)
      {
        buffer[pos++] = c;
        buffer[pos] = '\0';
      }

      if (strstr(buffer, expected))
      {
        return true;
      }

      if (strstr(buffer, "ERROR"))
      {
        return false;
      }
    }
  }

  Serial.println(F("TIMEOUT"));

  return false;
}


// =====================================================
// MODEM CHECK
// =====================================================

bool modemOK()
{
  return sendAT(
    "AT",
    "OK",
    3000
  );
}


// =====================================================
// SIM CHECK
// =====================================================

bool simOK()
{
  return sendAT(
    "AT+CPIN?",
    "READY",
    5000
  );
}


// =====================================================
// NETWORK CHECK
// =====================================================

bool networkOK()
{
  clearModem();

  Serial.println(F(">> AT+CEREG?"));

  gsm.println(F("AT+CEREG?"));

  unsigned long start = millis();

  char buffer[80];

  byte pos = 0;

  buffer[0] = '\0';

  while (millis() - start < 5000)
  {
    while (gsm.available())
    {
      char c = gsm.read();

      Serial.write(c);

      if (pos < sizeof(buffer) - 1)
      {
        buffer[pos++] = c;
        buffer[pos] = '\0';
      }

      if (strstr(buffer, ",1") ||
          strstr(buffer, ",5"))
      {
        return true;
      }
    }
  }

  return false;
}


// =====================================================
// INTERNET
// =====================================================

bool internetOK()
{
  char cmd[70];

  Serial.println();
  Serial.println(F("Connecting Internet..."));


  // ---------------------------------------------------
  // APN
  // ---------------------------------------------------

  sprintf(
    cmd,
    "AT+CGDCONT=1,\"IP\",\"%s\"",
    APN
  );

  if (!sendAT(
        cmd,
        "OK",
        5000))
  {
    return false;
  }


  // ---------------------------------------------------
  // PACKET ATTACH
  // ---------------------------------------------------

  if (!sendAT(
        "AT+CGATT=1",
        "OK",
        15000))
  {
    return false;
  }


  // ---------------------------------------------------
  // PDP ACTIVATION
  // ---------------------------------------------------

  if (!sendAT(
        "AT+CGACT=1,1",
        "OK",
        15000))
  {
    return false;
  }


  // ---------------------------------------------------
  // GET IP
  // ---------------------------------------------------

  if (!sendAT(
        "AT+CGPADDR=1",
        "+CGPADDR:",
        5000))
  {
    return false;
  }


  Serial.println();
  Serial.println(F("INTERNET OK"));

  return true;
}


// =====================================================
// GNSS START
// =====================================================

// =====================================================
// GNSS START
// =====================================================

bool gnssStart()
{
  Serial.println();
  Serial.println(F("======================================"));
  Serial.println(F("Starting GNSS..."));
  Serial.println(F("======================================"));

  clearModem();

  Serial.println(F(">> AT+CGNSSPWR=1"));

  gsm.println(F("AT+CGNSSPWR=1"));

  unsigned long start = millis();

  bool gotResponse = false;

  while (millis() - start < 5000)
  {
    while (gsm.available())
    {
      char c = gsm.read();

      Serial.write(c);

      gotResponse = true;
    }
  }

  if (!gotResponse)
  {
    Serial.println();
    Serial.println(F("No response from GNSS command."));
    return false;
  }

  Serial.println();
  Serial.println(F("GNSS POWER COMMAND SENT"));

  // Give GNSS engine time to initialize
  delay(3000);

  return true;
}


// =====================================================
// READ GNSS
// =====================================================
//
// A7672S response:
//
// +CGNSSINFO:
// mode,
// GPS-SVs,
// GLONASS-SVs,
// BEIDOU-SVs,
// latitude,
// N/S,
// longitude,
// E/W,
// date,
// UTC time,
// altitude,
// speed,
// course,
// PDOP,
// HDOP,
// VDOP
//
// =====================================================

// =====================================================
// READ GNSS
// =====================================================

bool readGNSS()
{
  gpsFix = false;

  Serial.println();
  Serial.println(F("======================================"));
  Serial.println(F("Checking GNSS..."));
  Serial.println(F("======================================"));

  clearModem();

  Serial.println(F(">> AT+CGNSSINFO"));

  gsm.println(F("AT+CGNSSINFO"));


  // ===================================================
  // RECEIVE RESPONSE
  // ===================================================

  char response[220];

  byte pos = 0;

  response[0] = '\0';

  unsigned long start = millis();

  while (millis() - start < 5000)
  {
    while (gsm.available())
    {
      char c = gsm.read();

      Serial.write(c);

      if (pos < sizeof(response) - 1)
      {
        response[pos++] = c;
        response[pos] = '\0';
      }

      // Reset timeout when data arrives
      start = millis();
    }
  }


  // ===================================================
  // FIND +CGNSSINFO:
  // ===================================================

  char *data =
    strstr(response, "+CGNSSINFO:");

  if (data == NULL)
  {
    Serial.println();
    Serial.println(F("No GNSS response."));

    return false;
  }


  // Move past "+CGNSSINFO:"
  data += 11;


  // ===================================================
  // FIELD ARRAY
  // ===================================================

  char field[17][20];

  byte fieldCount = 0;
  byte fieldPos = 0;


  for (byte i = 0; i < 17; i++)
  {
    field[i][0] = '\0';
  }


  // ===================================================
  // SPLIT CSV FIELDS
  // ===================================================

  while (*data &&
         fieldCount < 17)
  {
    char c = *data;


    // -------------------------------------------------
    // COMMA
    // -------------------------------------------------

    if (c == ',')
    {
      field[fieldCount][fieldPos] = '\0';

      fieldCount++;

      fieldPos = 0;

      data++;

      continue;
    }


    // -------------------------------------------------
    // CR / LF
    // -------------------------------------------------

    if (c == '\r' ||
        c == '\n')
    {
      field[fieldCount][fieldPos] = '\0';

      fieldCount++;

      break;
    }


    // -------------------------------------------------
    // STORE CHARACTER
    // -------------------------------------------------

    if (fieldPos < sizeof(field[0]) - 1)
    {
      field[fieldCount][fieldPos++] = c;
    }

    data++;
  }


  // ===================================================
  // DEBUG: DISPLAY PARSED FIELDS
  // ===================================================

  Serial.println();
  Serial.println(F("Parsed GNSS fields:"));

  for (byte i = 0; i < fieldCount; i++)
  {
    Serial.print(F("Field "));
    Serial.print(i);
    Serial.print(F(" = ["));
    Serial.print(field[i]);
    Serial.println(F("]"));
  }


  // ===================================================
  // CHECK MINIMUM FIELDS
  // ===================================================

  if (fieldCount < 14)
  {
    Serial.println();
    Serial.println(F("Incomplete GNSS data."));

    return false;
  }


  // ===================================================
  // FIX MODE
  // ===================================================

  int fixMode =
    atoi(field[0]);


  if (fixMode < 2)
  {
    Serial.println();
    Serial.println(F("NO GPS FIX"));
    Serial.println(F("Waiting for satellites..."));

    return false;
  }


  // ===================================================
  // SATELLITES
  // ===================================================

  gpsSatellites =
    atoi(field[1]);


  // ===================================================
  // LATITUDE
  // ===================================================

  gpsLatitude =
    atof(field[5]);


  // ===================================================
  // LATITUDE DIRECTION
  // ===================================================

  if (strcmp(field[6], "S") == 0)
  {
    gpsLatitude =
      -gpsLatitude;
  }


  // ===================================================
  // LONGITUDE
  // ===================================================

  gpsLongitude =
    atof(field[7]);


  // ===================================================
  // LONGITUDE DIRECTION
  // ===================================================

  if (strcmp(field[8], "W") == 0)
  {
    gpsLongitude =
      -gpsLongitude;
  }


  // ===================================================
  // DATE
  // ===================================================

  strncpy(
    gpsDate,
    field[9],
    sizeof(gpsDate) - 1
  );

  gpsDate[
    sizeof(gpsDate) - 1
  ] = '\0';


  // ===================================================
  // UTC TIME
  // ===================================================

  strncpy(
    gpsTime,
    field[10],
    sizeof(gpsTime) - 1
  );

  gpsTime[
    sizeof(gpsTime) - 1
  ] = '\0';


  // ===================================================
  // ALTITUDE
  // ===================================================

  gpsAltitude =
    atof(field[11]);


  // ===================================================
  // SPEED
  // ===================================================

  gpsSpeed =
    atof(field[12]);


  // ===================================================
  // COURSE
  // ===================================================

  gpsCourse =
    atof(field[13]);


  // ===================================================
  // GPS FIX VALID
  // ===================================================

  gpsFix = true;


  // ===================================================
  // DISPLAY
  // ===================================================

  Serial.println();
  Serial.println(F("******** GPS FIX ********"));

  Serial.print(F("Fix mode       : "));
  Serial.println(fixMode);

  Serial.print(F("GPS satellites : "));
  Serial.println(gpsSatellites);

  Serial.print(F("Latitude       : "));
  Serial.println(gpsLatitude, 7);

  Serial.print(F("Longitude      : "));
  Serial.println(gpsLongitude, 7);

  Serial.print(F("Date           : "));
  Serial.println(gpsDate);

  Serial.print(F("UTC time       : "));
  Serial.println(gpsTime);

  Serial.print(F("Altitude       : "));
  Serial.print(gpsAltitude, 2);
  Serial.println(F(" m"));

  Serial.print(F("Speed          : "));
  Serial.print(gpsSpeed, 2);
  Serial.println(F(" knots"));

  Serial.print(F("Speed          : "));
  Serial.print(
    gpsSpeed * 1.852,
    2
  );
  Serial.println(F(" km/h"));

  Serial.print(F("Course         : "));
  Serial.println(gpsCourse, 2);


  // ===================================================
  // GOOGLE MAPS
  // ===================================================

  Serial.println();
  Serial.println(F("Google Maps:"));

  Serial.print(
    F("https://maps.google.com/?q=")
  );

  Serial.print(
    gpsLatitude,
    7
  );

  Serial.print(',');

  Serial.println(
    gpsLongitude,
    7
  );

  Serial.println(
    F("*************************")
  );


  return true;
}

// =====================================================
// MQTT START
// =====================================================

bool mqttStart()
{
  Serial.println();
  Serial.println(F("Starting MQTT..."));

  clearModem();

  Serial.println(F(">> AT+CMQTTSTART"));

  gsm.println(F("AT+CMQTTSTART"));

  unsigned long start = millis();

  char buffer[100];

  byte pos = 0;

  buffer[0] = '\0';

  while (millis() - start < 15000)
  {
    while (gsm.available())
    {
      char c = gsm.read();

      Serial.write(c);

      if (pos < sizeof(buffer) - 1)
      {
        buffer[pos++] = c;
        buffer[pos] = '\0';
      }

      // -----------------------------------------------
      // MQTT SERVICE STARTED
      // -----------------------------------------------

      if (strstr(buffer, "+CMQTTSTART: 0"))
      {
        Serial.println();
        Serial.println(F("MQTT SERVICE STARTED"));
        break;
      }

      // -----------------------------------------------
      // MQTT ALREADY RUNNING
      // -----------------------------------------------

      if (strstr(buffer, "ERROR"))
      {
        Serial.println();
        Serial.println(F("MQTT SERVICE ALREADY RUNNING"));
        break;
      }
    }

    if (strstr(buffer, "+CMQTTSTART: 0") ||
        strstr(buffer, "ERROR"))
    {
      break;
    }
  }


  // ===================================================
  // ACQUIRE MQTT CLIENT
  // ===================================================

  char cmd[70];

  sprintf(
    cmd,
    "AT+CMQTTACCQ=0,\"%s\",0",
    MQTT_CLIENT_ID
  );

  Serial.println();
  Serial.println(F("Acquiring MQTT client..."));

  if (!sendAT(
        cmd,
        "OK",
        5000))
  {
    Serial.println(F("MQTT client already acquired or unavailable."));
    return false;
  }

  Serial.println(F("MQTT CLIENT READY"));

  return true;
}


// =====================================================
// MQTT CONNECT
// =====================================================

bool mqttConnect()
{
  char cmd[180];


  sprintf(
    cmd,
    "AT+CMQTTCONNECT=0,\"tcp://%s:%d\",60,1,\"%s\",\"%s\"",
    MQTT_SERVER,
    MQTT_PORT,
    MQTT_USERNAME,
    MQTT_PASSWORD
  );


  Serial.println();
  Serial.println(
    F("Connecting MQTT...")
  );


  if (!sendAT(
        cmd,
        "OK",
        30000))
  {
    Serial.println(
      F("MQTT CONNECT FAILED")
    );

    return false;
  }


  Serial.println(
    F("MQTT CONNECT COMMAND OK")
  );

  return true;
}


// =====================================================
// MQTT PUBLISH
// =====================================================

bool mqttPublish(
  const char *topic,
  const char *payload)
{
  char cmd[70];


  // ---------------------------------------------------
  // TOPIC
  // ---------------------------------------------------

  sprintf(
    cmd,
    "AT+CMQTTTOPIC=0,%d",
    strlen(topic)
  );


  if (!sendAT(
        cmd,
        ">",
        5000))
  {
    Serial.println(
      F("TOPIC FAILED")
    );

    return false;
  }


  gsm.print(topic);

  gsm.write('\r');

  delay(300);


  // ---------------------------------------------------
  // PAYLOAD
  // ---------------------------------------------------

  sprintf(
    cmd,
    "AT+CMQTTPAYLOAD=0,%d",
    strlen(payload)
  );


  if (!sendAT(
        cmd,
        ">",
        5000))
  {
    Serial.println(
      F("PAYLOAD COMMAND FAILED")
    );

    return false;
  }


  gsm.print(payload);

  gsm.write('\r');

  delay(300);


  // ---------------------------------------------------
  // PUBLISH
  // ---------------------------------------------------

  if (!sendAT(
        "AT+CMQTTPUB=0,1,60",
        "OK",
        15000))
  {
    Serial.println(
      F("PUBLISH FAILED")
    );

    return false;
  }


  Serial.println();
  Serial.println(
    F("==============================")
  );

  Serial.println(
    F("       MQTT SENT OK")
  );

  Serial.println(
    F("==============================")
  );


  return true;
}


// =====================================================
// APPEND DOUBLE TO STRING
// =====================================================
//
// Arduino UNO AVR does not reliably support %f inside
// sprintf(). dtostrf() is used instead.
//
// =====================================================

void appendDouble(
  char *buffer,
  double value,
  byte decimals)
{
  char temp[18];

  dtostrf(
    value,
    0,
    decimals,
    temp
  );

  strcat(
    buffer,
    temp
  );
}


// =====================================================
// PUBLISH GPS DATA
// =====================================================

bool publishGPS()
{
  if (!gpsFix)
  {
    Serial.println(
      F("Cannot publish GPS: no fix.")
    );

    return false;
  }


  // ---------------------------------------------------
  // MQTT JSON
  // ---------------------------------------------------

  char payload[150];

  payload[0] = '\0';


  strcat(
    payload,
    "{\"id\":\""
  );

  strcat(
    payload,
    MQTT_CLIENT_ID
  );

  strcat(
    payload,
    "\",\"lat\":"
  );


  appendDouble(
    payload,
    gpsLatitude,
    6
  );


  strcat(
    payload,
    ",\"lon\":"
  );


  appendDouble(
    payload,
    gpsLongitude,
    6
  );


  strcat(
    payload,
    ",\"alt\":"
  );


  appendDouble(
    payload,
    gpsAltitude,
    1
  );


  strcat(
    payload,
    ",\"spd\":"
  );


  // Convert knots -> km/h
  appendDouble(
    payload,
    gpsSpeed * 1.852,
    1
  );


  strcat(
    payload,
    ",\"sat\":"
  );


  char satBuffer[8];

  itoa(
    gpsSatellites,
    satBuffer,
    10
  );

  strcat(
    payload,
    satBuffer
  );


  strcat(
    payload,
    "}"
  );


  // ---------------------------------------------------
  // DISPLAY PAYLOAD
  // ---------------------------------------------------

  Serial.println();
  Serial.println(
    F("GPS MQTT PAYLOAD:")
  );

  Serial.println(payload);


  // ---------------------------------------------------
  // SEND
  // ---------------------------------------------------

  return mqttPublish(
    MQTT_TOPIC,
    payload
  );
}


// Setup code

void setup()
{
  Serial.begin(9600);
  gsm.begin(9600);

  Serial.println();
  Serial.println(F("=============================="));
  Serial.println(F(" A7672S + UNO GPS MQTT"));
  Serial.println(F("=============================="));

  delay(5000);


  // ===================================================
  // STEP 1: MODEM
  // ===================================================

  Serial.println();
  Serial.println(F("STEP 1: MODEM"));

  while (!modemOK())
  {
    Serial.println(F("Waiting for modem..."));
    delay(3000);
  }

  Serial.println(F("MODEM OK"));


  // ===================================================
  // STEP 2: SIM
  // ===================================================

  Serial.println();
  Serial.println(F("STEP 2: SIM"));

  while (!simOK())
  {
    Serial.println(F("Waiting for SIM..."));
    delay(3000);
  }

  Serial.println(F("SIM READY"));


  // ===================================================
  // STEP 3: GSM SIGNAL
  // ===================================================

  Serial.println();
  Serial.println(F("STEP 3: SIGNAL"));

  sendAT(
    "AT+CSQ",
    "OK",
    5000
  );


  // ===================================================
  // STEP 4: GSM NETWORK
  // ===================================================

  Serial.println();
  Serial.println(F("STEP 4: GSM NETWORK"));

  while (!networkOK())
  {
    Serial.println(F("Waiting for GSM network..."));
    delay(5000);
  }

  Serial.println(F("GSM NETWORK REGISTERED"));


  // ===================================================
  // STEP 5: INTERNET
  // ===================================================

  Serial.println();
  Serial.println(F("STEP 5: INTERNET"));

  while (!internetOK())
  {
    Serial.println(F("Internet failed."));
    delay(5000);
  }

  Serial.println(F("INTERNET READY"));


  // ===================================================
  // STEP 6: GNSS START
  // ===================================================

  Serial.println();
  Serial.println(F("STEP 6: GNSS"));

  while (!gnssStart())
  {
    Serial.println(F("GNSS start failed."));
    delay(5000);
  }

  Serial.println(F("GNSS ENGINE READY"));


  // ===================================================
  // STEP 7: WAIT FOR GPS FIX
  // ===================================================

  Serial.println();
  Serial.println(F("STEP 7: GPS FIX"));

  while (!readGNSS())
  {
    Serial.println();
    Serial.println(F("No GPS fix yet."));
    Serial.println(F("Waiting for satellites..."));

    delay(5000);
  }

  Serial.println();
  Serial.println(F("GPS FIX ACQUIRED"));


  // ===================================================
// STEP 8: MQTT START
// ===================================================

Serial.println();
Serial.println(F("STEP 8: MQTT START"));

if (!mqttStart())
{
  Serial.println(F("MQTT start failed."));
  Serial.println(F("Stopping program."));
  return;
}

Serial.println(F("MQTT SERVICE READY"));


  // ===================================================
  // STEP 9: MQTT CONNECT
  // ===================================================

  Serial.println();
  Serial.println(F("STEP 9: MQTT CONNECT"));

  while (!mqttConnect())
  {
    Serial.println(F("MQTT connection failed."));
    delay(5000);
  }

  Serial.println(F("MQTT CONNECTED"));


  // ===================================================
  // STEP 10: SEND GPS
  // ===================================================

  Serial.println();
  Serial.println(F("STEP 10: SEND GPS"));

  if (publishGPS())
  {
    Serial.println(F("GPS DATA SENT SUCCESSFULLY"));
  }
  else
  {
    Serial.println(F("GPS DATA SEND FAILED"));
  }


  // ===================================================
  // DONE
  // ===================================================

  Serial.println();
  Serial.println(F("=============================="));
  Serial.println(F("         TEST DONE"));
  Serial.println(F("=============================="));
}


// =====================================================
// LOOP
// =====================================================

unsigned long lastGPSPublish = 0;

const unsigned long GPS_INTERVAL = 120000UL;  // 2 minutes


void loop()
{
  // ---------------------------------------------------
  // Every 2 minutes
  // ---------------------------------------------------

  if (millis() - lastGPSPublish >= GPS_INTERVAL)
  {
    lastGPSPublish = millis();

    Serial.println();
    Serial.println(F("======================================"));
    Serial.println(F("2 MINUTE GPS UPDATE"));
    Serial.println(F("======================================"));


    // -------------------------------------------------
    // Get latest GPS position
    // -------------------------------------------------

    if (readGNSS())
    {
      Serial.println();
      Serial.println(F("GPS FIX OK"));
      Serial.println(F("Publishing GPS to MQTT..."));


      // -----------------------------------------------
      // Publish
      // -----------------------------------------------

      if (publishGPS())
      {
        Serial.println(F("GPS UPDATE SENT"));
      }
      else
      {
        Serial.println(F("GPS UPDATE FAILED"));
      }
    }
    else
    {
      Serial.println();
      Serial.println(F("GPS FIX NOT AVAILABLE"));
      Serial.println(F("Nothing published."));
    }
  }
}