#include <SoftwareSerial.h>

// =====================================================
// A7672S <-> ARDUINO UNO
// =====================================================
//
// A7672S TX -> Arduino D2
// A7672S RX -> Arduino D3
// GND       -> Arduino GND
//
// =====================================================

#define GSM_RX 2
#define GSM_TX 3

SoftwareSerial gsm(GSM_RX, GSM_TX);


// =====================================================
// SETTINGS
// =====================================================

const char APN[] = "airtelgprs.com";

const char MQTT_SERVER[]   = "mqtt.sumato.tech";
const int  MQTT_PORT       = 1883;

const char MQTT_USERNAME[] = "user1";
const char MQTT_PASSWORD[] = "secret";

const char MQTT_CLIENT_ID[] = "RMS001";

const char MQTT_TOPIC[] = "test/device";


// =====================================================
// GPS VARIABLES
// =====================================================

double latitude = 0;
double longitude = 0;

bool gpsValid = false;


// =====================================================
// CLEAR MODEM BUFFER
// =====================================================

void clearModem()
{
  while (gsm.available())
    gsm.read();
}


// =====================================================
// SEND AT COMMAND
// =====================================================

bool sendAT(
  const char *cmd,
  const char *expected,
  unsigned long timeout)
{
  clearModem();

  Serial.print(">> ");
  Serial.println(cmd);

  gsm.println(cmd);

  unsigned long start = millis();

  char buffer[100];
  byte pos = 0;

  buffer[0] = '\0';

  while (millis() - start < timeout)
  {
    while (gsm.available())
    {
      char c = gsm.read();

      Serial.write(c);

      if (pos < sizeof(buffer) - 1)
      {
        buffer[pos++] = c;
        buffer[pos] = '\0';
      }

      if (strstr(buffer, expected))
        return true;

      if (strstr(buffer, "ERROR"))
        return false;
    }
  }

  Serial.println("TIMEOUT");

  return false;
}


// =====================================================
// MODEM CHECK
// =====================================================

bool modemOK()
{
  return sendAT(
    "AT",
    "OK",
    3000
  );
}


// =====================================================
// SIM CHECK
// =====================================================

bool simOK()
{
  return sendAT(
    "AT+CPIN?",
    "READY",
    5000
  );
}


// =====================================================
// NETWORK CHECK
// =====================================================

bool networkOK()
{
  clearModem();

  Serial.println(">> AT+CEREG?");

  gsm.println("AT+CEREG?");

  unsigned long start = millis();

  char buffer[100];
  byte pos = 0;

  buffer[0] = '\0';

  while (millis() - start < 5000)
  {
    while (gsm.available())
    {
      char c = gsm.read();

      Serial.write(c);

      if (pos < sizeof(buffer) - 1)
      {
        buffer[pos++] = c;
        buffer[pos] = '\0';
      }

      if (strstr(buffer, ",1") ||
          strstr(buffer, ",5"))
      {
        return true;
      }
    }
  }

  return false;
}


// =====================================================
// INTERNET / PDP
// =====================================================

bool internetOK()
{
  char cmd[70];

  Serial.println();
  Serial.println("Connecting Internet...");


  // ---------------------------------------------------
  // APN
  // ---------------------------------------------------

  sprintf(
    cmd,
    "AT+CGDCONT=1,\"IP\",\"%s\"",
    APN
  );

  if (!sendAT(
        cmd,
        "OK",
        5000))
  {
    return false;
  }


  // ---------------------------------------------------
  // Attach packet service
  // ---------------------------------------------------

  if (!sendAT(
        "AT+CGATT=1",
        "OK",
        15000))
  {
    return false;
  }


  // ---------------------------------------------------
  // Activate PDP
  // ---------------------------------------------------

  if (!sendAT(
        "AT+CGACT=1,1",
        "OK",
        15000))
  {
    return false;
  }


  // ---------------------------------------------------
  // Get IP
  // ---------------------------------------------------

  if (!sendAT(
        "AT+CGPADDR=1",
        "+CGPADDR:",
        5000))
  {
    return false;
  }


  Serial.println();
  Serial.println("INTERNET OK");

  return true;
}


// =====================================================
// MQTT START
// =====================================================

bool mqttStart()
{
  Serial.println();
  Serial.println("Starting MQTT...");


  if (!sendAT(
        "AT+CMQTTSTART",
        "OK",
        15000))
  {
    return false;
  }


  char cmd[70];

  sprintf(
    cmd,
    "AT+CMQTTACCQ=0,\"%s\",0",
    MQTT_CLIENT_ID
  );


  if (!sendAT(
        cmd,
        "OK",
        5000))
  {
    return false;
  }


  Serial.println("MQTT SERVICE READY");

  return true;
}


// =====================================================
// MQTT CONNECT
// =====================================================

bool mqttConnect()
{
  char cmd[180];

  sprintf(
    cmd,
    "AT+CMQTTCONNECT=0,\"tcp://%s:%d\",60,1,\"%s\",\"%s\"",
    MQTT_SERVER,
    MQTT_PORT,
    MQTT_USERNAME,
    MQTT_PASSWORD
  );


  Serial.println();
  Serial.println("Connecting MQTT...");


  if (!sendAT(
        cmd,
        "OK",
        30000))
  {
    Serial.println(
      "MQTT CONNECT FAILED"
    );

    return false;
  }


  Serial.println(
    "MQTT CONNECT COMMAND OK"
  );

  return true;
}


// =====================================================
// START GNSS
// =====================================================

bool startGNSS()
{
  Serial.println();
  Serial.println("Starting GNSS...");


  if (!sendAT(
        "AT+CGNSSPWR=1",
        "OK",
        5000))
  {
    Serial.println(
      "GNSS START FAILED"
    );

    return false;
  }


  Serial.println(
    "GNSS POWER ON"
  );

  return true;
}


// =====================================================
// READ GNSS
// =====================================================
//
// This uses your previous working parsing technique.
// =====================================================

bool readGNSS()
{
  Serial.println();
  Serial.println("======================================");
  Serial.println("Checking GNSS...");
  Serial.println("======================================");


  clearModem();

  gsm.println("AT+CGNSSINFO");


  String response = "";

  unsigned long start = millis();


  // ---------------------------------------------------
  // Wait for complete GNSS response
  // ---------------------------------------------------

  while (millis() - start < 5000)
  {
    while (gsm.available())
    {
      char c = gsm.read();

      Serial.write(c);

      response += c;

      // Extend timeout whenever data arrives
      start = millis();
    }
  }


  // ---------------------------------------------------
  // Find +CGNSSINFO:
  // ---------------------------------------------------

  int pos = response.indexOf(
    "+CGNSSINFO:"
  );


  if (pos < 0)
  {
    Serial.println();
    Serial.println(
      "No GNSS response."
    );

    gpsValid = false;

    return false;
  }


  // ---------------------------------------------------
  // Remove everything before +CGNSSINFO:
  // ---------------------------------------------------

  String data =
    response.substring(pos + 11);


  // ---------------------------------------------------
  // Remove OK
  // ---------------------------------------------------

  int okPos =
    data.indexOf("OK");


  if (okPos >= 0)
  {
    data =
      data.substring(0, okPos);
  }


  data.trim();


  // ---------------------------------------------------
  // Split fields
  // ---------------------------------------------------

  String field[25];

  int fieldCount = 0;

  int fieldStart = 0;


  for (
    int i = 0;
    i <= data.length();
    i++
  )
  {
    if (
      i == data.length() ||
      data.charAt(i) == ','
    )
    {
      if (fieldCount < 25)
      {
        field[fieldCount] =
          data.substring(
            fieldStart,
            i
          );

        field[fieldCount].trim();

        fieldCount++;
      }

      fieldStart = i + 1;
    }
  }


  // ---------------------------------------------------
  // Find latitude/longitude
  // ---------------------------------------------------

  int latitudeIndex = -1;

  int longitudeIndex = -1;

  int latitudeDirectionIndex = -1;

  int longitudeDirectionIndex = -1;


  for (
    int i = 0;
    i < fieldCount;
    i++
  )
  {

    // Latitude direction

    if (
      field[i] == "N" ||
      field[i] == "S"
    )
    {
      latitudeDirectionIndex = i;

      if (i > 0)
      {
        latitudeIndex = i - 1;
      }
    }


    // Longitude direction

    if (
      field[i] == "E" ||
      field[i] == "W"
    )
    {
      longitudeDirectionIndex = i;

      if (i > 0)
      {
        longitudeIndex = i - 1;
      }
    }
  }


  // ---------------------------------------------------
  // Check coordinates
  // ---------------------------------------------------

  if (
    latitudeIndex < 0 ||
    longitudeIndex < 0
  )
  {
    Serial.println();
    Serial.println(
      "GPS coordinates not available yet."
    );

    Serial.println(
      "Waiting for satellite fix..."
    );

    gpsValid = false;

    return false;
  }


  // ---------------------------------------------------
  // Fix mode
  // ---------------------------------------------------

  int fixMode =
    field[0].toInt();


  if (fixMode < 2)
  {
    Serial.println();
    Serial.println("NO GPS FIX");

    Serial.println(
      "Waiting for satellites..."
    );

    gpsValid = false;

    return false;
  }


  // ---------------------------------------------------
  // Convert latitude/longitude
  // ---------------------------------------------------

  latitude =
    field[latitudeIndex].toFloat();


  longitude =
    field[longitudeIndex].toFloat();


  // ---------------------------------------------------
  // Apply direction
  // ---------------------------------------------------

  if (
    field[latitudeDirectionIndex] == "S"
  )
  {
    latitude = -latitude;
  }


  if (
    field[longitudeDirectionIndex] == "W"
  )
  {
    longitude = -longitude;
  }


  gpsValid = true;


  // ---------------------------------------------------
  // Find additional fields
  // ---------------------------------------------------

  int dateIndex =
    longitudeDirectionIndex + 1;

  int timeIndex =
    longitudeDirectionIndex + 2;

  int altitudeIndex =
    longitudeDirectionIndex + 3;

  int speedIndex =
    longitudeDirectionIndex + 4;

  int courseIndex =
    longitudeDirectionIndex + 5;


  // ---------------------------------------------------
  // DISPLAY GPS
  // ---------------------------------------------------

  Serial.println();
  Serial.println("******** GPS FIX ********");


  Serial.print("Fix mode       : ");
  Serial.println(field[0]);


  Serial.print("GPS satellites : ");
  Serial.println(field[1]);


  Serial.print("Latitude       : ");
  Serial.println(
    latitude,
    7
  );


  Serial.print("Longitude      : ");
  Serial.println(
    longitude,
    7
  );


  // ---------------------------------------------------
  // Date
  // ---------------------------------------------------

  if (dateIndex < fieldCount)
  {
    Serial.print("Date           : ");
    Serial.println(
      field[dateIndex]
    );
  }


  // ---------------------------------------------------
  // UTC time
  // ---------------------------------------------------

  if (timeIndex < fieldCount)
  {
    Serial.print("UTC time       : ");
    Serial.println(
      field[timeIndex]
    );
  }


  // ---------------------------------------------------
  // Altitude
  // ---------------------------------------------------

  if (altitudeIndex < fieldCount)
  {
    Serial.print("Altitude       : ");

    Serial.print(
      field[altitudeIndex]
    );

    Serial.println(" m");
  }


  // ---------------------------------------------------
  // Speed
  // ---------------------------------------------------

  if (speedIndex < fieldCount)
  {
    double speedKnots =
      field[speedIndex].toFloat();


    Serial.print("Speed          : ");

    Serial.print(
      speedKnots,
      2
    );

    Serial.println(
      " knots"
    );


    Serial.print("Speed          : ");

    Serial.print(
      speedKnots * 1.852,
      2
    );

    Serial.println(
      " km/h"
    );
  }


  // ---------------------------------------------------
  // Course
  // ---------------------------------------------------

  if (courseIndex < fieldCount)
  {
    Serial.print("Course         : ");

    Serial.println(
      field[courseIndex]
    );
  }


  // ---------------------------------------------------
  // Google Maps
  // ---------------------------------------------------

  Serial.println();

  Serial.println(
    "Google Maps:"
  );

  Serial.print(
    "https://maps.google.com/?q="
  );

  Serial.print(
    latitude,
    7
  );

  Serial.print(",");

  Serial.println(
    longitude,
    7
  );


  Serial.println(
    "*************************"
  );


  return true;
}


// =====================================================
// MQTT PUBLISH
// =====================================================

bool mqttPublish(
  const char *topic,
  const char *payload)
{
  char cmd[70];


  // ---------------------------------------------------
  // TOPIC
  // ---------------------------------------------------

  sprintf(
    cmd,
    "AT+CMQTTTOPIC=0,%d",
    strlen(topic)
  );


  if (!sendAT(
        cmd,
        ">",
        5000))
  {
    Serial.println(
      "TOPIC FAILED"
    );

    return false;
  }


  gsm.print(topic);

  gsm.write('\r');

  delay(300);


  // ---------------------------------------------------
  // PAYLOAD
  // ---------------------------------------------------

  sprintf(
    cmd,
    "AT+CMQTTPAYLOAD=0,%d",
    strlen(payload)
  );


  if (!sendAT(
        cmd,
        ">",
        5000))
  {
    Serial.println(
      "PAYLOAD COMMAND FAILED"
    );

    return false;
  }


  gsm.print(payload);

  gsm.write('\r');

  delay(300);


  // ---------------------------------------------------
  // PUBLISH
  // ---------------------------------------------------

  if (!sendAT(
        "AT+CMQTTPUB=0,1,60",
        "OK",
        15000))
  {
    Serial.println(
      "PUBLISH FAILED"
    );

    return false;
  }


  Serial.println();
  Serial.println(
    "=============================="
  );

  Serial.println(
    "       MQTT SENT OK"
  );

  Serial.println(
    "=============================="
  );


  return true;
}


// =====================================================
// CREATE AND SEND GPS PAYLOAD
// =====================================================

void publishGPS()
{
  if (!gpsValid)
  {
    Serial.println(
      "No valid GPS data."
    );

    return;
  }


  // ---------------------------------------------------
  // Small JSON payload
  // ---------------------------------------------------

  char payload[120];


  sprintf(
    payload,
    "{\"device\":\"%s\",\"lat\":%.7f,\"lon\":%.7f}",
    MQTT_CLIENT_ID,
    latitude,
    longitude
  );


  Serial.println();
  Serial.println(
    "MQTT GPS PAYLOAD:"
  );

  Serial.println(payload);


  mqttPublish(
    MQTT_TOPIC,
    payload
  );
}


// =====================================================
// SETUP
// =====================================================

void setup()
{
  Serial.begin(9600);

  gsm.begin(9600);


  Serial.println();
  Serial.println(
    "=============================="
  );

  Serial.println(
    " A7672S + UNO"
  );

  Serial.println(
    " MQTT + GPS TEST"
  );

  Serial.println(
    "=============================="
  );


  delay(5000);


  // ===================================================
  // MODEM
  // ===================================================

  Serial.println();
  Serial.println(
    "STEP 1: MODEM"
  );


  while (!modemOK())
  {
    Serial.println(
      "Waiting for modem..."
    );

    delay(3000);
  }


  Serial.println(
    "MODEM OK"
  );


  // ===================================================
  // SIM
  // ===================================================

  Serial.println();
  Serial.println(
    "STEP 2: SIM"
  );


  while (!simOK())
  {
    Serial.println(
      "Waiting for SIM..."
    );

    delay(3000);
  }


  Serial.println(
    "SIM READY"
  );


  // ===================================================
  // SIGNAL
  // ===================================================

  Serial.println();
  Serial.println(
    "STEP 3: SIGNAL"
  );


  sendAT(
    "AT+CSQ",
    "OK",
    5000
  );


  // ===================================================
  // NETWORK
  // ===================================================

  Serial.println();
  Serial.println(
    "STEP 4: NETWORK"
  );


  while (!networkOK())
  {
    Serial.println(
      "Waiting for network..."
    );

    delay(5000);
  }


  Serial.println();
  Serial.println(
    "NETWORK REGISTERED"
  );


  // ===================================================
  // INTERNET
  // ===================================================

  Serial.println();
  Serial.println(
    "STEP 5: INTERNET"
  );


  while (!internetOK())
  {
    Serial.println(
      "Internet failed."
    );

    delay(5000);
  }


  // ===================================================
  // MQTT START
  // ===================================================

  Serial.println();
  Serial.println(
    "STEP 6: MQTT START"
  );


  while (!mqttStart())
  {
    Serial.println(
      "MQTT start failed."
    );

    delay(5000);
  }


  // ===================================================
  // MQTT CONNECT
  // ===================================================

  Serial.println();
  Serial.println(
    "STEP 7: MQTT CONNECT"
  );


  while (!mqttConnect())
  {
    Serial.println(
      "MQTT connection failed."
    );

    delay(5000);
  }


  // ===================================================
  // GNSS START
  // ===================================================

  Serial.println();
  Serial.println(
    "STEP 8: GNSS"
  );


  while (!startGNSS())
  {
    Serial.println(
      "GNSS start failed."
    );

    delay(5000);
  }


  // ===================================================
  // WAIT FOR GPS
  // ===================================================

  Serial.println();
  Serial.println(
    "Waiting for GPS fix..."
  );


  while (!readGNSS())
  {
    delay(5000);
  }


  // ===================================================
  // PUBLISH GPS
  // ===================================================

  Serial.println();
  Serial.println(
    "STEP 9: GPS MQTT PUBLISH"
  );


  publishGPS();


  Serial.println();
  Serial.println(
    "=============================="
  );

  Serial.println(
    "        SYSTEM READY"
  );

  Serial.println(
    "=============================="
  );
}


// =====================================================
// LOOP
// =====================================================

void loop()
{
  static unsigned long lastGPS = 0;


  // ---------------------------------------------------
  // Read + publish GPS every 60 seconds
  // ---------------------------------------------------

  if (
    millis() - lastGPS >= 60000UL
  )
  {
    lastGPS = millis();


    if (readGNSS())
    {
      publishGPS();
    }
  }
}
