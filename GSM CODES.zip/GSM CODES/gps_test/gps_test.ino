/*
   ESP32 GPS + MQTT Publisher

   GPS TX -> ESP32 GPIO16 (RX2)
   GPS RX -> ESP32 GPIO17 (TX2)

   Publishes GPS data to:
   rms/RMS001/gps
*/

#include <WiFi.h>
#include <PubSubClient.h>
#include <TinyGPS++.h>
#include <ArduinoJson.h>

//=====================================================
// WiFi
//=====================================================
#define WIFI_SSID "POCO X5 Pro 5G"
#define WIFI_PASSWORD ""  // Open network

//=====================================================
// MQTT
//=====================================================
#define MQTT_SERVER "mqtt.sumato.tech"
#define MQTT_PORT 1883
#define MQTT_USERNAME "user1"
#define MQTT_PASSWORD "secret"
#define MQTT_CLIENT_ID "RMS001"

#define TOPIC_GPS "rms/RMS001/gps"

//=====================================================
// GPS
//=====================================================
#define GPS_RX_PIN 16
#define GPS_TX_PIN 17
#define GPS_BAUD 9600

TinyGPSPlus gps;
HardwareSerial GPS(2);

WiFiClient espClient;
PubSubClient mqttClient(espClient);

//=====================================================

void connectWiFi() {
  static unsigned long lastAttempt = 0;

  if (WiFi.status() == WL_CONNECTED)
    return;

  if (millis() - lastAttempt < 5000)
    return;

  lastAttempt = millis();

  Serial.println();
  Serial.print("Connecting to WiFi... ");

  WiFi.disconnect(true);
  delay(100);

  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
}
//=====================================================

void connectMQTT() {
  static unsigned long lastAttempt = 0;

  if (mqttClient.connected())
    return;

  if (millis() - lastAttempt < 5000)
    return;

  lastAttempt = millis();

  Serial.print("Connecting MQTT... ");

  if (mqttClient.connect(
        MQTT_CLIENT_ID,
        MQTT_USERNAME,
        MQTT_PASSWORD)) {
    Serial.println("Connected");
  } else {
    Serial.print("Failed rc=");
    Serial.println(mqttClient.state());
  }
}

//=====================================================

void publishGPS() {
  StaticJsonDocument<256> doc;

  doc["latitude"] = gps.location.lat();
  doc["longitude"] = gps.location.lng();
  doc["altitude"] = gps.altitude.meters();
  doc["speed"] = gps.speed.kmph();
  doc["satellites"] = gps.satellites.value();
  doc["hdop"] = gps.hdop.hdop();

  char payload[256];
  serializeJson(doc, payload);

  if (mqttClient.publish(TOPIC_GPS, payload)) {
    Serial.println("GPS Published");
    Serial.println(payload);
  } else {
    Serial.println("MQTT Publish Failed");
  }
}

//=====================================================

void setup() {
  Serial.begin(115200);

  GPS.begin(
    GPS_BAUD,
    SERIAL_8N1,
    GPS_RX_PIN,
    GPS_TX_PIN);

  connectWiFi();

  mqttClient.setServer(MQTT_SERVER, MQTT_PORT);

  connectMQTT();

  Serial.println();
  Serial.println("================================");
  Serial.println("Waiting for GPS Fix...");
  Serial.println("================================");
}

//=====================================================

// void loop() {
//   //--------------------------------------------------
//   // Keep WiFi alive
//   //--------------------------------------------------

//   connectWiFi();

//   if (WiFi.status() == WL_CONNECTED) {
//     static bool wifiPrinted = false;

//     if (!wifiPrinted) {
//       wifiPrinted = true;

//       Serial.println();
//       Serial.println("WiFi Connected");
//       Serial.print("IP : ");
//       Serial.println(WiFi.localIP());
//     }

//     connectMQTT();
//   }

//   mqttClient.loop();

//   //--------------------------------------------------
//   // Read GPS continuously
//   //--------------------------------------------------

//   while (GPS.available()) {
//     gps.encode(GPS.read());
//   }

//   //--------------------------------------------------
//   // Status every second
//   //--------------------------------------------------

//   static unsigned long timer = 0;

//   if (millis() - timer >= 1000) {
//     timer = millis();

//     Serial.print("Satellites: ");

//     if (gps.satellites.isValid())
//       Serial.print(gps.satellites.value());
//     else
//       Serial.print("0");

//     if (gps.location.isValid()) {
//       Serial.println("  --> GPS FIX");

//       Serial.print("Latitude : ");
//       Serial.println(gps.location.lat(), 6);

//       Serial.print("Longitude: ");
//       Serial.println(gps.location.lng(), 6);

//       Serial.print("Altitude : ");
//       Serial.print(gps.altitude.meters());
//       Serial.println(" m");

//       Serial.print("Speed    : ");
//       Serial.print(gps.speed.kmph());
//       Serial.println(" km/h");

//       Serial.print("HDOP     : ");

//       if (gps.hdop.isValid())
//         Serial.println(gps.hdop.hdop());
//       else
//         Serial.println("N/A");

//       if (WiFi.status() == WL_CONNECTED && mqttClient.connected()) {
//         publishGPS();
//       }

//       Serial.println("--------------------------------");
//     } else {
//       Serial.println("  Searching...");
//     }
//   }
// }


void loop()
{
    while (GPS.available())
    {
        char c = GPS.read();
        Serial.write(c);
    }
}


// #include <WiFi.h>

// void setup()
// {
//     Serial.begin(115200);

//     WiFi.mode(WIFI_STA);
//     WiFi.disconnect();
//     delay(100);

//     Serial.println("Scanning...");

//     int n = WiFi.scanNetworks();

//     for (int i = 0; i < n; i++)
//     {
//         Serial.printf("%s (%d dBm)\n",
//                       WiFi.SSID(i).c_str(),
//                       WiFi.RSSI(i));
//     }
// }

// void loop()
// {
// }