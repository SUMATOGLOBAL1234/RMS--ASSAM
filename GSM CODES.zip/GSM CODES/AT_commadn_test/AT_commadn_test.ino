#include <SoftwareSerial.h>

const int GSM_TX_PIN = 3;
const int GSM_RX_PIN = 2;

const long SERIAL_BAUD = 9600;
const long GSM_BAUD = 9600;

SoftwareSerial gsm(GSM_TX_PIN, GSM_RX_PIN);


// =====================================================
// TIMERS
// =====================================================

const unsigned long GPS_INTERVAL = 60000UL;     // 1 minute
const unsigned long GSM_CHECK_INTERVAL = 30000UL;

unsigned long lastGPS = 0;
unsigned long lastGSMCheck = 0;


// =====================================================
// STATE
// =====================================================

enum SystemState
{
  MODEM_STARTING,
  CHECKING_SIM,
  WAITING_NETWORK,
  CONNECTING_DATA,
  STARTING_GNSS,
  RUNNING
};

SystemState state = MODEM_STARTING;


// =====================================================
// SETUP
// =====================================================

void setup()
{
  Serial.begin(SERIAL_BAUD);
  gsm.begin(GSM_BAUD);

  Serial.println();
  Serial.println("====================================");
  Serial.println("       A7672S TRACKER");
  Serial.println("====================================");

  delay(10000);

  state = MODEM_STARTING;
}


// =====================================================
// MAIN LOOP
// =====================================================

void loop()
{
  switch (state)
  {

    // ================================================
    // MODEM
    // ================================================

    case MODEM_STARTING:

      if (modemOK())
      {
        Serial.println("Modem OK");

        state = CHECKING_SIM;
      }
      else
      {
        Serial.println("Modem not responding.");

        delay(3000);
      }

      break;


    // ================================================
    // SIM
    // ================================================

    case CHECKING_SIM:

      if (simReady())
      {
        Serial.println("SIM READY");

        state = WAITING_NETWORK;
      }
      else
      {
        Serial.println("SIM not ready.");

        delay(3000);
      }

      break;


    // ================================================
    // NETWORK
    // ================================================

    case WAITING_NETWORK:

      Serial.println("Checking network registration...");

      if (networkRegistered())
      {
        Serial.println("NETWORK REGISTERED");

        state = CONNECTING_DATA;
      }
      else
      {
        Serial.println("Waiting for network...");

        delay(5000);
      }

      break;


    // ================================================
    // MOBILE DATA
    // ================================================

    case CONNECTING_DATA:

      Serial.println("Activating mobile data...");

      if (connectData())
      {
        Serial.println("MOBILE DATA CONNECTED");

        state = STARTING_GNSS;
      }
      else
      {
        Serial.println("Data connection failed.");

        delay(5000);
      }

      break;


    // ================================================
    // GNSS
    // ================================================

    case STARTING_GNSS:

      Serial.println("Starting GNSS...");

      if (startGNSS())
      {
        Serial.println("GNSS STARTED");

        state = RUNNING;
      }
      else
      {
        Serial.println("GNSS start failed.");

        delay(5000);
      }

      break;


    // ================================================
    // NORMAL OPERATION
    // ================================================

    case RUNNING:

      runningMode();

      break;
  }
}


// =====================================================
// MODEM TEST
// =====================================================

bool modemOK()
{
  String response = sendAT("AT", 3000);

  return response.indexOf("OK") >= 0;
}


// =====================================================
// SIM TEST
// =====================================================

bool simReady()
{
  String response = sendAT("AT+CPIN?", 3000);

  return response.indexOf("+CPIN: READY") >= 0;
}


// =====================================================
// NETWORK REGISTRATION
// =====================================================

bool networkRegistered()
{
  String response = sendAT("AT+CEREG?", 3000);

  // 1 = registered home network
  // 5 = registered roaming

  if (response.indexOf(",1") >= 0)
    return true;

  if (response.indexOf(",5") >= 0)
    return true;

  return false;
}


// =====================================================
// CONNECT MOBILE DATA
// =====================================================

bool connectData()
{
  String response;

  response = sendAT("AT+CGATT=1", 10000);

  if (response.indexOf("OK") < 0)
    return false;

  response = sendAT("AT+CGACT=1,1", 10000);

  if (response.indexOf("OK") < 0)
    return false;

  response = sendAT("AT+CGPADDR=1", 5000);

  if (response.indexOf(".") >= 0)
    return true;

  return false;
}


// =====================================================
// START GNSS
// =====================================================

bool startGNSS()
{
  String response =
      sendAT("AT+CGNSSPWR=1", 5000);

  return response.indexOf("OK") >= 0;
}


// =====================================================
// RUNNING MODE
// =====================================================

void runningMode()
{
  unsigned long now = millis();


  // ---------------------------------------------------
  // GPS EVERY 1 MINUTE
  // ---------------------------------------------------

  if (now - lastGPS >= GPS_INTERVAL)
  {
    lastGPS = now;

    Serial.println();
    Serial.println("Reading GPS...");

    readGNSS();

    // Later:
    // compare previous GPS
    // if changed significantly:
    // publishMQTT();
  }


  // ---------------------------------------------------
  // GSM CONNECTION CHECK
  // ---------------------------------------------------

  if (now - lastGSMCheck >= GSM_CHECK_INTERVAL)
  {
    lastGSMCheck = now;

    if (!networkRegistered())
    {
      Serial.println("NETWORK LOST");

      state = WAITING_NETWORK;
      return;
    }
  }


  // ---------------------------------------------------
  // SERIAL MONITOR
  // ---------------------------------------------------

  while (Serial.available())
  {
    gsm.write(Serial.read());
  }

  while (gsm.available())
  {
    Serial.write(gsm.read());
  }
}


// =====================================================
// GPS
// =====================================================

void readGNSS()
{
  String response =
      sendAT("AT+CGNSSINFO", 5000);

  Serial.println(response);

  // We'll put the corrected parser here.
}


// =====================================================
// SEND AT COMMAND
// =====================================================

String sendAT(const char *command,
              unsigned long timeout)
{
  clearBuffer();

  Serial.print(">> ");
  Serial.println(command);

  gsm.println(command);

  String response = "";

  unsigned long start = millis();

  while (millis() - start < timeout)
  {
    while (gsm.available())
    {
      char c = gsm.read();

      Serial.write(c);

      response += c;

      start = millis();
    }
  }

  Serial.println();

  return response;
}


// =====================================================
// CLEAR BUFFER
// =====================================================

void clearBuffer()
{
  while (gsm.available())
  {
    gsm.read();
  }
}
