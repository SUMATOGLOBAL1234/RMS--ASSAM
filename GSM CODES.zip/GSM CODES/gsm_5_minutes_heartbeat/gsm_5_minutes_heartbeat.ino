#include <SoftwareSerial.h>
#include <string.h>
#include <stdlib.h>

// =====================================================
// A7672S <-> Arduino UNO
// A7672S TX -> Arduino D2
// A7672S RX -> Arduino D3
// =====================================================

SoftwareSerial gsm(2, 3);   // RX, TX

// =====================================================
// SETTINGS
// =====================================================

const char APN[] = "airtelgprs.com";

const char MQTT_SERVER[] = "mqtt.sumato.tech";
const int  MQTT_PORT = 1883;

const char MQTT_USER[] = "user1";
const char MQTT_PASS[] = "secret";

const char MQTT_CLIENT_ID[] = "RMS002";
const char MQTT_TOPIC[] = "test/device";

const unsigned long SEND_INTERVAL = 300000UL; // 5 minutes

unsigned long lastSend = 0;

// =====================================================
// CLEAR MODEM BUFFER
// =====================================================

void clearModem()
{
  while (gsm.available())
  {
    gsm.read();
  }
}

// =====================================================
// SEND AT COMMAND
// =====================================================

bool sendAT(const char *command,
            const char *expected,
            unsigned long timeout)
{
  clearModem();

  Serial.print(">> ");
  Serial.println(command);

  gsm.println(command);

  unsigned long start = millis();

  char buffer[180];
  int index = 0;

  memset(buffer, 0, sizeof(buffer));

  while (millis() - start < timeout)
  {
    while (gsm.available())
    {
      char c = gsm.read();

      Serial.write(c);

      if (index < sizeof(buffer) - 1)
      {
        buffer[index++] = c;
        buffer[index] = '\0';
      }

      if (strstr(buffer, expected))
      {
        Serial.println();
        return true;
      }

      if (strstr(buffer, "ERROR"))
      {
        Serial.println();
        return false;
      }
    }
  }

  Serial.println();
  return false;
}

// =====================================================
// MODEM CHECK
// =====================================================

bool modemOK()
{
  return sendAT("AT", "OK", 3000);
}

// =====================================================
// SIM CHECK
// =====================================================

bool simOK()
{
  return sendAT("AT+CPIN?", "READY", 5000);
}

// =====================================================
// SIGNAL CHECK
// =====================================================

bool signalOK()
{
  clearModem();

  Serial.println(">> AT+CSQ");

  gsm.println("AT+CSQ");

  unsigned long start = millis();

  char buffer[120];
  int index = 0;

  memset(buffer, 0, sizeof(buffer));

  while (millis() - start < 5000)
  {
    while (gsm.available())
    {
      char c = gsm.read();

      Serial.write(c);

      if (index < sizeof(buffer) - 1)
      {
        buffer[index++] = c;
        buffer[index] = '\0';
      }

      if (strstr(buffer, "+CSQ:"))
      {
        char *p = strstr(buffer, "+CSQ:");

        int rssi = atoi(p + 6);

        Serial.println();
        Serial.print("Signal RSSI: ");
        Serial.println(rssi);

        if (rssi == 99)
        {
          return false;
        }

        return true;
      }
    }
  }

  Serial.println();
  return false;
}

// =====================================================
// NETWORK CHECK
// =====================================================

bool networkOK()
{
  clearModem();

  Serial.println(">> AT+CEREG?");

  gsm.println("AT+CEREG?");

  unsigned long start = millis();

  char buffer[150];
  int index = 0;

  memset(buffer, 0, sizeof(buffer));

  while (millis() - start < 10000)
  {
    while (gsm.available())
    {
      char c = gsm.read();

      Serial.write(c);

      if (index < sizeof(buffer) - 1)
      {
        buffer[index++] = c;
        buffer[index] = '\0';
      }

      // Registered home network
      if (strstr(buffer, ",1"))
      {
        Serial.println();
        Serial.println("Network registered.");
        return true;
      }

      // Registered roaming
      if (strstr(buffer, ",5"))
      {
        Serial.println();
        Serial.println("Network registered (roaming).");
        return true;
      }
    }
  }

  Serial.println();
  return false;
}

// =====================================================
// INTERNET / PDP CONTEXT
// =====================================================

bool internetOK()
{
  Serial.println("Setting APN...");

  if (!sendAT("AT+CGDCONT=1,\"IP\",\"airtelgprs.com\"",
              "OK",
              5000))
  {
    return false;
  }

  Serial.println("Attaching packet domain...");

  if (!sendAT("AT+CGATT=1", "OK", 15000))
  {
    return false;
  }

  Serial.println("Activating PDP...");

  if (!sendAT("AT+CGACT=1,1", "OK", 30000))
  {
    return false;
  }

  Serial.println("Checking IP...");

  if (!sendAT("AT+CGPADDR=1", "+CGPADDR:", 10000))
  {
    return false;
  }

  return true;
}

// =====================================================
// MQTT STOP
//
// We deliberately stop MQTT first.
// If it is already stopped, ERROR is ignored.
// =====================================================

void mqttStop()
{
  clearModem();

  Serial.println("Stopping previous MQTT service...");

  gsm.println("AT+CMQTTSTOP");

  unsigned long start = millis();

  while (millis() - start < 10000)
  {
    while (gsm.available())
    {
      char c = gsm.read();
      Serial.write(c);
    }
  }

  Serial.println();
}

// =====================================================
// MQTT START
// =====================================================

bool mqttStart()
{
  // Make sure an old MQTT service is not left running
  mqttStop();

  delay(1000);

  clearModem();

  Serial.println("Starting MQTT...");

  gsm.println("AT+CMQTTSTART");

  unsigned long start = millis();

  char buffer[180];
  int index = 0;

  memset(buffer, 0, sizeof(buffer));

  while (millis() - start < 20000)
  {
    while (gsm.available())
    {
      char c = gsm.read();

      Serial.write(c);

      if (index < sizeof(buffer) - 1)
      {
        buffer[index++] = c;
        buffer[index] = '\0';
      }

      // Correct successful MQTT start response
      if (strstr(buffer, "+CMQTTSTART: 0"))
      {
        Serial.println();
        Serial.println("MQTT STARTED");
        return true;
      }

      if (strstr(buffer, "ERROR"))
      {
        Serial.println();
        Serial.println("MQTT start returned ERROR.");
        return false;
      }
    }
  }

  Serial.println();
  Serial.println("MQTT start timeout.");

  return false;
}

// =====================================================
// MQTT CLIENT ACQUIRE
// =====================================================

bool mqttAcquire()
{
  char command[100];

  snprintf(command,
           sizeof(command),
           "AT+CMQTTACCQ=0,\"%s\",0",
           MQTT_CLIENT_ID);

  if (!sendAT(command, "OK", 10000))
  {
    Serial.println("MQTT client acquire failed.");
    return false;
  }

  Serial.println("MQTT client acquired.");

  return true;
}

// =====================================================
// MQTT CONNECT
// =====================================================

bool mqttConnect()
{
  char command[220];

  snprintf(command,
           sizeof(command),
           "AT+CMQTTCONNECT=0,\"tcp://%s:%d\",60,1,\"%s\",\"%s\"",
           MQTT_SERVER,
           MQTT_PORT,
           MQTT_USER,
           MQTT_PASS);

  clearModem();

  Serial.println("Connecting MQTT...");

  gsm.println(command);

  unsigned long start = millis();

  char buffer[220];
  int index = 0;

  memset(buffer, 0, sizeof(buffer));

  while (millis() - start < 30000)
  {
    while (gsm.available())
    {
      char c = gsm.read();

      Serial.write(c);

      if (index < sizeof(buffer) - 1)
      {
        buffer[index++] = c;
        buffer[index] = '\0';
      }

      // MQTT connected
      if (strstr(buffer, "+CMQTTCONNECT: 0,0"))
      {
        Serial.println();
        Serial.println("MQTT CONNECTED");
        return true;
      }

      if (strstr(buffer, "ERROR"))
      {
        Serial.println();
        Serial.println("MQTT CONNECT ERROR");
        return false;
      }
    }
  }

  Serial.println();
  Serial.println("MQTT connection timeout.");

  return false;
}

// =====================================================
// MQTT PUBLISH
// =====================================================

bool mqttPublish(const char *topic, const char *payload)
{
  char command[80];

  int topicLength = strlen(topic);
  int payloadLength = strlen(payload);

  // ---------------------------------------------------
  // TOPIC
  // ---------------------------------------------------

  snprintf(command,
           sizeof(command),
           "AT+CMQTTTOPIC=0,%d",
           topicLength);

  clearModem();

  Serial.print(">> ");
  Serial.println(command);

  gsm.println(command);

  unsigned long start = millis();

  bool prompt = false;

  while (millis() - start < 10000)
  {
    while (gsm.available())
    {
      char c = gsm.read();
      Serial.write(c);

      if (c == '>')
      {
        prompt = true;
        break;
      }
    }

    if (prompt)
      break;
  }

  if (!prompt)
  {
    Serial.println();
    Serial.println("Topic prompt failed.");
    return false;
  }

  gsm.print(topic);
  gsm.write('\r');

  delay(500);

  // ---------------------------------------------------
  // PAYLOAD
  // ---------------------------------------------------

  snprintf(command,
           sizeof(command),
           "AT+CMQTTPAYLOAD=0,%d",
           payloadLength);

  clearModem();

  Serial.print(">> ");
  Serial.println(command);

  gsm.println(command);

  start = millis();
  prompt = false;

  while (millis() - start < 10000)
  {
    while (gsm.available())
    {
      char c = gsm.read();
      Serial.write(c);

      if (c == '>')
      {
        prompt = true;
        break;
      }
    }

    if (prompt)
      break;
  }

  if (!prompt)
  {
    Serial.println();
    Serial.println("Payload prompt failed.");
    return false;
  }

  gsm.print(payload);
  gsm.write('\r');

  delay(500);

  // ---------------------------------------------------
  // PUBLISH
  // ---------------------------------------------------

  snprintf(command,
           sizeof(command),
           "AT+CMQTTPUB=0,1,60");

  clearModem();

  Serial.print(">> ");
  Serial.println(command);

  gsm.println(command);

  start = millis();

  char buffer[150];
  int index = 0;

  memset(buffer, 0, sizeof(buffer));

  while (millis() - start < 30000)
  {
    while (gsm.available())
    {
      char c = gsm.read();

      Serial.write(c);

      if (index < sizeof(buffer) - 1)
      {
        buffer[index++] = c;
        buffer[index] = '\0';
      }

      if (strstr(buffer, "+CMQTTPUB: 0,0"))
      {
        Serial.println();
        Serial.println("DATA PUBLISHED");
        return true;
      }

      if (strstr(buffer, "ERROR"))
      {
        Serial.println();
        Serial.println("MQTT publish ERROR");
        return false;
      }
    }
  }

  Serial.println();
  Serial.println("MQTT publish timeout.");

  return false;
}

// =====================================================
// SEND TEST DATA
// =====================================================

bool sendTestData()
{
  char payload[120];

  snprintf(payload,
           sizeof(payload),
           "{\"id\":\"%s\",\"status\":\"I am alive\"}",
           MQTT_CLIENT_ID);

  Serial.println();
  Serial.println("Sending data:");
  Serial.println(payload);

  return mqttPublish(MQTT_TOPIC, payload);
}

// =====================================================
// COMPLETE MQTT CONNECTION
// =====================================================

bool connectMQTT()
{
  Serial.println();
  Serial.println("================================");
  Serial.println("STARTING MQTT CONNECTION");
  Serial.println("================================");

  // MQTT START
  if (!mqttStart())
  {
    Serial.println("MQTT start failed.");
    return false;
  }

  delay(1000);

  // CLIENT ACQUIRE
  if (!mqttAcquire())
  {
    Serial.println("MQTT acquire failed.");
    mqttStop();
    return false;
  }

  delay(1000);

  // CONNECT
  if (!mqttConnect())
  {
    Serial.println("MQTT connection failed.");
    mqttStop();
    return false;
  }

  return true;
}

// =====================================================
// SETUP
// =====================================================

void setup()
{
  Serial.begin(115200);

  gsm.begin(115200);

  delay(3000);

  Serial.println();
  Serial.println("================================");
  Serial.println("A7672S MQTT TEST");
  Serial.println("================================");

  // ---------------------------------------------------
  // MODEM
  // ---------------------------------------------------

  while (!modemOK())
  {
    Serial.println("Modem not responding. Retrying...");
    delay(3000);
  }

  Serial.println("Modem OK.");

  // ---------------------------------------------------
  // SIM
  // ---------------------------------------------------

  while (!simOK())
  {
    Serial.println("SIM not ready. Retrying...");
    delay(5000);
  }

  Serial.println("SIM OK.");

  // ---------------------------------------------------
  // SIGNAL
  // ---------------------------------------------------

  while (!signalOK())
  {
    Serial.println("Signal not available. Retrying...");
    delay(5000);
  }

  // ---------------------------------------------------
  // NETWORK
  // ---------------------------------------------------

  while (!networkOK())
  {
    Serial.println("Network not registered. Retrying...");
    delay(5000);
  }

  // ---------------------------------------------------
  // INTERNET
  // ---------------------------------------------------

  while (!internetOK())
  {
    Serial.println("Internet setup failed. Retrying...");
    delay(5000);
  }

  Serial.println("Internet OK.");

  // ---------------------------------------------------
  // MQTT
  // ---------------------------------------------------

  while (!connectMQTT())
  {
    Serial.println();
    Serial.println("MQTT connection failed.");
    Serial.println("Retrying complete MQTT connection...");
    delay(5000);
  }

  // ---------------------------------------------------
  // FIRST DATA
  // ---------------------------------------------------

  while (!sendTestData())
  {
    Serial.println("First data failed.");
    Serial.println("Retrying publish...");
    delay(5000);
  }

  lastSend = millis();

  Serial.println();
  Serial.println("================================");
  Serial.println("SYSTEM READY");
  Serial.println("DATA EVERY 5 MINUTES");
  Serial.println("================================");
}

// =====================================================
// LOOP
// =====================================================

void loop()
{
  if (millis() - lastSend >= SEND_INTERVAL)
  {
    Serial.println();
    Serial.println("5 minutes elapsed.");
    Serial.println("Sending next data...");

    if (sendTestData())
    {
      lastSend = millis();
    }
    else
    {
      Serial.println("Publish failed.");
      Serial.println("Reconnecting MQTT...");

      mqttStop();

      delay(1000);

      bool connected = false;

      while (!connected)
      {
        if (connectMQTT())
        {
          connected = true;
        }
        else
        {
          Serial.println("MQTT reconnect failed. Retrying...");
          delay(5000);
        }
      }

      if (sendTestData())
      {
        lastSend = millis();
      }
    }
  }
}