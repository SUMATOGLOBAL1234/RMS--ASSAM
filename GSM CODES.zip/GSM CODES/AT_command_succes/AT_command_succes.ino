#include <SoftwareSerial.h>

// =====================================================
// A7672S <-> ARDUINO UNO
// =====================================================
//
// A7672S TX -> Arduino D2
// A7672S RX -> Arduino D3
// GND       -> Arduino GND
//
// =====================================================

#define GSM_RX 2
#define GSM_TX 3

SoftwareSerial gsm(GSM_RX, GSM_TX);


// =====================================================
// SETTINGS
// =====================================================

const char APN[] = "JioNet"; //"airtelgprs.com";

const char MQTT_SERVER[]   = "mqtt.sumato.tech";
const int  MQTT_PORT       = 1883;

const char MQTT_USERNAME[] = "user1";
const char MQTT_PASSWORD[] = "secret";

const char MQTT_CLIENT_ID[] = "RMS002";

const char MQTT_TOPIC[] = "test/device";


// =====================================================
// CLEAR MODEM BUFFER
// =====================================================

void clearModem()
{
  while (gsm.available())
    gsm.read();
}


// =====================================================
// SEND AT COMMAND
// =====================================================

bool sendAT(
  const char *cmd,
  const char *expected,
  unsigned long timeout)
{
  clearModem();

  Serial.print(">> ");
  Serial.println(cmd);

  gsm.println(cmd);

  unsigned long start = millis();

  char buffer[100];
  byte pos = 0;

  buffer[0] = '\0';

  while (millis() - start < timeout)
  {
    while (gsm.available())
    {
      char c = gsm.read();

      Serial.write(c);

      if (pos < sizeof(buffer) - 1)
      {
        buffer[pos++] = c;
        buffer[pos] = '\0';
      }

      if (strstr(buffer, expected))
        return true;

      if (strstr(buffer, "ERROR"))
        return false;
    }
  }

  Serial.println("TIMEOUT");

  return false;
}


// =====================================================
// MODEM CHECK
// =====================================================

bool modemOK()
{
  return sendAT("AT", "OK", 3000);
}


// =====================================================
// SIM CHECK
// =====================================================

bool simOK()
{
  return sendAT(
    "AT+CPIN?",
    "READY",
    5000
  );
}


// =====================================================
// NETWORK CHECK
// =====================================================

bool networkOK()
{
  clearModem();

  Serial.println(">> AT+CEREG?");

  gsm.println("AT+CEREG?");

  unsigned long start = millis();

  char buffer[100];
  byte pos = 0;

  buffer[0] = '\0';

  while (millis() - start < 5000)
  {
    while (gsm.available())
    {
      char c = gsm.read();

      Serial.write(c);

      if (pos < sizeof(buffer) - 1)
      {
        buffer[pos++] = c;
        buffer[pos] = '\0';
      }

      if (strstr(buffer, ",1") ||
          strstr(buffer, ",5"))
      {
        return true;
      }
    }
  }

  return false;
}


// =====================================================
// INTERNET
// =====================================================

bool internetOK()
{
  char cmd[70];

  Serial.println();
  Serial.println("Connecting Internet...");


  // APN
  sprintf(
    cmd,
    "AT+CGDCONT=1,\"IP\",\"%s\"",
    APN
  );

  if (!sendAT(cmd, "OK", 5000))
    return false;


  // Packet attach
  if (!sendAT(
        "AT+CGATT=1",
        "OK",
        15000))
    return false;


  // PDP activation
  if (!sendAT(
        "AT+CGACT=1,1",
        "OK",
        15000))
    return false;


  // IP address
  if (!sendAT(
        "AT+CGPADDR=1",
        "+CGPADDR:",
        5000))
    return false;


  Serial.println();
  Serial.println("INTERNET OK");

  return true;
}


// =====================================================
// MQTT START
// =====================================================

bool mqttStart()
{
  Serial.println();
  Serial.println("Starting MQTT...");


  if (!sendAT(
        "AT+CMQTTSTART",
        "OK",
        15000))
  {
    return false;
  }


  char cmd[70];

  sprintf(
    cmd,
    "AT+CMQTTACCQ=0,\"%s\",0",
    MQTT_CLIENT_ID
  );

  if (!sendAT(
        cmd,
        "OK",
        5000))
  {
    return false;
  }


  Serial.println("MQTT SERVICE READY");

  return true;
}


// =====================================================
// MQTT CONNECT
// =====================================================

bool mqttConnect()
{
  char cmd[180];

  sprintf(
    cmd,
    "AT+CMQTTCONNECT=0,\"tcp://%s:%d\",60,1,\"%s\",\"%s\"",
    MQTT_SERVER,
    MQTT_PORT,
    MQTT_USERNAME,
    MQTT_PASSWORD
  );

  Serial.println();
  Serial.println("Connecting MQTT...");

  if (!sendAT(
        cmd,
        "OK",
        30000))
  {
    Serial.println("MQTT CONNECT FAILED");
    return false;
  }


  Serial.println("MQTT CONNECT COMMAND OK");

  return true;
}


// =====================================================
// MQTT PUBLISH
// =====================================================

bool mqttPublish(
  const char *topic,
  const char *payload)
{
  char cmd[70];


  // -------------------------------
  // TOPIC
  // -------------------------------

  sprintf(
    cmd,
    "AT+CMQTTTOPIC=0,%d",
    strlen(topic)
  );

  if (!sendAT(cmd, ">", 5000))
  {
    Serial.println("TOPIC FAILED");
    return false;
  }

  gsm.print(topic);

  gsm.write('\r');

  delay(300);


  // -------------------------------
  // PAYLOAD
  // -------------------------------

  sprintf(
    cmd,
    "AT+CMQTTPAYLOAD=0,%d",
    strlen(payload)
  );

  if (!sendAT(cmd, ">", 5000))
  {
    Serial.println("PAYLOAD COMMAND FAILED");
    return false;
  }

  gsm.print(payload);

  gsm.write('\r');

  delay(300);


  // -------------------------------
  // PUBLISH
  // -------------------------------

  if (!sendAT(
        "AT+CMQTTPUB=0,1,60",
        "OK",
        15000))
  {
    Serial.println("PUBLISH FAILED");
    return false;
  }


  Serial.println();
  Serial.println("==============================");
  Serial.println("       MQTT SENT OK");
  Serial.println("==============================");

  return true;
}


// =====================================================
// UPTIME STRING (HH:MM:SS SINCE BOOT)
// =====================================================

// void getUptime(char *outBuf, size_t outSize)
// {
//   unsigned long totalSeconds = millis() / 1000UL;

//   unsigned long hours   = totalSeconds / 3600UL;
//   unsigned long minutes = (totalSeconds % 3600UL) / 60UL;
//   unsigned long seconds = totalSeconds % 60UL;

//   snprintf(
//     outBuf,
//     outSize,
//     "%02lu:%02lu:%02lu",
//     hours,
//     minutes,
//     seconds
//   );
// }


// =====================================================
// SEND MESSAGE WITH SEND TIME
// =====================================================

// bool sendMessageWithTime(const char *message)
// {
//   char timeBuf[16];
//   char payload[180];

//   getUptime(timeBuf, sizeof(timeBuf));

//   snprintf(
//     payload,
//     sizeof(payload),
//     "{\"id\":\"%s\",\"send_time\":\"%s\",\"msg\":\"%s\"}",
//     MQTT_CLIENT_ID,
//     timeBuf,
//     message
//   );

//   Serial.println();
//   Serial.print("Payload: ");
//   Serial.println(payload);

//   return mqttPublish(MQTT_TOPIC, payload);
// }

// =====================================================
// SETUP
// =====================================================

void setup()
{
  Serial.begin(9600);

  gsm.begin(9600);

  Serial.println();
  Serial.println("==============================");
  Serial.println(" A7672S + UNO MQTT TEST");
  Serial.println("==============================");

  delay(5000);


  // ===================================================
  // MODEM
  // ===================================================

  Serial.println();
  Serial.println("STEP 1: MODEM");

  while (!modemOK())
  {
    Serial.println("Waiting for modem...");
    delay(3000);
  }

  Serial.println("MODEM OK");


  // ===================================================
  // SIM
  // ===================================================

  Serial.println();
  Serial.println("STEP 2: SIM");

  while (!simOK())
  {
    Serial.println("Waiting for SIM...");
    delay(3000);
  }

  Serial.println("SIM READY");


  // ===================================================
  // SIGNAL
  // ===================================================

  Serial.println();
  Serial.println("STEP 3: SIGNAL");

  sendAT(
    "AT+CSQ",
    "OK",
    5000
  );


  // ===================================================
  // NETWORK
  // ===================================================

  Serial.println();
  Serial.println("STEP 4: NETWORK");

  while (!networkOK())
  {
    Serial.println("Waiting for network...");
    delay(5000);
  }

  Serial.println();
  Serial.println("NETWORK REGISTERED");


  // ===================================================
  // INTERNET
  // ===================================================

  Serial.println();
  Serial.println("STEP 5: INTERNET");

  while (!internetOK())
  {
    Serial.println("Internet failed.");
    delay(5000);
  }


  // ===================================================
  // MQTT START
  // ===================================================

  Serial.println();
  Serial.println("STEP 6: MQTT START");

  while (!mqttStart())
  {
    Serial.println("MQTT start failed.");
    delay(5000);
  }


  // ===================================================
  // MQTT CONNECT
  // ===================================================

  Serial.println();
  Serial.println("STEP 7: MQTT CONNECT");

  while (!mqttConnect())
  {
    Serial.println("MQTT connection failed.");
    delay(5000);
  }


  // ===================================================
  // TEST MESSAGE
  // ===================================================

  Serial.println();
  Serial.println("STEP 8: TEST PUBLISH");

  mqttPublish(
    MQTT_TOPIC,
    "Hello from RMS001 Sumit new"
  );


  Serial.println();
  Serial.println("==============================");
  Serial.println("         TEST DONE");
  Serial.println("==============================");
}


// =====================================================
// LOOP
// =====================================================

void loop()
{
  mqttPublish(
    MQTT_TOPIC,
    "Hello from RMS001 Sumit new"
  );
  delay(5 * 60 * 1000UL);
}
