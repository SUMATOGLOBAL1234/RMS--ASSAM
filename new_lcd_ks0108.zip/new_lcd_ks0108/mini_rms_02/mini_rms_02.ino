#include "pinmap.h"
#include "config.h"
#include "globals.h"

#include "gsm_gps_module.h"
#include "RTC.h"
#include "ultrasonic.h"
#include "StatusLED.h"
#include "motor_status.h"
#include "lcd.h"
#include "mqttmanager.h"
#include "reboot.h"
//#include "vfd_uart.h"

// OTA over Wi-Fi is intentionally disabled in this cellular build.

// =====================================================
// SETUP
// =====================================================
void setup() {
  Serial.begin(115200);

  delay(500);

  Serial.println();
  Serial.println("==============================");
  Serial.println("MINI RMS - CELLULAR VERSION");
  Serial.println("A7672S GNSS + GSM + MQTT");
  Serial.println("==============================");

  // =================================================
  // HARDWARE
  // =================================================
  initRTC();
  initScheduledReboot();
  initUltrasonic();
  // Initialize status LEDs
  initStatusLEDs();
  initMotorStatus();
  initGPS();

  // =================================================
  // LCD
  // =================================================
  initLCD();

  // =================================================
  // A7672S NETWORK + GNSS + MQTT
  // =================================================
  initGSM();
  initMQTT();

  // Start the ESP32 task watchdog only after all lengthy setup
  // operations have completed. This watchdog resets the ESP32
  // if the main loop becomes stuck.
  initRebootWatchdog();

  // =================================================
  // INITIAL DATA / LCD
  // =================================================
  updateRTC();
  updateLCD();
  //initVFD();

  Serial.println();
  Serial.println("==============================");
  Serial.println("MINI RMS READY");
  Serial.println("A7672S -> MQTT TRANSPORT ACTIVE");
  Serial.println("==============================");
}

// =====================================================
// MAIN LOOP
// =====================================================
void loop() {
  // Feed the watchdog first. If the firmware gets stuck anywhere
  // in the loop, this line is no longer reached and the ESP32
  // automatically resets after the watchdog timeout.
  feedRebootWatchdog();

  // =================================================
  // DAILY AUTOMATIC REBOOT - 12:01 AM
  // =================================================
  checkScheduledReboot();

  // =================================================
  // CELLULAR / MQTT
  // =================================================
  checkMQTT();

  // =================================================
  // RTC DISPLAY VARIABLES
  // =================================================
  if (millis() - rtcTimer >= RTC_INTERVAL) {
    rtcTimer = millis();
    updateRTC();
  }

  // =================================================
  // ULTRASONIC
  // =================================================
  if (millis() - ultraTimer >= ULTRASONIC_INTERVAL) {
    ultraTimer = millis();
    updateUltrasonic();
  }

  // Update internet and depth sensor LEDs
  updateStatusLEDs();

  // =================================================
  // MOTOR
  // =================================================
  updateMotorStatus();


  //updateVFD();

  // =================================================
  // LCD
  // =================================================
  updateLCD();

  // =================================================
  // MQTT LIVE DATA
  // =================================================
  checkMQTTLiveChanges();

  yield();
}
