#ifndef ULTRASONIC_H
#define ULTRASONIC_H

#include <ArduinoJson.h>
#include <HardwareSerial.h>
#include <math.h>

#include "globals.h"
#include "pinmap.h"
#include "config.h"

// =====================================================
// SENSOR CONFIGURATION
// =====================================================

#define ULTRASONIC_TRIGGER_PIN 25
#define ULTRASONIC_RX_PIN      33

#define ULTRASONIC_BAUD        115200

// =====================================================
// DISTANCE LIMITS
// =====================================================

#define MIN_DISTANCE 80
#define MAX_DISTANCE 8000

// =====================================================
// BACKGROUND FILTER
// =====================================================
//
// Approximately 4.55 minutes of filtering.
//
// 500 samples / approximately 273 seconds
// = approximately 546 ms per filter sample.
//
// The sensor itself can be triggered faster, but only
// one valid reading is added to the background filter
// approximately every 546 ms.
//
// =====================================================

#define FILTER_MAX_SAMPLES       500
#define FILTER_WINDOW_MS         273000UL
#define FILTER_SAMPLE_INTERVAL   (FILTER_WINDOW_MS / FILTER_MAX_SAMPLES)

// Maximum allowed deviation used during the
// first-stage outlier rejection.
#define FILTER_MAX_DEVIATION_MM  150

// Minimum number of samples required before
// producing a filtered result.
#define FILTER_MIN_SAMPLES       20

// =====================================================
// SENSOR TIMEOUT
// =====================================================

#define SENSOR_TIMEOUT 5000UL

// =====================================================
// TRIGGER TIMING
// =====================================================

#define SENSOR_TRIGGER_LOW_US          500UL
#define SENSOR_RESPONSE_TIMEOUT_MS     20UL
#define SENSOR_TRIGGER_INTERVAL_MS     50UL

// =====================================================
// SENSOR STATE
// =====================================================

enum UltrasonicState {
    ULTRA_IDLE = 0,
    ULTRA_TRIGGER_LOW,
    ULTRA_WAITING_RESPONSE
};

UltrasonicState ultrasonicState = ULTRA_IDLE;

// =====================================================
// TIMERS
// =====================================================

unsigned long ultrasonicTriggerTimer = 0;
unsigned long ultrasonicResponseStart = 0;
unsigned long ultrasonicTriggerStartMicros = 0;

// =====================================================
// UART FRAME
// =====================================================

uint8_t ultraFrame[4];
uint8_t ultraIndex = 0;

// =====================================================
// SENSOR DATA
// =====================================================

unsigned long lastValidReading = 0;

uint16_t rawDistanceMM = 0;

// Final filtered depth used by MQTT/LCD.
uint16_t filteredDepthMM = 0;

// =====================================================
// BACKGROUND FILTER BUFFER
// =====================================================

uint16_t filterSamples[FILTER_MAX_SAMPLES];

uint16_t filterSampleCount = 0;

unsigned long filterLastSampleTime = 0;

unsigned long filterWindowStartTime = 0;

bool filterResultValid = false;

// =====================================================
// FILTER RESULT
// =====================================================

uint16_t filterResult = 0;

// =====================================================
// INITIALIZATION
// =====================================================

void initUltrasonic()
{
    // -------------------------------------------------
    // Trigger
    // -------------------------------------------------

    pinMode(
        ULTRASONIC_TRIGGER_PIN,
        OUTPUT
    );

    // Sensor idle state
    digitalWrite(
        ULTRASONIC_TRIGGER_PIN,
        HIGH
    );

    // -------------------------------------------------
    // UART
    // -------------------------------------------------
    //
    // GPIO33 = ESP32 RX
    //
    // No ESP32 TX required.
    //
    // -------------------------------------------------

    Ultra.begin(
        ULTRASONIC_BAUD,
        SERIAL_8N1,
        ULTRASONIC_RX_PIN,
        -1
    );

    // -------------------------------------------------
    // Clear UART
    // -------------------------------------------------

    while (Ultra.available()) {
        Ultra.read();
    }

    // -------------------------------------------------
    // Reset filter
    // -------------------------------------------------

    for (
        uint16_t i = 0;
        i < FILTER_MAX_SAMPLES;
        i++
    ) {
        filterSamples[i] = 0;
    }

    filterSampleCount = 0;

    filterLastSampleTime = millis();

    filterWindowStartTime = millis();

    filterResultValid = false;

    filterResult = 0;

    // -------------------------------------------------
    // Reset data
    // -------------------------------------------------

    distanceMM = 0;

    depthMM = 0;

    rawDistanceMM = 0;

    filteredDepthMM = 0;

    lastValidReading = millis();

    ultrasonicTriggerTimer = millis();

    ultrasonicState = ULTRA_IDLE;

    ultraIndex = 0;

    // -------------------------------------------------
    // Debug
    // -------------------------------------------------

    Serial.println(
        "Ultrasonic initialized"
    );

    Serial.println(
        "Trigger GPIO : 25"
    );

    Serial.println(
        "UART RX GPIO : 33"
    );

    Serial.println(
        "UART Baud    : 115200"
    );

    Serial.println(
        "Filter       : 500 samples / 4.55 minutes"
    );

    Serial.print(
        "Filter sample interval: "
    );

    Serial.print(
        FILTER_SAMPLE_INTERVAL
    );

    Serial.println(
        " ms"
    );
}

// =====================================================
// RESET FILTER WINDOW
// =====================================================

void resetUltrasonicFilter()
{
    filterSampleCount = 0;

    filterLastSampleTime = millis();

    filterWindowStartTime = millis();

    filterResultValid = false;

    filterResult = 0;
}

// =====================================================
// SIMPLE SORT
// =====================================================

void sortFilterSamples(
    uint16_t *data,
    uint16_t count
)
{
    for (
        uint16_t i = 0;
        i < count;
        i++
    ) {
        for (
            uint16_t j = i + 1;
            j < count;
            j++
        ) {
            if (
                data[j] < data[i]
            ) {
                uint16_t temp = data[i];

                data[i] = data[j];

                data[j] = temp;
            }
        }
    }
}

// =====================================================
// CALCULATE ROBUST FILTER RESULT
// =====================================================
//
// Processing:
//
// 1. Sort collected samples.
// 2. Find median.
// 3. Reject large deviations from median.
// 4. Find the densest/dependent cluster.
// 5. Average the dominant cluster.
// 6. Use result as final depth.
//
// =====================================================

bool calculateUltrasonicFilter()
{
    if (
        filterSampleCount < FILTER_MIN_SAMPLES
    ) {
        return false;
    }

    // -------------------------------------------------
    // Copy samples
    // -------------------------------------------------

    static uint16_t sortedSamples[FILTER_MAX_SAMPLES];

    for (
        uint16_t i = 0;
        i < filterSampleCount;
        i++
    ) {
        sortedSamples[i] =
            filterSamples[i];
    }

    // -------------------------------------------------
    // Sort
    // -------------------------------------------------

    sortFilterSamples(
        sortedSamples,
        filterSampleCount
    );

    // -------------------------------------------------
    // Median
    // -------------------------------------------------

    uint16_t median;

    if (
        filterSampleCount % 2 == 0
    ) {
        uint32_t a =
            sortedSamples[
                (filterSampleCount / 2) - 1
            ];

        uint32_t b =
            sortedSamples[
                filterSampleCount / 2
            ];

        median =
            (uint16_t)((a + b) / 2);
    }
    else {
        median =
            sortedSamples[
                filterSampleCount / 2
            ];
    }

    // -------------------------------------------------
    // First outlier rejection
    // -------------------------------------------------
    //
    // Keep values reasonably close to the median.
    //
    // This removes jumps such as:
    //
    // 960
    // 1000
    // 1145
    // 960
    //
    // when 1145 is an isolated reading.
    //
    // -------------------------------------------------

    uint16_t validCount = 0;

    uint32_t validSum = 0;

    for (
        uint16_t i = 0;
        i < filterSampleCount;
        i++
    ) {
        int32_t difference =
            (int32_t)sortedSamples[i] -
            (int32_t)median;

        if (difference < 0) {
            difference = -difference;
        }

        if (
            difference <= FILTER_MAX_DEVIATION_MM
        ) {
            validSum +=
                sortedSamples[i];

            validCount++;
        }
    }

    // -------------------------------------------------
    // Not enough consistent samples
    // -------------------------------------------------

    if (
        validCount < FILTER_MIN_SAMPLES
    ) {
        Serial.println(
            "Ultrasonic filter: insufficient consistent samples"
        );

        return false;
    }

    // -------------------------------------------------
    // Final dominant-cluster average
    // -------------------------------------------------

    uint16_t result =
        (uint16_t)(
            validSum / validCount
        );

    // -------------------------------------------------
    // Range safety
    // -------------------------------------------------

    if (
        result < MIN_DISTANCE ||
        result > MAX_DISTANCE
    ) {
        return false;
    }

    // -------------------------------------------------
    // Store final result
    // -------------------------------------------------

    filterResult = result;

    filterResultValid = true;

    return true;
}

// =====================================================
// ADD FILTER SAMPLE
// =====================================================

void addUltrasonicFilterSample(
    uint16_t distance
)
{
    unsigned long now = millis();

    // -------------------------------------------------
    // Limit filter sampling rate
    // -------------------------------------------------

    if (
        now - filterLastSampleTime <
        FILTER_SAMPLE_INTERVAL
    ) {
        return;
    }

    filterLastSampleTime = now;

    // -------------------------------------------------
    // Add sample
    // -------------------------------------------------

    if (
        filterSampleCount <
        FILTER_MAX_SAMPLES
    ) {
        filterSamples[
            filterSampleCount
        ] = distance;

        filterSampleCount++;
    }

    // -------------------------------------------------
    // Debug
    // -------------------------------------------------

    Serial.print(
        "Filter sample "
    );

    Serial.print(
        filterSampleCount
    );

    Serial.print(
        "/"
    );

    Serial.print(
        FILTER_MAX_SAMPLES
    );

    Serial.print(
        ": "
    );

    Serial.print(
        distance
    );

    Serial.println(
        " mm"
    );

    // -------------------------------------------------
    // Complete filter window
    // -------------------------------------------------

    if (
        filterSampleCount >=
        FILTER_MAX_SAMPLES
    ) {
        Serial.println();
        Serial.println(
            "========== ULTRASONIC FILTER =========="
        );

        if (
            calculateUltrasonicFilter()
        ) {
            filteredDepthMM =
                filterResult;

            distanceMM =
                filteredDepthMM;

            depthMM =
                filteredDepthMM;

            Serial.print(
                "Filtered depth: "
            );

            Serial.print(
                filteredDepthMM
            );

            Serial.println(
                " mm"
            );

            Serial.println(
                "========================================"
            );
        }
        else {
            Serial.println(
                "Ultrasonic filter: result invalid"
            );
        }

        // -------------------------------------------------
        // Start a new background window
        // -------------------------------------------------

        resetUltrasonicFilter();
    }
}

// =====================================================
// RESET FRAME
// =====================================================

void resetUltrasonicFrame()
{
    ultraIndex = 0;
}

// =====================================================
// READ FRAME
// =====================================================

bool readUltrasonicFrame(
    uint16_t &distance
)
{
    while (
        Ultra.available()
    ) {
        uint8_t b =
            Ultra.read();

        // ---------------------------------------------
        // Find header
        // ---------------------------------------------

        if (
            ultraIndex == 0
        ) {
            if (
                b != 0xFF
            ) {
                continue;
            }
        }

        ultraFrame[
            ultraIndex++
        ] = b;

        // ---------------------------------------------
        // Need four bytes
        // ---------------------------------------------

        if (
            ultraIndex < 4
        ) {
            continue;
        }

        // ---------------------------------------------
        // Frame complete
        // ---------------------------------------------

        ultraIndex = 0;

        // ---------------------------------------------
        // Checksum
        // ---------------------------------------------

        uint8_t checksum =
            (
                ultraFrame[0] +
                ultraFrame[1] +
                ultraFrame[2]
            ) & 0xFF;

        if (
            checksum !=
            ultraFrame[3]
        ) {
            continue;
        }

        // ---------------------------------------------
        // Distance
        // ---------------------------------------------

        distance =
            (
                (uint16_t)ultraFrame[1] << 8
            ) |
            ultraFrame[2];

        // ---------------------------------------------
        // Range
        // ---------------------------------------------

        if (
            distance < MIN_DISTANCE ||
            distance > MAX_DISTANCE
        ) {
            continue;
        }

        return true;
    }

    return false;
}

// =====================================================
// START TRIGGER
// =====================================================

void startUltrasonicTrigger()
{
    // -------------------------------------------------
    // Flush old data
    // -------------------------------------------------

    while (
        Ultra.available()
    ) {
        Ultra.read();
    }

    resetUltrasonicFrame();

    // -------------------------------------------------
    // Start trigger pulse
    // -------------------------------------------------

    digitalWrite(
        ULTRASONIC_TRIGGER_PIN,
        LOW
    );

    ultrasonicTriggerStartMicros =
        micros();

    ultrasonicState =
        ULTRA_TRIGGER_LOW;
}

// =====================================================
// UPDATE ULTRASONIC
// =====================================================
//
// NON-BLOCKING
//
// =====================================================

void updateUltrasonic()
{
    unsigned long now =
        millis();

    unsigned long nowMicros =
        micros();

    // =================================================
    // TRIGGER LOW
    // =================================================

    if (
        ultrasonicState ==
        ULTRA_TRIGGER_LOW
    ) {
        if (
            nowMicros -
            ultrasonicTriggerStartMicros >=
            SENSOR_TRIGGER_LOW_US
        ) {
            digitalWrite(
                ULTRASONIC_TRIGGER_PIN,
                HIGH
            );

            ultrasonicResponseStart =
                now;

            ultrasonicState =
                ULTRA_WAITING_RESPONSE;
        }

        return;
    }

    // =================================================
    // WAITING FOR RESPONSE
    // =================================================

    if (
        ultrasonicState ==
        ULTRA_WAITING_RESPONSE
    ) {
        uint16_t distance;

        if (
            readUltrasonicFrame(
                distance
            )
        ) {
            // -----------------------------------------
            // Raw
            // -----------------------------------------

            rawDistanceMM =
                distance;

            // -----------------------------------------
            // Valid sensor reading
            // -----------------------------------------

            lastValidReading =
                now;

            // -----------------------------------------
            // Add to background filter
            // -----------------------------------------

            addUltrasonicFilterSample(
                distance
            );

            // -----------------------------------------
            // Debug
            // -----------------------------------------

            Serial.print(
                "Raw: "
            );

            Serial.print(
                distance
            );

            Serial.print(
                " mm"
            );

            Serial.println();

            // -----------------------------------------
            // Complete
            // -----------------------------------------

            ultrasonicState =
                ULTRA_IDLE;

            ultrasonicTriggerTimer =
                now;

            return;
        }

        // ---------------------------------------------
        // Response timeout
        // ---------------------------------------------

        if (
            now -
            ultrasonicResponseStart >=
            SENSOR_RESPONSE_TIMEOUT_MS
        ) {
            ultrasonicState =
                ULTRA_IDLE;

            ultrasonicTriggerTimer =
                now;

            resetUltrasonicFrame();

            return;
        }

        return;
    }

    // =================================================
    // IDLE
    // =================================================

    if (
        ultrasonicState ==
        ULTRA_IDLE
    ) {
        if (
            now -
            ultrasonicTriggerTimer >=
            SENSOR_TRIGGER_INTERVAL_MS
        ) {
            startUltrasonicTrigger();
        }
    }

    // =================================================
    // SENSOR TIMEOUT
    // =================================================

    if (
        now -
        lastValidReading >
        SENSOR_TIMEOUT
    ) {
        distanceMM = 0;

        depthMM = 0;

        filteredDepthMM = 0;

        filterResultValid = false;
    }
}

// =====================================================
// MQTT DATA
// =====================================================
//
// IMPORTANT:
//
// This keeps the exact MQTT ultrasonic structure:
//
// "ultrasonic": {
//     "depth": 1017,
//     "unit": "mm",
//     "status": "OK"
// }
//
// No additional fields are added.
// =====================================================

void addUltrasonicData(
    JsonDocument &doc
)
{
    bool valid =
        (
            millis() -
            lastValidReading <=
            SENSOR_TIMEOUT
        );

    doc["ultrasonic"]["depth"] =
        round(depthMM);

    doc["ultrasonic"]["unit"] =
        "mm";

    doc["ultrasonic"]["status"] =
        valid
        ? "OK"
        : "NO_DATA";
}

#endif