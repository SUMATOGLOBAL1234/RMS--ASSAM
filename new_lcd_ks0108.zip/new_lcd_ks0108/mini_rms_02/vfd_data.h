// #ifndef VFD_UART_H
// #define VFD_UART_H

// #include <Arduino.h>
// #include <ArduinoJson.h>

// // =====================================================
// // STM32 / VFD UART
// // =====================================================
// //
// // ESP32 GPIO25 RX  <- STM32 TX
// // ESP32 GPIO33 TX  -> STM32 RX
// //
// // Baud: 9600
// // Format: 8N1
// //
// // STM32 sends one JSON object per line.
// //
// // ESP32 can send:
// //      CMD:ON\r\n
// //      CMD:OFF\r\n
// //
// // =====================================================

// #define VFD_RX_PIN 25
// #define VFD_TX_PIN 33
// #define VFD_BAUD   9600

// HardwareSerial VFDSerial(1);


// // =====================================================
// // VFD DATA
// // =====================================================

// struct VFDData
// {
//   String status;

//   float vdc;
//   float idc;
//   float vout;
//   float iout;
//   float freq;
//   float temp;
//   float pwr;
//   float lpm;

//   int faultCode;
//   String faultMsg;

//   float s_hr;
//   float s_kl;
//   float s_kwh;

//   float t_hr;
//   float t_kl;
//   float t_kwh;

//   bool valid;
// };

// VFDData vfd;


// // =====================================================
// // INITIALIZE VFD UART
// // =====================================================

// void initVFD()
// {
//   VFDSerial.begin(
//     VFD_BAUD,
//     SERIAL_8N1,
//     VFD_RX_PIN,
//     VFD_TX_PIN
//   );

//   // ---------------------------------------------------
//   // DEFAULT VFD STATE
//   // ---------------------------------------------------

//   vfd.status = "COMM_LOSS";

//   vfd.vdc  = 0.0;
//   vfd.idc  = 0.0;
//   vfd.vout = 0.0;
//   vfd.iout = 0.0;
//   vfd.freq = 0.0;
//   vfd.temp = 0.0;
//   vfd.pwr  = 0.0;
//   vfd.lpm  = 0.0;

//   vfd.faultCode = 1000;
//   vfd.faultMsg  = "MODBUS LOSS";

//   vfd.s_hr  = 0.0;
//   vfd.s_kl  = 0.0;
//   vfd.s_kwh = 0.0;

//   vfd.t_hr  = 0.0;
//   vfd.t_kl  = 0.0;
//   vfd.t_kwh = 0.0;

//   vfd.valid = false;


//   // ---------------------------------------------------
//   // DEBUG
//   // ---------------------------------------------------

//   Serial.println();
//   Serial.println(F("======================================"));
//   Serial.println(F("VFD UART INITIALIZED"));
//   Serial.println(F("======================================"));

//   Serial.print(F("RX: GPIO"));
//   Serial.println(VFD_RX_PIN);

//   Serial.print(F("TX: GPIO"));
//   Serial.println(VFD_TX_PIN);

//   Serial.print(F("BAUD: "));
//   Serial.println(VFD_BAUD);
// }


// // =====================================================
// // REMOTE VFD ON
// // =====================================================
// //
// // Called when MQTT command payload is:
// //      ON
// //
// // Sends to STM32:
// //      CMD:ON\r\n
// //
// // =====================================================

// void sendVFDOn()
// {
//   VFDSerial.print(F("CMD:ON\r\n"));

//   Serial.println();
//   Serial.println(F("======================================"));
//   Serial.println(F("VFD REMOTE COMMAND"));
//   Serial.println(F("COMMAND: ON"));
//   Serial.println(F("SENT: CMD:ON"));
//   Serial.println(F("======================================"));
// }


// // =====================================================
// // REMOTE VFD OFF
// // =====================================================
// //
// // Called when MQTT command payload is:
// //      OFF
// //
// // Sends to STM32:
// //      CMD:OFF\r\n
// //
// // =====================================================

// void sendVFDOff()
// {
//   VFDSerial.print(F("CMD:OFF\r\n"));

//   Serial.println();
//   Serial.println(F("======================================"));
//   Serial.println(F("VFD REMOTE COMMAND"));
//   Serial.println(F("COMMAND: OFF"));
//   Serial.println(F("SENT: CMD:OFF"));
//   Serial.println(F("======================================"));
// }


// // =====================================================
// // SEND VFD COMMAND FROM STRING
// // =====================================================
// //
// // This is useful for MQTT.
// //
// // Payload:
// //      ON
// //      OFF
// //
// // =====================================================

// bool processVFDCommand(String command)
// {
//   command.trim();
//   command.toUpperCase();

//   if (command == "ON")
//   {
//     sendVFDOn();
//     return true;
//   }

//   if (command == "OFF")
//   {
//     sendVFDOff();
//     return true;
//   }

//   Serial.print(F("UNKNOWN VFD COMMAND: "));
//   Serial.println(command);

//   return false;
// }


// // =====================================================
// // PARSE VFD JSON
// // =====================================================

// bool parseVFDData(const String &json)
// {
//   StaticJsonDocument<1024> doc;

//   DeserializationError error =
//     deserializeJson(doc, json);

//   if (error)
//   {
//     Serial.print(F("VFD JSON ERROR: "));
//     Serial.println(error.c_str());

//     return false;
//   }


//   // ---------------------------------------------------
//   // STATUS
//   // ---------------------------------------------------

//   vfd.status =
//     doc["status"] | "COMM_LOSS";


//   // ---------------------------------------------------
//   // ELECTRICAL
//   // ---------------------------------------------------

//   vfd.vdc =
//     doc["vdc"] | 0.0;

//   vfd.idc =
//     doc["idc"] | 0.0;

//   vfd.vout =
//     doc["vout"] | 0.0;

//   vfd.iout =
//     doc["iout"] | 0.0;

//   vfd.freq =
//     doc["freq"] | 0.0;


//   // ---------------------------------------------------
//   // TEMPERATURE / POWER / FLOW
//   // ---------------------------------------------------

//   vfd.temp =
//     doc["temp"] | 0.0;

//   vfd.pwr =
//     doc["pwr"] | 0.0;

//   vfd.lpm =
//     doc["lpm"] | 0.0;


//   // ---------------------------------------------------
//   // FAULT
//   // ---------------------------------------------------

//   vfd.faultCode =
//     doc["fault_code"] | 1000;

//   vfd.faultMsg =
//     doc["fault_msg"] | "MODBUS LOSS";


//   // ---------------------------------------------------
//   // SESSION
//   // ---------------------------------------------------

//   vfd.s_hr =
//     doc["s_hr"] | 0.0;

//   vfd.s_kl =
//     doc["s_kl"] | 0.0;

//   vfd.s_kwh =
//     doc["s_kwh"] | 0.0;


//   // ---------------------------------------------------
//   // TOTAL
//   // ---------------------------------------------------

//   vfd.t_hr =
//     doc["t_hr"] | 0.0;

//   vfd.t_kl =
//     doc["t_kl"] | 0.0;

//   vfd.t_kwh =
//     doc["t_kwh"] | 0.0;


//   // ---------------------------------------------------
//   // VALID DATA
//   // ---------------------------------------------------

//   vfd.valid = true;

//   return true;
// }


// // =====================================================
// // READ VFD UART
// // =====================================================

// void updateVFD()
// {
//   static String rxBuffer = "";

//   while (VFDSerial.available())
//   {
//     char c = VFDSerial.read();


//     // -------------------------------------------------
//     // END OF JSON MESSAGE
//     // -------------------------------------------------

//     if (c == '\n')
//     {
//       rxBuffer.trim();

//       if (rxBuffer.length() > 0)
//       {
//         Serial.println();
//         Serial.println(F("======================================"));
//         Serial.println(F("VFD DATA RECEIVED"));
//         Serial.println(F("======================================"));

//         Serial.println(rxBuffer);


//         // ---------------------------------------------
//         // PARSE JSON
//         // ---------------------------------------------

//         if (parseVFDData(rxBuffer))
//         {
//           Serial.println(F("VFD JSON PARSED OK"));

//           Serial.print(F("Status      : "));
//           Serial.println(vfd.status);

//           Serial.print(F("VDC         : "));
//           Serial.println(vfd.vdc, 2);

//           Serial.print(F("IDC         : "));
//           Serial.println(vfd.idc, 2);

//           Serial.print(F("VOUT        : "));
//           Serial.println(vfd.vout, 2);

//           Serial.print(F("IOUT        : "));
//           Serial.println(vfd.iout, 2);

//           Serial.print(F("Frequency   : "));
//           Serial.println(vfd.freq, 2);

//           Serial.print(F("Temperature : "));
//           Serial.println(vfd.temp, 1);

//           Serial.print(F("Power       : "));
//           Serial.println(vfd.pwr, 1);

//           Serial.print(F("LPM         : "));
//           Serial.println(vfd.lpm, 1);

//           Serial.print(F("Fault Code  : "));
//           Serial.println(vfd.faultCode);

//           Serial.print(F("Fault       : "));
//           Serial.println(vfd.faultMsg);

//           Serial.print(F("Session HR  : "));
//           Serial.println(vfd.s_hr, 2);

//           Serial.print(F("Session KL  : "));
//           Serial.println(vfd.s_kl, 2);

//           Serial.print(F("Session kWh : "));
//           Serial.println(vfd.s_kwh, 2);

//           Serial.print(F("Total HR    : "));
//           Serial.println(vfd.t_hr, 2);

//           Serial.print(F("Total KL    : "));
//           Serial.println(vfd.t_kl, 2);

//           Serial.print(F("Total kWh   : "));
//           Serial.println(vfd.t_kwh, 2);
//         }
//         else
//         {
//           Serial.println(F("VFD JSON PARSE FAILED"));
//         }
//       }

//       // Clear buffer for next JSON
//       rxBuffer = "";
//     }


//     // -------------------------------------------------
//     // STORE CHARACTER
//     // -------------------------------------------------

//     else if (c != '\r')
//     {
//       // Prevent runaway buffer
//       if (rxBuffer.length() < 1200)
//       {
//         rxBuffer += c;
//       }
//       else
//       {
//         Serial.println(F("VFD RX BUFFER OVERFLOW"));
//         rxBuffer = "";
//       }
//     }
//   }
// }

// #endif