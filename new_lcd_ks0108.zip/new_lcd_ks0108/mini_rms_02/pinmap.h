#ifndef PINMAP_H
#define PINMAP_H

//==============================
// A7672S GSM/GNSS (UART2)
//==============================
#define GSM_RX_PIN 16
#define GSM_TX_PIN 17

//==============================
// Ultrasonic (UART1)
//==============================
#define ULTRASONIC_TRIGGER_PIN 25
#define ULTRASONIC_RX_PIN      33

//==============================
// DS1302 RTC
//==============================
#define RTC_RST_PIN 32
#define RTC_DAT_PIN 21
#define RTC_CLK_PIN 22

//==============================
// RS485
//==============================
// #define RS485_RX_PIN 14  // RO
// #define RS485_TX_PIN 27  // DI
// #define RS485_DE_RE_PIN 26


//==============================
// Relay Pin
//==============================
#define Relay_1 18
#define Relay_2 19

//==============================
// LCD (ST7920 Serial Mode)
//==============================
// #define LCD_DATA_PIN          23      // SID
// #define LCD_CLOCK_PIN         13      // SCLK
// #define LCD_CS_PIN            5       // E / CS
// #define LCD_RESET_PIN         4

//==============================
// MOTOR DETECTION
//==============================

#define MOTOR_STATUS_PIN 27


#endif