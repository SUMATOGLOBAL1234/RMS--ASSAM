#ifndef RTC_H
#define RTC_H

#include "globals.h"
#include "pinmap.h"
#include "config.h"

// =====================================================
// RTC
// =====================================================
// Wi-Fi/NTP has been removed. The DS1302 remains the local
// timekeeper. The A7672S GNSS UTC date/time can be used as
// the future synchronization source without requiring Wi-Fi.
// =====================================================

bool rtcInitialSyncDone = false;
unsigned long rtcSyncTimer = 0;

void updateRTC() {
  Time t = rtc.time();

  char dateBuffer[20];
  char timeBuffer[20];

  snprintf(dateBuffer, sizeof(dateBuffer),
           "%04d-%02d-%02d", t.yr, t.mon, t.date);
  snprintf(timeBuffer, sizeof(timeBuffer),
           "%02d:%02d:%02d", t.hr, t.min, t.sec);

  rtcDate = String(dateBuffer);
  rtcTime = String(timeBuffer);
}

void initRTC() {
  rtc.writeProtect(false);
  rtc.halt(false);

  // Keep the existing DS1302 time unless it is manually set here.
  updateRTC();
  ntpTimeValid = false;

  Serial.println("RTC initialized.");
  Serial.print("RTC Date: "); Serial.println(rtcDate);
  Serial.print("RTC Time: "); Serial.println(rtcTime);
}

// Compatibility function: retained so the main loop structure does
// not need another network dependency. No Wi-Fi/NTP is used anymore.
void checkRTCInternetSync() {
  // GNSS time synchronization can be added here later if required.
}

String getTime12Hour() {
  Time now = rtc.time();
  int hour = now.hr;
  String ampm = "AM";

  if (hour >= 12) ampm = "PM";
  hour %= 12;
  if (hour == 0) hour = 12;

  char buffer[20];
  snprintf(buffer, sizeof(buffer),
           "%02d:%02d:%02d %s", hour, now.min, now.sec, ampm.c_str());
  return String(buffer);
}

#endif
