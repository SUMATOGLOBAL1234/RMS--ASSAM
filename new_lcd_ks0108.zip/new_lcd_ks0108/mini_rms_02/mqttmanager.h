#ifndef MQTT_MANAGER_H
#define MQTT_MANAGER_H

#include <ArduinoJson.h>
#include <math.h>

#include "globals.h"
#include "config.h"
#include "gsm_gps_module.h"

extern int gsmRSSI;
extern String gsmIPAddress;

// =====================================================
// DATA FUNCTION DECLARATIONS
// =====================================================
void addGPSData(JsonDocument &doc);
void addRTCData(JsonDocument &doc);
void addUltrasonicData(JsonDocument &doc);
void addMotorData(JsonDocument &doc);
void addElectricalData(JsonDocument &doc);

bool mqttInitialized = false;

// =====================================================
// MQTT INIT
// =====================================================
void initMQTT()
{
    mqttInitialized = true;
    Serial.println("MQTT: A7672S cooperative transport initialized");
    Serial.println("MQTT: only LIVE payloads are transmitted");
}

// =====================================================
// BACKGROUND MQTT TASK
// =====================================================
void checkMQTT()
{
    if (!mqttInitialized)
        return;

    gsmTask();
}

// =====================================================
// DEVICE STATUS
// =====================================================
void addDeviceStatus(JsonDocument &doc)
{
    doc["device"] = MQTT_CLIENT_ID;
    doc["wifi"] = cellularConnected;
    doc["mqtt"] = mqttConnected;
    doc["rssi"] = gsmRSSI;
    doc["ip"] = gsmIPAddress;
    doc["uptime_seconds"] = millis() / 1000UL;

}

// =====================================================
// RTC DATA
// =====================================================
void addRTCData(JsonDocument &doc)
{
    doc["rtc"]["date"] = rtcDate;
    doc["rtc"]["time"] = rtcTime;
    doc["rtc"]["ntp_valid"] = ntpTimeValid;
}

// =====================================================
// BUILD THE EXISTING SINGLE LIVE PAYLOAD
// =====================================================
// This is intentionally the same payload composition used by
// the project. No ONLINE/OFFLINE message is generated.
// =====================================================
String buildLivePayload()
{
    StaticJsonDocument<4096> doc;

    doc["event"] = "LIVE";

    addDeviceStatus(doc);
    addGPSData(doc);
    addRTCData(doc);
    addUltrasonicData(doc);
    addMotorData(doc);
    addElectricalData(doc);

    String payload;
    payload.reserve(4096);
    serializeJson(doc, payload);

    return payload;
}

// =====================================================
// COMPATIBILITY API
// =====================================================
// Motor event code from the old project can call this, but the
// cellular transport intentionally sends LIVE only.
// =====================================================
void publishAllData(const char *event)
{
    if (event && strcmp(event, "LIVE") == 0)
    {
        Serial.println("MQTT: LIVE is scheduled by gsmTask() every 5 minutes");
    }
    else
    {
        Serial.print("MQTT: ignoring non-LIVE event: ");
        Serial.println(event ? event : "NULL");
    }
}

void publishLiveData()
{
    // The actual publish is owned by the cooperative GSM state machine.
    Serial.println("MQTT: LIVE publish is handled by gsmTask()");
}

void checkMQTTLiveChanges()
{
    // No independent timer here. The GSM/GNSS state machine owns the
    // absolute 5-minute LIVE schedule so a missed transmission does not
    // shift the following 5-minute boundary.
}

// =====================================================
// MQTT COMMAND PROCESSING
// =====================================================
void processMQTTCommand(String command)
{
    command.trim();
    Serial.print("MQTT command ignored in LIVE-only mode: ");
    Serial.println(command);
}

#endif
