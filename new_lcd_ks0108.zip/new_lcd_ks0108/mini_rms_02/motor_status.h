
#ifndef MOTOR_STATUS_H
#define MOTOR_STATUS_H

#include "globals.h"
#include "pinmap.h"
#include "config.h"

#include <ArduinoJson.h>

// =====================================================
// MQTT FUNCTION
// =====================================================

void publishAllData(const char *event);

// =====================================================
// MOTOR PIN
// =====================================================
//
// MOTOR_STATUS_PIN should already exist in pinmap.h.
//
// GPIO34 is input-only and has NO internal pull-up/
// pull-down resistor.
// =====================================================

#ifndef MOTOR_STATUS_PIN
#define MOTOR_STATUS_PIN 27
#endif

// =====================================================
// INTERNAL MOTOR STATE
// =====================================================

bool motorStatusInitialized = false;

// Start of current motor session
unsigned long motorSessionStartMillis = 0;

// Start of current day's active motor segment
unsigned long motorDaySegmentStartMillis = 0;

// Date currently being tracked
String motorRuntimeDate = "";

// =====================================================
// MQTT EVENT STATE
// =====================================================
//
// Motor events are stored until MQTT is connected.
//
// MOTOR_ON  -> sent once when motor starts
// MOTOR_OFF -> sent once when motor stops
//
// LIVE data is handled separately by the main loop
// every 5 minutes.
// =====================================================

enum MotorMQTTEvent {
  MOTOR_EVENT_NONE,
  MOTOR_EVENT_ON,
  MOTOR_EVENT_OFF
};

MotorMQTTEvent pendingMotorMQTTEvent =
  MOTOR_EVENT_NONE;

// =====================================================
// INIT
// =====================================================

void initMotorStatus() {
  pinMode(
    MOTOR_STATUS_PIN,
    INPUT);

  motorRunning =
    (digitalRead(
       MOTOR_STATUS_PIN)
     == HIGH);

  lastMotorState =
    motorRunning;

  currentRunSeconds =
    0;

  motorRuntimeDate =
    rtcDate;

  motorStatusInitialized =
    true;

  // =================================================
  // MOTOR ALREADY ON AT STARTUP
  // =================================================

  if (motorRunning) {
    motorSessionStartMillis =
      millis();

    motorDaySegmentStartMillis =
      millis();

    motorStartDate =
      rtcDate;

    motorStartTime =
      rtcTime;

    // ---------------------------------------------
    // Request MOTOR_ON MQTT
    // ---------------------------------------------

    pendingMotorMQTTEvent =
      MOTOR_EVENT_ON;

    Serial.println(
      "Motor already ON at startup.");
  }

  Serial.println(
    "Motor status initialized.");

  Serial.print(
    "Motor = ");

  Serial.println(
    motorRunning
      ? "ON"
      : "OFF");
}

// =====================================================
// GET LIVE CURRENT RUN
// =====================================================

uint32_t getLiveMotorRunSeconds() {
  if (!motorRunning) {
    return currentRunSeconds;
  }

  return (
           millis() - motorSessionStartMillis)
         / 1000UL;
}

// =====================================================
// GET LIVE TODAY RUNTIME
// =====================================================

uint32_t getLiveTodayRunSeconds() {
  if (!motorRunning) {
    return todayRunSeconds;
  }

  uint32_t currentDayRun =
    (millis() - motorDaySegmentStartMillis) / 1000UL;

  return todayRunSeconds + currentDayRun;
}

// =====================================================
// FORMAT RUNTIME
// =====================================================

String formatMotorRuntime(
  uint32_t seconds) {
  uint32_t hours =
    seconds / 3600UL;

  uint32_t minutes =
    (seconds % 3600UL) / 60UL;

  uint32_t secs =
    seconds % 60UL;

  char buffer[20];

  sprintf(
    buffer,
    "%02lu:%02lu:%02lu",
    (unsigned long)hours,
    (unsigned long)minutes,
    (unsigned long)secs);

  return String(buffer);
}

// =====================================================
// LIVE MINUTES
// =====================================================

uint32_t getCurrentRunMinutes() {
  return getLiveMotorRunSeconds() / 60UL;
}

uint32_t getTodayRunMinutes() {
  return getLiveTodayRunSeconds() / 60UL;
}

// =====================================================
// PROCESS PENDING MQTT EVENT
// =====================================================
//
// This waits for MQTT to become connected.
//
// It does NOT block the ESP32.
//
// =====================================================

void processMotorMQTTEvent() {
  // LIVE-only MQTT mode: motor transitions are still recorded in the
  // motor state variables, but MOTOR_ON/MOTOR_OFF MQTT messages are not sent.
  pendingMotorMQTTEvent = MOTOR_EVENT_NONE;
}


// =====================================================
// UPDATE MOTOR
// =====================================================

void updateMotorStatus() {
  if (!motorStatusInitialized)
    return;

  // =================================================
  // READ GPIO
  // =================================================

  bool currentState =
    (digitalRead(
       MOTOR_STATUS_PIN)
     == HIGH);

  // =================================================
  // UPDATE RTC VARIABLES
  // =================================================

  updateRTC();

  // =================================================
  // NEW DAY
  // =================================================

  if (
    motorRuntimeDate != rtcDate) {
    Serial.println(
      "Motor: New day detected.");

    // ---------------------------------------------
    // If motor was running before midnight,
    // close yesterday's active segment.
    // ---------------------------------------------

    if (motorRunning) {
      uint32_t yesterdayActive =
        (millis() - motorDaySegmentStartMillis) / 1000UL;

      todayRunSeconds +=
        yesterdayActive;
    }

    // ---------------------------------------------
    // New day
    // ---------------------------------------------

    todayRunSeconds =
      0;

    motorStartCount =
      0;

    // ---------------------------------------------
    // If motor is still ON, begin a new day's
    // runtime segment.
    // ---------------------------------------------

    if (currentState) {
      motorDaySegmentStartMillis =
        millis();
    }

    motorRuntimeDate =
      rtcDate;
  }

  // =================================================
  // OFF → ON
  // =================================================

  if (
    currentState && !lastMotorState) {
    motorRunning =
      true;

    // ---------------------------------------------
    // Start current session
    // ---------------------------------------------

    motorSessionStartMillis =
      millis();

    motorDaySegmentStartMillis =
      millis();

    currentRunSeconds =
      0;

    // ---------------------------------------------
    // RTC timestamp
    // ---------------------------------------------

    motorStartDate =
      rtcDate;

    motorStartTime =
      rtcTime;

    // ---------------------------------------------
    // Start counter
    // ---------------------------------------------

    motorStartCount++;

    Serial.println(
      "==============================");

    Serial.println(
      "MOTOR START");

    Serial.print(
      "Date: ");

    Serial.println(
      motorStartDate);

    Serial.print(
      "Time: ");

    Serial.println(
      motorStartTime);

    // ---------------------------------------------
    // Request MOTOR_ON MQTT
    // ---------------------------------------------

    pendingMotorMQTTEvent =
      MOTOR_EVENT_ON;
  }

  // =================================================
  // MOTOR RUNNING
  // =================================================

  if (currentState) {
    motorRunning =
      true;

    // ---------------------------------------------
    // Live current run
    // ---------------------------------------------

    currentRunSeconds =
      getLiveMotorRunSeconds();
  }

  // =================================================
  // ON → OFF
  // =================================================

  if (
    !currentState && lastMotorState) {
    motorRunning =
      false;

    // ---------------------------------------------
    // Final current run
    // ---------------------------------------------

    currentRunSeconds =
      getLiveMotorRunSeconds();

    // ---------------------------------------------
    // Add completed run to today's total
    // ---------------------------------------------

    todayRunSeconds +=
      currentRunSeconds;

    // ---------------------------------------------
    // Stop timestamp
    // ---------------------------------------------

    motorStopDate =
      rtcDate;

    motorStopTime =
      rtcTime;

    Serial.println(
      "==============================");

    Serial.println(
      "MOTOR STOP");

    Serial.print(
      "Date: ");

    Serial.println(
      motorStopDate);

    Serial.print(
      "Time: ");

    Serial.println(
      motorStopTime);

    Serial.print(
      "This Run: ");

    Serial.print(
      currentRunSeconds);

    Serial.println(
      " sec");

    Serial.print(
      "Today: ");

    Serial.print(
      todayRunSeconds);

    Serial.println(
      " sec");

    // ---------------------------------------------
    // Request MOTOR_OFF MQTT
    // ---------------------------------------------

    pendingMotorMQTTEvent =
      MOTOR_EVENT_OFF;
  }

  // =================================================
  // PROCESS MQTT EVENT
  // =================================================

  processMotorMQTTEvent();

  // =================================================
  // SAVE STATE
  // =================================================

  lastMotorState =
    currentState;
}

// =====================================================
// ADD MOTOR DATA
// =====================================================
//
// PAYLOAD FORMAT UNCHANGED
//
// motor
// ├── running
// ├── start_date
// ├── start_time
// ├── stop_date
// ├── stop_time
// ├── current_run_seconds
// ├── current_run_minutes
// ├── current_run
// ├── today_run_seconds
// ├── today_run_minutes
// ├── today_run
// └── starts_today
//
// =====================================================

void addMotorData(
  JsonDocument &doc) {
  doc["motor"]["running"] =
    motorRunning;

  // -------------------------------------------------
  // Event timestamps
  // -------------------------------------------------

  doc["motor"]["start_date"] =
    motorStartDate;

  doc["motor"]["start_time"] =
    motorStartTime;

  doc["motor"]["stop_date"] =
    motorStopDate;

  doc["motor"]["stop_time"] =
    motorStopTime;

  // -------------------------------------------------
  // Current run
  // -------------------------------------------------

  doc["motor"]["current_run_seconds"] =
    getLiveMotorRunSeconds();

  doc["motor"]["current_run_minutes"] =
    getCurrentRunMinutes();

  doc["motor"]["current_run"] =
    formatMotorRuntime(
      getLiveMotorRunSeconds());

  // -------------------------------------------------
  // Today's total
  // -------------------------------------------------

  doc["motor"]["today_run_seconds"] =
    getLiveTodayRunSeconds();

  doc["motor"]["today_run_minutes"] =
    getTodayRunMinutes();

  doc["motor"]["today_run"] =
    formatMotorRuntime(
      getLiveTodayRunSeconds());

  // -------------------------------------------------
  // Starts today
  // -------------------------------------------------

  doc["motor"]["starts_today"] =
    motorStartCount;
}

#endif
