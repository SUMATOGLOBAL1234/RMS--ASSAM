#ifndef LCD_H
#define LCD_H

#include <Wire.h>
#include <string.h>
#include "motor_status.h"
#include "globals.h"
#include "pinmap.h"
#include "config.h"

// ==========================================================
// PCF8575 + KS0108 I2C DISPLAY DRIVER
// Keeps the same lcd.* drawing calls used by the original
// dashboard. The original U8g2 SPI display object is removed.
// ==========================================================

#define LCD_I2C_SDA 23
#define LCD_I2C_SCL 5
#define LCD_PCF8575_ADDRESS 0x20

// PCF8575 P00-P07 -> KS0108 D0-D7
// PCF8575 P10 -> RS, P11 -> E, P12 -> CS1,
// P13 -> CS2, P14 -> RESET
#define LCD_PCF_RS   8
#define LCD_PCF_E    9
#define LCD_PCF_CS1 10
#define LCD_PCF_CS2 11
#define LCD_PCF_RST 12

// The working test sketch used active-HIGH chip selects.
// Change to 1 only if your particular module uses active-LOW CS.
#define LCD_CS_ACTIVE_LOW 0

// Lightweight font identifiers. These retain the font names used
// in the original dashboard, without depending on U8g2.
static const uint8_t u8g2_font_6x12_tf[] = {1};
static const uint8_t u8g2_font_5x8_tf  [] = {2};
static const uint8_t u8g2_font_4x6_tf  [] = {3};

class PCF8575_KS0108 {
public:
  void begin() {
    Wire.begin(LCD_I2C_SDA, LCD_I2C_SCL);
    Wire.setClock(100000);

    portState = 0xFFFF;
    writePort(portState);
    delay(10);

    pinWrite(LCD_PCF_RST, LOW);
    delay(20);
    pinWrite(LCD_PCF_RST, HIGH);
    delay(20);

    for (uint8_t chip = 0; chip < 2; ++chip) {
      selectChip(chip);
      writeByte(0x3F, false); // Display ON
      writeByte(0xC0, false); // Start line 0
    }

    // Force the first framebuffer transfer to initialize every LCD byte.
    memset(previousBuffer, 0xFF, sizeof(previousBuffer));
    clearBuffer();
    sendBuffer();
  }

  void clearBuffer() {
    memset(frameBuffer, 0, sizeof(frameBuffer));
  }

  void sendBuffer() {
    // Only transmit changed bytes. This is important because an I2C
    // expander is much slower than a directly connected parallel LCD.
    for (uint8_t page = 0; page < 8; ++page) {
      uint8_t col = 0;

      while (col < 128) {
        uint16_t index = (uint16_t)page * 128 + col;

        if (frameBuffer[index] == previousBuffer[index]) {
          ++col;
          continue;
        }

        uint8_t chip = col / 64;
        uint8_t localCol = col % 64;
        selectChip(chip);
        writeByte(0xB8 | page, false);
        writeByte(0x40 | localCol, false);

        // Send a contiguous run of changed bytes, stopping at the
        // 64-column controller boundary.
        while (col < 128 && (col / 64) == chip) {
          index = (uint16_t)page * 128 + col;
          if (frameBuffer[index] == previousBuffer[index]) {
            break;
          }

          writeByte(frameBuffer[index], true);
          previousBuffer[index] = frameBuffer[index];
          ++col;
        }
      }
    }
  }

  void setFont(const uint8_t *font) {
    if (font == u8g2_font_6x12_tf) {
      fontMode = 1;
    } else if (font == u8g2_font_4x6_tf) {
      fontMode = 3;
    } else {
      fontMode = 2;
    }
  }

  void drawStr(uint8_t x, uint8_t baseline, const char *text) {
    if (!text) return;
    uint16_t xpos = x;
    while (*text && xpos < 128) {
      drawCharacter(xpos, baseline, *text++);
      xpos += (fontMode == 3) ? 5 : 6;
    }
  }

  void setCursor(uint8_t x, uint8_t baseline) {
    cursorX = x;
    cursorY = baseline;
  }

  void print(const char *text) {
    if (!text) return;
    while (*text && cursorX < 128) {
      drawCharacter(cursorX, cursorY, *text++);
      cursorX += (fontMode == 3) ? 5 : 6;
    }
  }

  void print(const String &text) {
    print(text.c_str());
  }

  void print(char value) {
    char text[2] = {value, '\0'};
    print(text);
  }

  void print(int value) {
    print(String(value));
  }

  void print(unsigned int value) {
    print(String(value));
  }

  void print(long value) {
    print(String(value));
  }

  void print(unsigned long value) {
    print(String(value));
  }

  // void print(float value, uint8_t decimals = 2) {
  //   print(String(value, decimals));
  // }

  // void print(double value, uint8_t decimals = 2) {
  //   print(String(value, decimals));
  // }

void print(float value, uint8_t decimals = 2) {
    print(String(value, (unsigned int)decimals));
}

void print(double value, uint8_t decimals = 2) {
    print(String(value, (unsigned int)decimals));
}

  void drawHLine(uint8_t x, uint8_t y, uint8_t width) {
    for (uint8_t i = 0; i < width; ++i) {
      drawPixel(x + i, y, true);
    }
  }

  void drawFrame(uint8_t x, uint8_t y, uint8_t width, uint8_t height) {
    if (width == 0 || height == 0) return;
    drawHLine(x, y, width);
    drawHLine(x, y + height - 1, width);

    for (uint8_t row = 0; row < height; ++row) {
      drawPixel(x, y + row, true);
      drawPixel(x + width - 1, y + row, true);
    }
  }

private:
  uint16_t portState = 0xFFFF;
  uint8_t frameBuffer[1024] = {0};
  uint8_t previousBuffer[1024] = {0};
  uint8_t fontMode = 2;
  uint16_t cursorX = 0;
  uint8_t cursorY = 0;

  void writePort(uint16_t value) {
    Wire.beginTransmission(LCD_PCF8575_ADDRESS);
    Wire.write(value & 0xFF);
    Wire.write((value >> 8) & 0xFF);
    Wire.endTransmission();
    portState = value;
  }

  void pinWrite(uint8_t pin, bool level) {
    if (level) portState |= (uint16_t)(1U << pin);
    else       portState &= ~(uint16_t)(1U << pin);
    writePort(portState);
  }

  void selectChip(uint8_t chip) {
#if LCD_CS_ACTIVE_LOW
    pinWrite(LCD_PCF_CS1, chip != 0);
    pinWrite(LCD_PCF_CS2, chip != 1);
#else
    pinWrite(LCD_PCF_CS1, chip == 0);
    pinWrite(LCD_PCF_CS2, chip == 1);
#endif
  }

  void writeByte(uint8_t value, bool isData) {
    // Set D0-D7 and RS while E is LOW.
    portState &= 0xFF00;
    portState |= value;

    if (isData) portState |= (1U << LCD_PCF_RS);
    else        portState &= ~(1U << LCD_PCF_RS);

    portState &= ~(1U << LCD_PCF_E);
    writePort(portState);

    pinWrite(LCD_PCF_E, HIGH);
    pinWrite(LCD_PCF_E, LOW);
    delayMicroseconds(2);
  }

  void drawPixel(uint8_t x, uint8_t y, bool on) {
    if (x >= 128 || y >= 64) return;

    uint16_t index = (uint16_t)(y / 8) * 128 + x;
    uint8_t mask = (uint8_t)(1U << (y & 7));

    if (on) frameBuffer[index] |= mask;
    else    frameBuffer[index] &= (uint8_t)~mask;
  }

  void getGlyph(char c, uint8_t glyph[5]) {
    static const uint8_t digits[10][5] = {
      {0x3E,0x51,0x49,0x45,0x3E}, {0x00,0x42,0x7F,0x40,0x00},
      {0x42,0x61,0x51,0x49,0x46}, {0x21,0x41,0x45,0x4B,0x31},
      {0x18,0x14,0x12,0x7F,0x10}, {0x27,0x45,0x45,0x45,0x39},
      {0x3C,0x4A,0x49,0x49,0x30}, {0x01,0x71,0x09,0x05,0x03},
      {0x36,0x49,0x49,0x49,0x36}, {0x06,0x49,0x49,0x29,0x1E}
    };

    static const uint8_t letters[26][5] = {
      {0x7E,0x11,0x11,0x11,0x7E}, {0x7F,0x49,0x49,0x49,0x36},
      {0x3E,0x41,0x41,0x41,0x22}, {0x7F,0x41,0x41,0x22,0x1C},
      {0x7F,0x49,0x49,0x49,0x41}, {0x7F,0x09,0x09,0x09,0x01},
      {0x3E,0x41,0x49,0x49,0x7A}, {0x7F,0x08,0x08,0x08,0x7F},
      {0x00,0x41,0x7F,0x41,0x00}, {0x20,0x40,0x41,0x3F,0x01},
      {0x7F,0x08,0x14,0x22,0x41}, {0x7F,0x40,0x40,0x40,0x40},
      {0x7F,0x02,0x0C,0x02,0x7F}, {0x7F,0x04,0x08,0x10,0x7F},
      {0x3E,0x41,0x41,0x41,0x3E}, {0x7F,0x09,0x09,0x09,0x06},
      {0x3E,0x41,0x51,0x21,0x5E}, {0x7F,0x09,0x19,0x29,0x46},
      {0x46,0x49,0x49,0x49,0x31}, {0x01,0x01,0x7F,0x01,0x01},
      {0x3F,0x40,0x40,0x40,0x3F}, {0x1F,0x20,0x40,0x20,0x1F},
      {0x3F,0x40,0x38,0x40,0x3F}, {0x63,0x14,0x08,0x14,0x63},
      {0x07,0x08,0x70,0x08,0x07}, {0x61,0x51,0x49,0x45,0x43}
    };

    if (c >= 'a' && c <= 'z') c -= ('a' - 'A');

    memset(glyph, 0, 5);

    if (c >= '0' && c <= '9') {
      memcpy(glyph, digits[c - '0'], 5);
    } else if (c >= 'A' && c <= 'Z') {
      memcpy(glyph, letters[c - 'A'], 5);
    } else {
      switch (c) {
        case '-': glyph[0]=0x08; glyph[1]=0x08; glyph[2]=0x08; glyph[3]=0x08; glyph[4]=0x08; break;
        case '.': glyph[1]=0x60; glyph[2]=0x60; break;
        case ':': glyph[1]=0x36; glyph[2]=0x36; break;
        case '/': glyph[0]=0x20; glyph[1]=0x10; glyph[2]=0x08; glyph[3]=0x04; glyph[4]=0x02; break;
        case '(': glyph[1]=0x1C; glyph[2]=0x22; glyph[3]=0x41; break;
        case ')': glyph[1]=0x41; glyph[2]=0x22; glyph[3]=0x1C; break;
        default: break;
      }
    }
  }

  void drawCharacter(uint16_t x, uint8_t baseline, char c) {
    uint8_t glyph[5];
    getGlyph(c, glyph);

    uint8_t targetWidth = (fontMode == 3) ? 4 : 5;
    uint8_t targetHeight = (fontMode == 1) ? 10 : ((fontMode == 3) ? 6 : 7);
    int16_t top = (int16_t)baseline - targetHeight;

    for (uint8_t ty = 0; ty < targetHeight; ++ty) {
      uint8_t sourceY = (uint16_t)ty * 7 / targetHeight;

      for (uint8_t tx = 0; tx < targetWidth; ++tx) {
        uint8_t sourceX = (uint16_t)tx * 5 / targetWidth;
        bool pixel = (glyph[sourceX] & (1U << sourceY)) != 0;
        if (pixel && top + ty >= 0 && (x + tx) < 128) {
          drawPixel((uint8_t)(x + tx), (uint8_t)(top + ty), true);
        }
      }
    }
  }
};

// Same global object name as the original SPI/U8g2 implementation.
PCF8575_KS0108 lcd;

// ==========================================================
// ORIGINAL LCD DASHBOARD CODE CONTINUES BELOW
// ==========================================================

// ==========================================================
// LCD SETTINGS
// ==========================================================

#define LCD_SCREEN_INTERVAL 5000UL
#define LCD_REFRESH_INTERVAL 250UL


uint8_t currentScreen = 0;

unsigned long lcdScreenTimer = 0;
unsigned long lcdRefreshTimer = 0;


// ==========================================================
// ESTIMATED MOTOR / SOLAR PARAMETERS
// ==========================================================
//
// These are MODEL values.
// They are NOT actual RS485 measurements.
//
// Calibrate these later against the VFD readings.
// ==========================================================

// Maximum observed motor/VFD voltage
#define MAX_MOTOR_VOLTAGE 228.0f

// Minimum useful running voltage
#define MIN_MOTOR_VOLTAGE 160.0f

// Maximum estimated current
#define MAX_MOTOR_CURRENT 9.0f

// Startup / minimum current
#define MIN_MOTOR_CURRENT 0.5f

// Assumed power factor
#define MOTOR_POWER_FACTOR 0.85f


// ==========================================================
// WEATHER FACTOR
// ==========================================================
//
// 1.00 = strong clear sun
// 0.90 = mostly sunny
// 0.75 = partly cloudy
// 0.60 = cloudy
// 0.45 = heavy cloud/rain
//
// For now this is manually defined.
//
// Later weather.h can update this value automatically
// using actual local weather/solar radiation.
// ==========================================================

float weatherFactor = 1.00f;


// ==========================================================
// LIVE ELECTRICAL VALUES
// ==========================================================

float estimatedVoltage = 0.0f;

float estimatedCurrent = 0.0f;

float estimatedPower = 0.0f;


// ==========================================================
// INTERNAL FILTER STATE
// ==========================================================

float filteredVoltage = 0.0f;

unsigned long electricalTimer = 0;


// Maximum voltage change per calculation
#define VOLTAGE_MAX_STEP 2.0f


// ==========================================================
// PUMP FLOW
// ==========================================================

#define PUMP_FLOW_LPS 1.0f


// ==========================================================
// LCD INITIALIZATION
// ==========================================================

void initLCD() {
  lcd.begin();

  lcd.clearBuffer();

  lcd.setFont(
    u8g2_font_6x12_tf);

  lcd.drawFrame(
    0,
    0,
    128,
    64);

  lcd.drawStr(
    12,
    18,
    "REMOTE MONITOR");

  lcd.drawStr(
    32,
    34,
    "SYS");

  lcd.setFont(
    u8g2_font_5x8_tf);

  lcd.drawStr(
    18,
    50,
    "Initializing...");

  lcd.sendBuffer();

  // No delay.
}


// ==========================================================
// HEADER
// ==========================================================

void drawHeader(
  const char *title) {
  lcd.setFont(
    u8g2_font_6x12_tf);

  lcd.drawStr(
    1,
    9,
    title);

  lcd.drawHLine(
    0,
    11,
    128);
}


// ==========================================================
// FOOTER
// ==========================================================

// void drawFooter() {
//   lcd.drawHLine(
//     0,
//     54,
//     128);

//   lcd.setFont(
//     u8g2_font_4x6_tf);

//   lcd.drawStr(
//     1,
//     62,
//     "Govt. of Assam");

//   lcd.setCursor(
//     80,
//     62);

//   lcd.print(
//     DEVICE_ID);
// }

void drawFooter() {
  // Footer separator
  lcd.drawHLine(0, 54, 128);

  // Footer font
  lcd.setFont(u8g2_font_5x8_tf);

  // Device ID
  String id = String(DEVICE_ID);
  int idWidth = id.length() * 6;
  int idX = (128 - idWidth)/2;

  if (idX < 0) idX = 0;

  lcd.setCursor(idX, 63);
  lcd.print(id);
}


// ==========================================================
// FORMAT RUNTIME
// ==========================================================

String formatRuntime(
  unsigned long sec) {
  unsigned long hr =
    sec / 3600UL;

  unsigned long mn =
    (sec % 3600UL) / 60UL;

  char buf[20];

  sprintf(
    buf,
    "%02lu Hr %02lu Min",
    hr,
    mn);

  return String(buf);
}


// ==========================================================
// GET LIVE MOTOR RUNTIME
// ==========================================================

unsigned long getLCDCurrentRunSeconds() {
  return getLiveMotorRunSeconds();
}


unsigned long getLCDTodayRunSeconds() {
  return getLiveTodayRunSeconds();
}


// ==========================================================
// WATER ESTIMATION
// ==========================================================
//
// Estimated only.
// Replace with actual flow sensor later.
// ==========================================================

float getWaterToday() {
  unsigned long runSeconds =
    getLCDTodayRunSeconds();

  return PUMP_FLOW_LPS * (float)runSeconds;
}


// ==========================================================
// SOLAR TIME FACTOR
// ==========================================================
//
// Returns approximate available solar power according
// to the time of day.
//
// The curve is deliberately smooth.
//
// Approximate behavior:
//
// 06:00 → 0
// 07:00 → 0.25
// 08:00 → 0.45
// 09:00 → 0.65
// 10:00 → 0.82
// 11:00 → 0.93
// 12:00 → 1.00
// 13:00 → 1.00
// 14:00 → 0.96
// 15:00 → 0.88
// 16:00 → 0.75
// 17:00 → 0.60
// 18:00 → 0.40
// 19:00 → 0
//
// This is an approximation.
// ==========================================================

float getSolarTimeFactor() {
  Time now = rtc.time();

  float hour =
    now.hr + (now.min / 60.0f) + (now.sec / 3600.0f);


  if (hour < 6.0f)
    return 0.0f;


  if (hour < 7.0f)
    return 0.25f * (hour - 6.0f);


  if (hour < 8.0f)
    return 0.25f + 0.20f * (hour - 7.0f);


  if (hour < 9.0f)
    return 0.45f + 0.20f * (hour - 8.0f);


  if (hour < 10.0f)
    return 0.65f + 0.17f * (hour - 9.0f);


  if (hour < 11.0f)
    return 0.82f + 0.11f * (hour - 10.0f);


  if (hour < 12.0f)
    return 0.93f + 0.07f * (hour - 11.0f);


  if (hour < 13.0f)
    return 1.00f;


  if (hour < 14.0f)
    return 1.00f - 0.04f * (hour - 13.0f);


  if (hour < 15.0f)
    return 0.96f - 0.08f * (hour - 14.0f);


  if (hour < 16.0f)
    return 0.88f - 0.13f * (hour - 15.0f);


  if (hour < 17.0f)
    return 0.75f - 0.15f * (hour - 16.0f);


  if (hour < 18.0f)
    return 0.60f - 0.20f * (hour - 17.0f);


  if (hour < 19.0f)
    return 0.40f - 0.40f * (hour - 18.0f);


  return 0.0f;
}


// ==========================================================
// WEATHER ADJUSTMENT
// ==========================================================

float getSolarFactor() {
  float timeFactor =
    getSolarTimeFactor();


  float factor =
    timeFactor * weatherFactor;


  if (factor < 0.0f)
    factor = 0.0f;

  if (factor > 1.0f)
    factor = 1.0f;


  return factor;
}


// ==========================================================
// DEPTH FILTER
// ==========================================================

#define DEPTH_MIN_VALID 80
#define DEPTH_MAX_VALID 8000
#define DEPTH_SAMPLE_COUNT 10

int previousDepthMM = 0;
int highestDepthMM = 0;
uint8_t depthReadingCount = 0;


// Process one depth reading
void updateDepthFilter(int depthMM) {
  // Valid depth: 80 mm to 800 mm
  if (depthMM >= DEPTH_MIN_VALID && depthMM <= DEPTH_MAX_VALID) {
    // Keep the highest value in this group
    if (depthMM > highestDepthMM) {
      highestDepthMM = depthMM;
    }
  }

  // Zero = no reading
  // Simply ignore it.
  else if (depthMM == 0) {
    // Keep previous value
  }

  // Anything outside 80-800 mm is invalid
  else {
    // Ignore invalid value
  }

  depthReadingCount++;

  // After 10 readings
  if (depthReadingCount >= DEPTH_SAMPLE_COUNT) {
    // If at least one valid reading was received
    if (highestDepthMM > 0) {
      previousDepthMM = highestDepthMM;
    }

    // Start a new group of 10 readings
    highestDepthMM = 0;
    depthReadingCount = 0;
  }
}
// ==========================================================
// CALCULATE TARGET VOLTAGE
// ==========================================================
//
// We do NOT directly jump to the target voltage.
//
// Example:
//
// target = 228 V
// current = 200 V
//
// 200 → 202 → 204 → 206 → ...
//
// This prevents artificial fluctuations.
// ==========================================================

float calculateTargetVoltage() {
  if (!motorRunning)
    return 0.0f;


  float solarFactor =
    getSolarFactor();


  // No useful sunlight
  if (solarFactor <= 0.01f) {
    return MIN_MOTOR_VOLTAGE;
  }


  // ------------------------------------------------------
  // Map solar factor to voltage
  //
  // 0.0 → 160 V
  // 1.0 → 228 V
  // ------------------------------------------------------

  float voltage =
    MIN_MOTOR_VOLTAGE + (MAX_MOTOR_VOLTAGE - MIN_MOTOR_VOLTAGE) * solarFactor;


  return voltage;
}


// ==========================================================
// UPDATE ESTIMATED VOLTAGE
// ==========================================================

void updateEstimatedVoltage() {
  unsigned long nowMillis =
    millis();


  // Run calculation every 1 second

  if (
    nowMillis - electricalTimer < 1000UL) {
    return;
  }


  electricalTimer =
    nowMillis;


  // ------------------------------------------------------
  // MOTOR OFF
  // ------------------------------------------------------

  if (!motorRunning) {
    filteredVoltage = 0.0f;

    estimatedVoltage = 0.0f;

    estimatedCurrent = 0.0f;

    estimatedPower = 0.0f;

    return;
  }


  // ------------------------------------------------------
  // Target voltage
  // ------------------------------------------------------

  float targetVoltage =
    calculateTargetVoltage();


  // ------------------------------------------------------
  // Slow voltage movement
  // ------------------------------------------------------

  if (
    targetVoltage > filteredVoltage) {
    filteredVoltage +=
      VOLTAGE_MAX_STEP;

    if (
      filteredVoltage > targetVoltage) {
      filteredVoltage =
        targetVoltage;
    }
  } else if (
    targetVoltage < filteredVoltage) {
    filteredVoltage -=
      VOLTAGE_MAX_STEP;

    if (
      filteredVoltage < targetVoltage) {
      filteredVoltage =
        targetVoltage;
    }
  }


  // ------------------------------------------------------
  // Clamp
  // ------------------------------------------------------

  if (
    filteredVoltage > MAX_MOTOR_VOLTAGE) {
    filteredVoltage =
      MAX_MOTOR_VOLTAGE;
  }


  if (
    filteredVoltage < MIN_MOTOR_VOLTAGE) {
    filteredVoltage =
      MIN_MOTOR_VOLTAGE;
  }


  estimatedVoltage =
    filteredVoltage;


  // ======================================================
  // CURRENT ESTIMATION
  // ======================================================
  //
  // Current is estimated from the solar factor.
  //
  // At weak operation:
  // approximately 0.5 A
  //
  // At full operation:
  // approximately 9 A
  // ======================================================

  float voltageFactor =
    (estimatedVoltage - MIN_MOTOR_VOLTAGE)
    / (MAX_MOTOR_VOLTAGE - MIN_MOTOR_VOLTAGE);


  if (voltageFactor < 0.0f)
    voltageFactor = 0.0f;


  if (voltageFactor > 1.0f)
    voltageFactor = 1.0f;


  estimatedCurrent =
    MIN_MOTOR_CURRENT + (MAX_MOTOR_CURRENT - MIN_MOTOR_CURRENT) * voltageFactor;


  // ======================================================
  // POWER
  // ======================================================
  //
  // P ≈ V × I × PF
  //
  // This is an estimate.
  // ======================================================

  estimatedPower =
    estimatedVoltage * estimatedCurrent * MOTOR_POWER_FACTOR;
}


// ==========================================================
// ADD ELECTRICAL DATA TO MQTT JSON
// ==========================================================
//
// These values are ESTIMATED until RS485/VFD data
// becomes available.
//
// ==========================================================

void addElectricalData(
  JsonDocument &doc) {
  doc["electrical"]["estimated"] = true;

  doc["electrical"]["voltage"] =
    estimatedVoltage;

  doc["electrical"]["current"] =
    estimatedCurrent;

  doc["electrical"]["power"] =
    estimatedPower;
}

// ==========================================================
// SCREEN 1
// ==========================================================

void drawScreen1() {
  drawHeader(
    "REMOTE MONITORING SYS");


  lcd.setFont(
    u8g2_font_5x8_tf);


  lcd.drawStr(
    10,
    24,
    "Department of");


  lcd.drawStr(
    18,
    34,
    "Irrigation");


  lcd.drawStr(
    26,
    44,
    "IIPPMS");


  lcd.drawStr(
    14,
    54,
    "Govt. of Assam");
}


// ==========================================================
// SCREEN 2
// MOTOR REPORT
// ==========================================================

void drawScreen2() {
  drawHeader(
    "MOTOR REPORT");


  lcd.setFont(
    u8g2_font_5x8_tf);


  // ------------------------------------------------------
  // STATUS
  // ------------------------------------------------------

  lcd.drawStr(
    2,
    23,
    "Status :");


  if (motorRunning) {
    lcd.drawStr(
      50,
      23,
      "RUNNING");
  } else {
    lcd.drawStr(
      50,
      23,
      "STOPPED");
  }


  // ------------------------------------------------------
  // CURRENT RUN
  // ------------------------------------------------------

  lcd.drawStr(
    2,
    35,
    "Run    :");


  lcd.setCursor(
    50,
    35);


  lcd.print(
    formatRuntime(
      getLCDCurrentRunSeconds()));


  // ------------------------------------------------------
  // TODAY
  // ------------------------------------------------------

  lcd.drawStr(
    2,
    47,
    "Today  :");


  lcd.setCursor(
    50,
    47);


  lcd.print(
    formatRuntime(
      getLCDTodayRunSeconds()));


  drawFooter();
}


// ==========================================================
// SCREEN 3
// GPS + RIVER DATA
// ==========================================================

void drawScreen3() {
  drawHeader(
    "RIVER DATA");


  lcd.setFont(
    u8g2_font_5x8_tf);


  // ------------------------------------------------------
  // GPS
  // ------------------------------------------------------

  lcd.setCursor(
    2,
    22);

  lcd.print(
    "GPS:");


  if (realGPSActive && satellites >= 1) {
    lcd.print("GPS FIX ");
    lcd.print(satellites);
    lcd.print(" SAT");
  } else {
    lcd.print("SEARCH");
  }

  // ------------------------------------------------------
  // LATITUDE
  // ------------------------------------------------------

  lcd.setCursor(
    2,
    33);

  lcd.print(
    "Lat:");


  lcd.print(liveLatitude, 6);


  // ------------------------------------------------------
  // LONGITUDE
  // ------------------------------------------------------

  lcd.setCursor(
    2,
    43);

  lcd.print(
    "Lon:");


  lcd.print(liveLongitude, 6);


  // ------------------------------------------------------
  // DEPTH
  // ------------------------------------------------------

  // ------------------------------------------------------
  // DEPTH
  // ------------------------------------------------------

  updateDepthFilter(depthMM);

  lcd.setCursor(
    2,
    53);

  lcd.print(
    "Depth:");

  lcd.print(
    previousDepthMM / 10.0,
    1);

  lcd.print(
    " cm");

  drawFooter();
}


// ==========================================================
// SCREEN 4
// ELECTRICAL DATA
// ==========================================================

void drawScreen4() {
  drawHeader(
    "ELECTRICAL DATA");


  lcd.setFont(
    u8g2_font_5x8_tf);


  // ------------------------------------------------------
  // VOLTAGE
  // ------------------------------------------------------

  lcd.drawStr(
    2,
    23,
    "Voltage :");


  lcd.setCursor(
    60,
    23);


  lcd.print(
    estimatedVoltage,
    0);

  lcd.print(
    " V");


  // ------------------------------------------------------
  // CURRENT
  // ------------------------------------------------------

  lcd.drawStr(
    2,
    35,
    "Current :");


  lcd.setCursor(
    60,
    35);


  lcd.print(
    estimatedCurrent,
    1);

  lcd.print(
    " A");


  // ------------------------------------------------------
  // POWER
  // ------------------------------------------------------

  lcd.drawStr(
    2,
    47,
    "Power   :");


  lcd.setCursor(
    60,
    47);


  lcd.print(
    estimatedPower,
    0);

  lcd.print(
    " W");


  drawFooter();
}


// ==========================================================
// SCREEN ROTATION
// ==========================================================

void drawDashboard() {
  switch (
    currentScreen) {
    case 0:

      drawScreen1();

      break;


    case 1:

      drawScreen2();

      break;


    case 2:

      drawScreen3();

      break;


    case 3:

      drawScreen4();

      break;
  }
}


// ==========================================================
// MAIN LCD UPDATE
// ==========================================================

void updateLCD() {
  // ------------------------------------------------------
  // Electrical calculation
  // ------------------------------------------------------

  updateEstimatedVoltage();


  // ------------------------------------------------------
  // Screen rotation
  // ------------------------------------------------------

  if (
    millis() - lcdScreenTimer >= LCD_SCREEN_INTERVAL) {
    lcdScreenTimer =
      millis();


    currentScreen++;


    if (
      currentScreen > 3) {
      currentScreen = 0;
    }
  }


  // ------------------------------------------------------
  // LCD refresh
  // ------------------------------------------------------

  if (
    millis() - lcdRefreshTimer < LCD_REFRESH_INTERVAL) {
    return;
  }


  lcdRefreshTimer =
    millis();


  // ------------------------------------------------------
  // Draw
  // ------------------------------------------------------

  lcd.clearBuffer();

  drawDashboard();

  lcd.sendBuffer();
}


#endif