#ifndef REBOOT_H
#define REBOOT_H

#include <Arduino.h>
#include <Preferences.h>
#include <esp_system.h>
#include <esp_task_wdt.h>
#include <esp_arduino_version.h>
#include "globals.h"

// =====================================================
// ESP32 REBOOT / WATCHDOG MANAGER
//
// 1. Normal scheduled reboot: every day at 00:01 (12:01 AM).
// 2. Software watchdog: if the main loop stops running for
//    WATCHDOG_TIMEOUT_SECONDS, the ESP32 is automatically reset.
//
// This is important if the ESP32 has power but the firmware
// becomes stuck. A normal checkScheduledReboot() cannot help
// in that situation because loop() is no longer executing.
// =====================================================

#define WATCHDOG_TIMEOUT_SECONDS 60

Preferences rebootPreferences;
bool rebootPreferencesInitialized = false;
bool watchdogInitialized = false;

void initScheduledReboot() {
  if (!rebootPreferencesInitialized) {
    rebootPreferences.begin("daily_reboot", false);
    rebootPreferencesInitialized = true;
  }
}

// =====================================================
// WATCHDOG INITIALIZATION
// =====================================================
void initRebootWatchdog() {
  if (watchdogInitialized)
    return;

#if ESP_ARDUINO_VERSION_MAJOR >= 3
  // Arduino-ESP32 3.x / ESP-IDF 5.x API
  esp_task_wdt_config_t wdtConfig = {
    .timeout_ms = WATCHDOG_TIMEOUT_SECONDS * 1000,
    .idle_core_mask = 0,
    .trigger_panic = true
  };

  esp_err_t result = esp_task_wdt_init(&wdtConfig);
#else
  // Arduino-ESP32 2.x API
  esp_err_t result = esp_task_wdt_init(WATCHDOG_TIMEOUT_SECONDS, true);
#endif

  // Subscribe the Arduino loop task to the watchdog.
  if (result == ESP_OK || result == ESP_ERR_INVALID_STATE) {
    esp_task_wdt_add(NULL);
    watchdogInitialized = true;

    Serial.print("WATCHDOG: enabled, timeout = ");
    Serial.print(WATCHDOG_TIMEOUT_SECONDS);
    Serial.println(" seconds");
  } else {
    Serial.print("WATCHDOG: initialization failed, error = ");
    Serial.println((int)result);
  }
}

// Call this from loop() regularly.
void feedRebootWatchdog() {
  if (watchdogInitialized) {
    esp_task_wdt_reset();
  }
}

// =====================================================
// DAILY AUTOMATIC REBOOT
// =====================================================
void checkScheduledReboot() {
  if (!rebootPreferencesInitialized) {
    initScheduledReboot();
  }

  Time now = rtc.time();

  // Use the whole 00:01 minute instead of checking only sec == 0.
  // This prevents missing the reboot if loop() happens to be busy
  // at exactly 00:01:00.
  if (now.hr == 0 && now.min == 1) {

    char today[11];
    snprintf(today, sizeof(today),
             "%04d-%02d-%02d", now.yr, now.mon, now.date);

    String lastRebootDate =
        rebootPreferences.getString("last_date", "");

    if (lastRebootDate != String(today)) {

      Serial.println();
      Serial.println("==============================");
      Serial.println("DAILY SCHEDULED REBOOT");
      Serial.println("Time: 12:01 AM");
      Serial.println("Restarting ESP32...");
      Serial.println("==============================");

      // Save before restart so the ESP32 does not reboot repeatedly
      // during the same 00:01 minute.
      rebootPreferences.putString("last_date", today);
      rebootPreferences.end();

      delay(100);
      ESP.restart();
    }
  }
}

#endif
