#ifndef CONFIG_H
#define CONFIG_H

//=====================================================
// Cellular / A7672S Configuration
//=====================================================
#define GSM_APN "JioNet" //"airtelgprs.com"
#define GSM_BAUD 9600

//=====================================================
// MQTT Configuration
//=====================================================
#define DEVICE_ID "SV1RDAA01"
#define MQTT_SERVER "mqtt.sumato.tech"
#define MQTT_PORT 1883
#define MQTT_USERNAME "user1"
#define MQTT_PASSWORD "secret"
#define MQTT_CLIENT_ID  DEVICE_ID //"RMS001"

//=====================================================
// MQTT Topics
//=====================================================
#define TOPIC_STATUS "rms/DEVICE_ID/status"
#define TOPIC_CMD "rms/DEVICE_ID/cmd"
//#define TOPIC_GPS_OVERRIDE "rms/RMS001/override/gps"

//=====================================================
// Sensor Update Time
//=====================================================
#define GPS_INTERVAL 1000
#define RTC_INTERVAL 1000
#define ULTRASONIC_INTERVAL 200
#define CURRENT_INTERVAL 200
#define MQTT_INTERVAL 5000
#define MQTT_LIVE_INTERVAL 2500
#define LCD_INTERVAL 250
#define RS485_INTERVAL 30000

//=====================================================
// UART Baud Rates
//=====================================================
#define ULTRASONIC_BAUD 115200
#define RS485_BAUD 9600

//=====================================================
// Time
//=====================================================
#define GMT_OFFSET_SEC 19800  // IST = UTC+5:30

#endif
