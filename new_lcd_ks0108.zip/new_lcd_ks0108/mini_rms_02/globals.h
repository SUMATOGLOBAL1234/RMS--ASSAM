#ifndef GLOBALS_H
#define GLOBALS_H

#include <Arduino.h>
#include <ArduinoJson.h>
#include <DS1302.h>

#include "pinmap.h"

void publishAllData(const char *event);

#define DEBUG_QUEUE_SIZE 20

// =====================================================
// DEBUG QUEUE
// =====================================================
String debugQueue[DEBUG_QUEUE_SIZE];
volatile uint8_t debugHead = 0;
volatile uint8_t debugTail = 0;

// =====================================================
// HARDWARE SERIAL
// =====================================================
// UART2 is dedicated to the A7672S.  The old NEO-6M
// GPS is no longer connected to this UART.
HardwareSerial GSM(2);
HardwareSerial Ultra(1);

// =====================================================
// RTC
// =====================================================
DS1302 rtc(
  RTC_RST_PIN,
  RTC_DAT_PIN,
  RTC_CLK_PIN);

bool rtcSyncedToday = false;
bool ntpTimeValid = false;

// =====================================================
// CELLULAR / MQTT STATUS
// =====================================================
bool gsmInitialized = false;
bool cellularConnected = false;
bool mqttConnected = false;

// =====================================================
// GPS DATA - supplied by A7672S GNSS
bool gpsInitialized = false;
bool realGPSActive = false;
char gpsDateUTC[12] = "";
char gpsTimeUTC[16] = "";
// =====================================================
double latitude = 0.0;
double longitude = 0.0;
float altitude = 0.0;
float speedKmph = 0.0;
int satellites = 0;
float gpsHDOP = 0.0f;

// Raw GPS
 double liveLatitude = 0.0;
double liveLongitude = 0.0;

// Filtered GPS
 double filteredLatitude = 0.0;
double filteredLongitude = 0.0;

// =====================================================
// RTC DATA
// =====================================================
String rtcDate = "";
String rtcTime = "";

// =====================================================
// MOTOR DATA
// =====================================================
bool motorRunning = false;
bool lastMotorState = false;
uint32_t currentRunSeconds = 0;
uint32_t todayRunSeconds = 0;
uint16_t motorStartCount = 0;
String lastMotorDate = "";
String motorStartDate = "";
String motorStartTime = "";
String motorStopDate = "";
String motorStopTime = "";
bool motorLogReady = false;

// =====================================================
// OTHER LIVE DATA
// =====================================================
int currentADC = 0;
float distanceMM = 0;
float depthMM = 0;
float liveRunSeconds = 0.0f;
float liveWaterToday = 0.0f;
float liveCurrent = 0.0f;
float livePower = 0.0f;

// =====================================================
// TIMERS
// =====================================================
unsigned long gpsTimer = 0;
unsigned long rtcTimer = 0;
unsigned long ultraTimer = 0;
unsigned long currentTimer = 0;
unsigned long mqttTimer = 0;
unsigned long lcdTimer = 0;
unsigned long rs485Timer = 0;

// =====================================================
// CELLULAR TIMERS
// =====================================================
unsigned long gsmNetworkCheckTimer = 0;
unsigned long mqttReconnectTimer = 0;

// Legacy phone-GPS variables retained for compatibility with
// existing code; they are not required for normal operation.
bool phoneGPSValid = false;
double phoneLatitude = 0.0;
double phoneLongitude = 0.0;
unsigned long phoneGPSLastUpdate = 0;

#endif
