#ifndef STATUS_LED_H
#define STATUS_LED_H

#include <Arduino.h>
#include "globals.h"

// Mini RMS status LEDs
// GPIO 15: Cellular internet/PDP connection
// GPIO 12: Ultrasonic depth sensor has recently returned valid data
// GPIO 34: Not used

#define INTERNET_STATUS_LED_PIN 15
#define DEPTH_STATUS_LED_PIN    12

// If the sensor stops returning valid readings for this long,
// the depth LED turns OFF. Adjust if your sensor update interval changes.
#define DEPTH_DATA_TIMEOUT_MS   3000UL

inline void initStatusLEDs()
{
    pinMode(INTERNET_STATUS_LED_PIN, OUTPUT);
    pinMode(DEPTH_STATUS_LED_PIN, OUTPUT);

    digitalWrite(INTERNET_STATUS_LED_PIN, LOW);
    digitalWrite(DEPTH_STATUS_LED_PIN, LOW);
}

inline void updateStatusLEDs()
{
    // Existing project variable: cellularConnected
    // This reflects the modem's cellular data/PDP internet connection.
    digitalWrite(
        INTERNET_STATUS_LED_PIN,
        cellularConnected ? HIGH : LOW
    );

    // Existing ultrasonic variable: lastValidReading
    // LED stays ON while valid depth readings continue to arrive.
    bool depthDataIsFresh =
        (lastValidReading != 0) &&
        ((unsigned long)(millis() - lastValidReading) <= DEPTH_DATA_TIMEOUT_MS);

    digitalWrite(
        DEPTH_STATUS_LED_PIN,
        depthDataIsFresh ? HIGH : LOW
    );
}

#endif // STATUS_LED_H
