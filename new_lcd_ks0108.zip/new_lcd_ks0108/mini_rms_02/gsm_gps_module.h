#ifndef GSM_GPS_MODULE_H
#define GSM_GPS_MODULE_H

/*
 * ============================================================
 * A7672S GSM + GNSS + MQTT MANAGER
 * ============================================================
 *
 * ESP32 UART2:
 *   A7672S TX -> GPIO16 (ESP32 RX2)
 *   A7672S RX -> GPIO17 (ESP32 TX2)
 *
 * Main design:
 *
 *   GSM/network    = independent
 *   PDP/Internet   = independent
 *   MQTT           = independent
 *   GNSS           = independent
 *   NTP/RTC        = optional
 *
 * Therefore:
 *
 *   GPS FAIL       -> MQTT continues
 *   GPS NO FIX     -> MQTT continues
 *   NTP FAIL       -> MQTT continues
 *   MQTT FAIL      -> GSM remains alive if possible
 *   PDP FAIL       -> MQTT reconnects after PDP recovery
 *   GSM FAIL       -> complete cellular recovery
 *
 * ============================================================
 */

#include <Arduino.h>
#include <ArduinoJson.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

#include "globals.h"
#include "config.h"

// ============================================================
// TIMINGS
// ============================================================

#define GSM_AT_TIMEOUT 5000UL
#define GSM_NETWORK_TIMEOUT 15000UL
#define GSM_PDP_TIMEOUT 30000UL
#define GSM_MQTT_TIMEOUT 30000UL
#define GSM_PUBLISH_TIMEOUT 15000UL
#define GSM_FIRST_MQTT_DELAY 30000UL
#define GSM_LIVE_INTERVAL 300000UL

#define GSM_RETRY_INTERVAL 5000UL
#define GSM_NETWORK_RETRY_INTERVAL 5000UL

#define GSM_HEALTH_INTERVAL 60000UL

#define GSM_GPS_INTERVAL 300000UL
#define GSM_GPS_RESPONSE_TIMEOUT 4000UL

#define GSM_NTP_TIMEOUT 30000UL
#define GSM_NTP_RETRY_INTERVAL 3600000UL

#define GSM_MAX_AT_RESPONSE 4000U

#define GPS_ALPHA 0.20f
#define GPS_MIN_SATELLITES 3

#define GSM_MQTT_FAILURE_LIMIT 3
#define GSM_MODEM_FAILURE_LIMIT 3



// ============================================================
// CELLULAR INFORMATION
// ============================================================

int gsmRSSI = 0;
String gsmIPAddress = "";

// mqttmanager.h owns the main RMS payload builder.
String buildLivePayload();
bool gsmMQTTPublish(const char *topic, const char *payload);

// ============================================================
// HARDWARE
// ============================================================

HardwareSerial *gsmHardware = &GSM;

// ============================================================
// STATE MACHINE
// ============================================================

enum GSMState {
  GSM_BOOT = 0,

  GSM_WAIT_MODEM,
  GSM_WAIT_SIM,

  GSM_START_GNSS,

  GSM_NETWORK_CHECK,
  GSM_SET_APN,
  GSM_ATTACH,
  GSM_PDP_CHECK,
  GSM_PDP_ACTIVATE,
  GSM_IP_CHECK,

  GSM_NTP_CONFIG,
  GSM_NTP_REQUEST,
  GSM_NTP_CLOCK,

  GSM_MQTT_START,
  GSM_MQTT_ACQUIRE,
  GSM_MQTT_CONNECT,

  GSM_READY,

  GSM_HEALTH_NETWORK,
  GSM_HEALTH_PDP,
  GSM_HEALTH_IP,

  GSM_GPS_READ,

  GSM_MQTT_DISCONNECT,
  GSM_MQTT_RELEASE,
  GSM_MQTT_STOP,

  GSM_RETRY_WAIT
};

GSMState gsmState = GSM_BOOT;

// ============================================================
// STATUS FLAGS
// ============================================================

//bool gsmInitialized = false;

bool mqttServiceStarted = false;
bool mqttClientAcquired = false;

bool ntpSyncedThisConnection = false;

bool mqttRecoveryRequested = false;
bool ntpOnlyRecovery = false;

// ============================================================
// TIMERS
// ============================================================

unsigned long gsmRetryAt = 0;
unsigned long gsmNextGPS = 0;

unsigned long gsmLastHealthCheck = 0;
unsigned long gsmLastPublish = 0;
bool mqttFirstPublishPending = false;
unsigned long mqttFirstPublishAt = 0;

unsigned long ntpRetryAt = 0;

// ============================================================
// FAILURE COUNTERS
// ============================================================

uint8_t mqttFailureCount = 0;
uint8_t modemFailureCount = 0;

// ============================================================
// AT TRANSACTION ENGINE
// ============================================================

bool atBusy = false;
bool atFinished = false;
bool atFailed = false;

String atExpected = "";
String gsmATResponse = "";

// ============================================================
// NON-BLOCKING MQTT PUBLISH ENGINE
// ============================================================
// MQTT publish is performed one small step at a time. No while()
// loop waits for the modem, so the main loop continues running and
// the ESP32 watchdog remains effective.
enum MQTTPublishStage {
  MQTT_PUB_IDLE = 0,
  MQTT_PUB_WAIT_TOPIC_PROMPT,
  MQTT_PUB_WAIT_TOPIC_OK,
  MQTT_PUB_WAIT_PAYLOAD_PROMPT,
  MQTT_PUB_WAIT_PAYLOAD_OK,
  MQTT_PUB_WAIT_RESULT
};

MQTTPublishStage mqttPublishStage = MQTT_PUB_IDLE;
bool mqttPublishBusy = false;
unsigned long mqttPublishDeadline = 0;
String mqttPublishResponse = "";
String mqttPublishTopic = "";
String mqttPublishPayload = "";

static void mqttPublishFail(const char *reason);
static void mqttPublishTask();
static bool startMQTTPublishAsync(const char *topic, const char *payload);

unsigned long atDeadline = 0;

// ============================================================
// URC FILTERING
// ============================================================
//
// A7672S can generate unsolicited responses while another
// command is being processed.
//
// Examples:
//
//   +CGNSSPWR: READY!
//   +CGEV: ...
//   +CMQTTCONN: ...
//
// They must not be allowed to make unrelated commands fail.
//
// ============================================================

static bool isURCLine(const String &line) {
  if (line.startsWith("+CGNSSPWR:"))
    return true;

  if (line.startsWith("+CGEV:"))
    return true;

  if (line.startsWith("+CMQTTCONN:"))
    return true;

  if (line.startsWith("+CMQTTDISC:"))
    return true;

  if (line.startsWith("+CMQTTPUB:"))
    return true;

  return false;
}

// ============================================================
// CLEAR UART
// ============================================================

static void clearGSMBuffer() {
  while (GSM.available())
    GSM.read();
}

// ============================================================
// CLEAR AT RESULT
// ============================================================

static void clearATResult() {
  atBusy = false;
  atFinished = false;
  atFailed = false;

  atExpected = "";
  gsmATResponse = "";
}

// ============================================================
// START AT COMMAND
// ============================================================

static void beginAT(
  const char *cmd,
  const char *expected,
  unsigned long timeout) {
  clearGSMBuffer();

  gsmATResponse = "";

  atExpected =
    expected ? expected : "";

  atBusy = true;
  atFinished = false;
  atFailed = false;

  atDeadline =
    millis() + timeout;

  Serial.print("A7672S >> ");
  Serial.println(cmd);

  GSM.println(cmd);
}

// ============================================================

static void beginAT(
  const String &cmd,
  const char *expected,
  unsigned long timeout) {
  beginAT(
    cmd.c_str(),
    expected,
    timeout);
}

// ============================================================
// POLL AT
// ============================================================

static void pollAT() {
  if (!atBusy)
    return;

  while (GSM.available()) {
    char c =
      (char)GSM.read();

    Serial.write(c);

    if (gsmATResponse.length() < GSM_MAX_AT_RESPONSE) {
      gsmATResponse += c;
    }

    /*
         * Do not immediately fail on every "ERROR" substring.
         *
         * First look for actual command response patterns.
         */

    if (gsmATResponse.indexOf(
          "+CME ERROR")
        >= 0) {
      atBusy = false;
      atFinished = true;
      atFailed = true;
      return;
    }

    if (gsmATResponse.indexOf(
          "+CMS ERROR")
        >= 0) {
      atBusy = false;
      atFinished = true;
      atFailed = true;
      return;
    }

    /*
         * Normal AT command error.
         */
    if (gsmATResponse.indexOf(
          "\r\nERROR\r\n")
          >= 0
        || gsmATResponse.indexOf(
             "\nERROR\r\n")
             >= 0) {
      atBusy = false;
      atFinished = true;
      atFailed = true;
      return;
    }

    /*
         * Expected response received.
         */
    if (atExpected.length() > 0 && gsmATResponse.indexOf(atExpected) >= 0) {
      atBusy = false;
      atFinished = true;
      atFailed = false;
      return;
    }
  }

  /*
     * Timeout.
     */
  if ((long)(millis() - atDeadline) >= 0) {
    atBusy = false;
    atFinished = true;
    atFailed = true;

    Serial.println(
      "A7672S: AT TIMEOUT");
  }
}

// ============================================================

static bool atDone() {
  return atFinished;
}

// ============================================================

static bool atOK() {
  return atFinished && !atFailed;
}

// ============================================================
// NETWORK REGISTRATION
// ============================================================

static bool parseCEREGStatus(
  int &status) {
  int p =
    gsmATResponse.indexOf(
      "+CEREG:");

  if (p < 0)
    return false;

  int colon =
    gsmATResponse.indexOf(
      ':',
      p);

  if (colon < 0)
    return false;

  String data =
    gsmATResponse.substring(
      colon + 1);

  data.trim();

  /*
     * Possible:
     *
     * +CEREG: 0,1
     * +CEREG: 0,5
     * +CEREG: 1
     * +CEREG: 5
     */

  int comma =
    data.indexOf(',');

  if (comma >= 0) {
    status =
      data.substring(
            comma + 1)
        .toInt();
  } else {
    status =
      data.toInt();
  }

  return true;
}

// ============================================================

static bool networkRegistered() {
  int status = -1;

  if (!parseCEREGStatus(status))
    return false;

  /*
     * 1 = registered, home
     * 5 = registered, roaming
     */

  return (
    status == 1 || status == 5);
}

// ============================================================
// PACKET ATTACH
// ============================================================
//
// IMPORTANT:
//
// We do NOT use the response from CGACT? to decide whether
// CGATT succeeded.
//
// CGATT and CGACT are different things.
//
// ============================================================

static bool packetAttached() {
  int p =
    gsmATResponse.indexOf(
      "+CGATT:");

  if (p < 0)
    return false;

  int colon =
    gsmATResponse.indexOf(
      ':',
      p);

  if (colon < 0)
    return false;

  String data =
    gsmATResponse.substring(
      colon + 1);

  data.trim();

  return data.toInt() == 1;
}

// ============================================================
// PDP CONTEXT CHECK
// ============================================================
//
// We only care about CID 1 because the program creates:
//
// AT+CGDCONT=1,"IP","APN"
//
// The modem may also report:
//
// +CGACT: 8,1
//
// That is another context and is NOT an error.
//
// ============================================================

static bool pdpActive() {
  int searchPos = 0;

  while (true) {
    int p =
      gsmATResponse.indexOf(
        "+CGACT:",
        searchPos);

    if (p < 0)
      return false;

    int colon =
      gsmATResponse.indexOf(
        ':',
        p);

    if (colon < 0)
      return false;

    int end =
      gsmATResponse.indexOf(
        '\n',
        colon);

    if (end < 0)
      end =
        gsmATResponse.length();

    String line =
      gsmATResponse.substring(
        colon + 1,
        end);

    line.trim();

    int comma =
      line.indexOf(',');

    if (comma >= 0) {
      int cid =
        line.substring(
              0,
              comma)
          .toInt();

      int state =
        line.substring(
              comma + 1)
          .toInt();

      /*
             * ONLY CID 1 matters.
             */
      if (cid == 1 && state == 1) {
        return true;
      }
    }

    searchPos = end + 1;

    if (searchPos >= (int)gsmATResponse.length()) {
      return false;
    }
  }
}

// ============================================================
// IP ADDRESS
// ============================================================

static bool parseIPAddress() {
  const char *prefix =
    "+CGPADDR: 1,";

  int p =
    gsmATResponse.indexOf(
      prefix);

  if (p < 0)
    return false;

  p += strlen(prefix);

  int e =
    gsmATResponse.indexOf(
      '\r',
      p);

  if (e < 0) {
    e =
      gsmATResponse.indexOf(
        '\n',
        p);
  }

  if (e < 0)
    e =
      gsmATResponse.length();

  String ip =
    gsmATResponse.substring(
      p,
      e);

  ip.trim();

  if (ip.length() == 0)
    return false;

  if (ip == "0.0.0.0")
    return false;

  gsmIPAddress = ip;

  Serial.print(
    "A7672S IP: ");

  Serial.println(
    gsmIPAddress);

  return true;
}

// ============================================================
// RSSI
// ============================================================

static bool parseRSSI() {
  int p =
    gsmATResponse.indexOf(
      "+CSQ:");

  if (p < 0)
    return false;

  p =
    gsmATResponse.indexOf(
      ':',
      p);

  if (p < 0)
    return false;

  String data =
    gsmATResponse.substring(
      p + 1);

  data.trim();

  int comma =
    data.indexOf(',');

  if (comma < 0)
    return false;

  int csq =
    data.substring(
          0,
          comma)
      .toInt();

  /*
     * 99 = unknown.
     */
  if (csq == 99) {
    gsmRSSI = 0;
    return true;
  }

  if (csq < 0 || csq > 31) {
    return false;
  }

  gsmRSSI =
    -113 + (2 * csq);

  Serial.print(
    "A7672S RSSI: ");

  Serial.print(
    gsmRSSI);

  Serial.println(
    " dBm");

  return true;
}

// ============================================================
// GPS RESET
// ============================================================

static void resetGPSValues() {
  realGPSActive = false;
  gpsInitialized = false;

  liveLatitude = 0.0;
  liveLongitude = 0.0;

  filteredLatitude = 0.0;
  filteredLongitude = 0.0;

  latitude = 0.0;
  longitude = 0.0;

  altitude = 0.0f;
  speedKmph = 0.0f;

  satellites = 0;
  gpsHDOP = 0.0f;

  gpsDateUTC[0] = '\0';
  gpsTimeUTC[0] = '\0';
}

// ============================================================
// NMEA -> DECIMAL
// ============================================================
//
// A7672S:
//
// Latitude:
//   DDMM.MMMM
//
// Longitude:
//   DDDMM.MMMM
//
// Example:
//
//   2608.1234,N
//       -> 26.13539
//
// ============================================================

static double nmeaToDecimalDegrees(const String &value, const String &hemisphere) {
  String v = value;
  v.trim();

  String h = hemisphere;
  h.trim();
  h.toUpperCase();

  if (v.length() == 0) {
    return NAN;
  }

  // A7672S +CGNSSINFO normally returns coordinates directly in
  // decimal degrees, e.g.:
  //   26.1365509,N
  //   91.7904282,E
  //
  // Accept decimal-degree values directly when they are already
  // within the valid latitude/longitude range for the hemisphere.
  double raw = v.toDouble();

  if (!isfinite(raw)) {
    return NAN;
  }

  // Detect whether the value is already decimal degrees.
  // Longitude may legitimately be 91.7904282, which must NOT be
  // interpreted as NMEA ddmm.mmmm because 91.79 would imply
  // 91 degrees 79 minutes.
  double absRaw = fabs(raw);

  bool looksLikeDecimalDegrees = false;

  if (h == "N" || h == "S") {
    if (absRaw <= 90.0) {
      looksLikeDecimalDegrees = true;
    }
  } else if (h == "E" || h == "W") {
    if (absRaw <= 180.0) {
      looksLikeDecimalDegrees = true;
    }
  }

  if (looksLikeDecimalDegrees) {
    double result = fabs(raw);

    if (h == "S" || h == "W") {
      result = -result;
    }

    if (h == "N" || h == "S") {
      if (result < -90.0 || result > 90.0) {
        return NAN;
      }
    } else if (h == "E" || h == "W") {
      if (result < -180.0 || result > 180.0) {
        return NAN;
      }
    }

    return result;
  }

  // Fallback for traditional NMEA ddmm.mmmm / dddmm.mmmm.
  // Example:
  //   2608.1930,N -> 26.136550
  //   09147.4257,E -> 91.790428
  //
  // The minutes portion must be < 60.
  double degrees = floor(absRaw / 100.0);
  double minutes = absRaw - (degrees * 100.0);

  if (!isfinite(degrees) || !isfinite(minutes)) {
    return NAN;
  }

  if (minutes < 0.0 || minutes >= 60.0) {
    return NAN;
  }

  double result = degrees + (minutes / 60.0);

  if (h == "S" || h == "W") {
    result = -result;
  }

  if (h == "N" || h == "S") {
    if (result < -90.0 || result > 90.0) {
      return NAN;
    }
  } else if (h == "E" || h == "W") {
    if (result < -180.0 || result > 180.0) {
      return NAN;
    }
  }

  return result;
}

// ============================================================
// GPS PARSER
// ============================================================
//
// A76XX CGNSSINFO format:
//
// mode,
// GPS-SVs,
// GLONASS-SVs,
// GALILEO-SVs,
// BEIDOU-SVs,
// latitude,
// N/S,
// longitude,
// E/W,
// date,
// UTC time,
// altitude,
// speed,
// course,
// PDOP,
// HDOP,
// VDOP,
// NoSV
//
// ============================================================

static bool parseGNSS(
  const String &response) {

  // ==========================================================
  // A7672S +CGNSSINFO parser
  //
  // IMPORTANT:
  // The modem may return spaces around fields, for example:
  //
  // +CGNSSINFO: 3, 14, , 05, 00, 26.1365337, N,
  //              91.7904053, E, 220926, 081235.00,
  //              13.8, 2.079, , 6.60, 4.05, 5.21, 05
  //
  // Therefore every comma-separated field is explicitly
  // whitespace-normalized before it is parsed.
  // ==========================================================

  int p = response.indexOf("+CGNSSINFO:");

  if (p < 0) {
    Serial.println("GPS PARSE: +CGNSSINFO NOT FOUND");
    return false;
  }

  int colon = response.indexOf(':', p);

  if (colon < 0) {
    Serial.println("GPS PARSE: COLON NOT FOUND");
    return false;
  }

  // Find the end of the +CGNSSINFO line.  Do not include the
  // following OK/other response lines in the field parser.
  int end = response.indexOf('\n', colon + 1);

  if (end < 0)
    end = response.length();

  String data = response.substring(colon + 1, end);
  data.trim();

  // Remove CR/LF/TAB/space characters at field boundaries and
  // also tolerate spaces accidentally inserted inside tokens.
  String field[18];
  int count = 0;
  int fieldStart = 0;

  for (int i = 0;
       i <= (int)data.length() && count < 18;
       i++) {

    if (i == (int)data.length() || data[i] == ',') {

      String token = data.substring(fieldStart, i);
      token.trim();

      // Remove all ordinary whitespace from the token.
      // This makes values such as " 26.1365337 " and " N "
      // parse identically to "26.1365337" and "N".
      token.replace(" ", "");
      token.replace("\t", "");
      token.replace("\r", "");

      field[count++] = token;
      fieldStart = i + 1;
    }
  }

  Serial.print("GPS PARSE: FIELD COUNT = ");
  Serial.println(count);

  // A valid A7672S position response needs at least fields 0..16.
  // Some firmware versions append field 17 (NoSV), some do not.
  if (count < 17) {
    Serial.println("GPS PARSE: TOO FEW FIELDS");
    return false;
  }

  // ==========================================================
  // Show the position fields before conversion.
  // This makes malformed modem responses immediately visible.
  // ==========================================================

  Serial.print("GPS PARSE: mode=[");
  Serial.print(field[0]);
  Serial.println("]");

  Serial.print("GPS PARSE: GPS-SV=[");
  Serial.print(field[1]);
  Serial.println("]");

  Serial.print("GPS PARSE: LAT=[");
  Serial.print(field[5]);
  Serial.println("]");

  Serial.print("GPS PARSE: NS=[");
  Serial.print(field[6]);
  Serial.println("]");

  Serial.print("GPS PARSE: LON=[");
  Serial.print(field[7]);
  Serial.println("]");

  Serial.print("GPS PARSE: EW=[");
  Serial.print(field[8]);
  Serial.println("]");

  // ==========================================================
  // POSITION FIELDS
  // ==========================================================

  if (field[5].length() == 0 ||
      field[6].length() == 0 ||
      field[7].length() == 0 ||
      field[8].length() == 0) {

    Serial.println("GPS PARSE: LAT/LON FIELD EMPTY");
    return false;
  }

  String ns = field[6];
  String ew = field[8];
  ns.trim();
  ew.trim();
  ns.toUpperCase();
  ew.toUpperCase();

  if (ns.length() == 0 || (ns[0] != 'N' && ns[0] != 'S')) {
    Serial.print("GPS PARSE: INVALID N/S = [");
    Serial.print(field[6]);
    Serial.println("]");
    return false;
  }

  if (ew.length() == 0 || (ew[0] != 'E' && ew[0] != 'W')) {
    Serial.print("GPS PARSE: INVALID E/W = [");
    Serial.print(field[8]);
    Serial.println("]");
    return false;
  }

  // ==========================================================
  // Satellite/mode information.
  // Do not reject a valid coordinate just because one of the
  // constellation counters is empty.
  // ==========================================================

  int mode = field[0].length() ? field[0].toInt() : 0;
  int gpsSV = field[1].length() ? field[1].toInt() : 0;
  int glonassSV = field[2].length() ? field[2].toInt() : 0;
  int galileoSV = field[3].length() ? field[3].toInt() : 0;
  int beidouSV = field[4].length() ? field[4].toInt() : 0;

  int constellationSV =
    gpsSV + glonassSV + galileoSV + beidouSV;

  // A7672S +CGNSSINFO:
  // field[14] = PDOP
  // field[15] = HDOP
  // field[16] = VDOP
  // field[17] = NoSV (when present)
  double pdop = field[14].length() ? field[14].toDouble() : NAN;
  double hdop = field[15].length() ? field[15].toDouble() : NAN;
  double vdop = field[16].length() ? field[16].toDouble() : NAN;

  // Mode is logged for diagnostics but is not used as the sole reason
  // to reject an otherwise valid coordinate.

  Serial.print("GPS PARSE: PDOP = ");
  if (isfinite(pdop)) Serial.println(pdop, 2);
  else Serial.println("N/A");

  Serial.print("GPS PARSE: HDOP = ");
  if (isfinite(hdop)) Serial.println(hdop, 2);
  else Serial.println("N/A");

  Serial.print("GPS PARSE: VDOP = ");
  if (isfinite(vdop)) Serial.println(vdop, 2);
  else Serial.println("N/A");

  Serial.print("GPS PARSE: MODE = ");
  Serial.print(mode);
  Serial.print(" CONSTELLATION SV = ");
  Serial.println(constellationSV);

  // ==========================================================
  // Convert NMEA coordinates to decimal degrees.
  // ==========================================================

  double lat =
    nmeaToDecimalDegrees(field[5], ns);

  double lon =
    nmeaToDecimalDegrees(field[7], ew);

  if (!isfinite(lat) || !isfinite(lon)) {
    Serial.println("GPS PARSE: COORDINATE CONVERSION FAILED");
    return false;
  }

  if (lat < -90.0 || lat > 90.0 ||
      lon < -180.0 || lon > 180.0) {
    Serial.print("GPS PARSE: COORDINATES OUT OF RANGE: ");
    Serial.print(lat, 7);
    Serial.print(", ");
    Serial.println(lon, 7);
    return false;
  }

  // 0,0 is treated as an invalid/no-position response.
  if (lat == 0.0 && lon == 0.0) {
    Serial.println("GPS PARSE: 0,0 POSITION REJECTED");
    return false;
  }

  // Store modem-reported HDOP for the rest of the RMS application.
  gpsHDOP = isfinite(hdop) ? (float)hdop : 0.0f;

  // ==========================================================
  // VALID LIVE GPS POSITION
  // ==========================================================

  liveLatitude = lat;
  liveLongitude = lon;

  altitude =
    field[11].length() ? field[11].toFloat() : 0.0f;

  // Preserve the existing project's knots -> km/h conversion.
  speedKmph =
    field[12].length() ? field[12].toFloat() * 1.852f : 0.0f;

  // CGNSSINFO:
  // 14 = PDOP
  // 15 = HDOP
  // 16 = VDOP
  gpsHDOP =
    field[15].length() ? field[15].toFloat() : 0.0f;

  // If field 17 (NoSV) exists, use it for the displayed satellite
  // count. Otherwise fall back to the GPS-SV count.
  if (count >= 18 && field[17].length() > 0) {
    satellites = field[17].toInt();
  } else {
    satellites = gpsSV;
  }

  strncpy(
    gpsDateUTC,
    field[9].c_str(),
    sizeof(gpsDateUTC) - 1);
  gpsDateUTC[sizeof(gpsDateUTC) - 1] = '\0';

  strncpy(
    gpsTimeUTC,
    field[10].c_str(),
    sizeof(gpsTimeUTC) - 1);
  gpsTimeUTC[sizeof(gpsTimeUTC) - 1] = '\0';

  realGPSActive = true;

  // ==========================================================
  // GPS FILTER
  // ==========================================================

  if (!gpsInitialized) {
    filteredLatitude = lat;
    filteredLongitude = lon;
    gpsInitialized = true;
  } else {
    filteredLatitude =
      GPS_ALPHA * lat +
      (1.0f - GPS_ALPHA) * filteredLatitude;

    filteredLongitude =
      GPS_ALPHA * lon +
      (1.0f - GPS_ALPHA) * filteredLongitude;
  }

  latitude = filteredLatitude;
  longitude = filteredLongitude;

  // ==========================================================
  // FINAL GPS DEBUG
  // ==========================================================

  Serial.println();
  Serial.println("========== A7672S GPS FIX ==========");

  Serial.print("Latitude  : ");
  Serial.println(liveLatitude, 7);

  Serial.print("Longitude : ");
  Serial.println(liveLongitude, 7);

  Serial.print("Altitude  : ");
  Serial.println(altitude, 2);

  Serial.print("Speed     : ");
  Serial.println(speedKmph, 2);

  Serial.print("Satellites: ");
  Serial.println(satellites);

  Serial.print("HDOP      : ");
  Serial.println(gpsHDOP, 2);

  Serial.print("UTC date  : ");
  Serial.println(gpsDateUTC);

  Serial.print("UTC time  : ");
  Serial.println(gpsTimeUTC);

  Serial.println("====================================");

  return true;
}

// ============================================================
// GPS REQUEST
// ============================================================

static void requestGPS() {
  if (atBusy)
    return;

  beginAT(
    "AT+CGNSSINFO",
    "OK",
    GSM_GPS_RESPONSE_TIMEOUT);
}

// ============================================================
// GPS PROCESS
// ============================================================

static void processGPSResult() {

  if (!atDone())
    return;

  Serial.println();
  Serial.println("========== RAW CGNSSINFO RESPONSE ==========");
  Serial.println(gsmATResponse);
  Serial.println("=============================================");

  bool gotFix =
    parseGNSS(
      gsmATResponse);

  if (gotFix) {

    // Every valid 5-minute GPS sample starts a fresh
    // 30-second delay before the LIVE MQTT publish.
    mqttFirstPublishPending = true;
    mqttFirstPublishAt =
      millis() + GSM_FIRST_MQTT_DELAY;

    Serial.println(
      "GPS: VALID LIVE FIX RECEIVED");

    Serial.println(
      "GPS: 30-SECOND MQTT PUBLISH WINDOW STARTS");

  } else {

    Serial.println(
      "GPS: NO VALID POSITION IN THIS SAMPLE");

    Serial.println(
      "GPS: GSM/MQTT CONTINUE");

  }

  clearATResult();
}

// ============================================================
// DAY OF WEEK
// ============================================================

static int dayOfWeek(
  int year,
  int month,
  int day) {
  if (month < 3) {
    month += 12;
    year--;
  }

  int k =
    year % 100;

  int j =
    year / 100;

  int h =
    (day + (13 * (month + 1)) / 5 + k + k / 4 + j / 4 + 5 * j) % 7;

  return (
           (h + 6) % 7)
         + 1;
}

// ============================================================
// WRITE NTP -> RTC
// ============================================================

static bool writeNTPClockToRTC() {
  int p =
    gsmATResponse.indexOf(
      "+CCLK:");

  if (p < 0)
    return false;

  int q1 =
    gsmATResponse.indexOf(
      '"',
      p);

  if (q1 < 0)
    return false;

  int q2 =
    gsmATResponse.indexOf(
      '"',
      q1 + 1);

  if (q2 < 0)
    return false;

  String clock =
    gsmATResponse.substring(
      q1 + 1,
      q2);

  int yy;
  int mo;
  int dd;
  int hh;
  int mm;
  int ss;

  if (
    sscanf(
      clock.c_str(),
      "%d/%d/%d,%d:%d:%d",
      &yy,
      &mo,
      &dd,
      &hh,
      &mm,
      &ss)
    != 6) {
    Serial.println(
      "NTP: CCLK parse failed");

    return false;
  }

  int year =
    2000 + yy;

  int dow =
    dayOfWeek(
      year,
      mo,
      dd);

  rtc.writeProtect(false);
  rtc.halt(false);

  rtc.time(
    Time(
      year,
      mo,
      dd,
      hh,
      mm,
      ss,
      (Time::Day)dow));

  char dateBuf[20];
  char timeBuf[20];

  snprintf(
    dateBuf,
    sizeof(dateBuf),
    "%04d-%02d-%02d",
    year,
    mo,
    dd);

  snprintf(
    timeBuf,
    sizeof(timeBuf),
    "%02d:%02d:%02d",
    hh,
    mm,
    ss);

  rtcDate =
    String(dateBuf);

  rtcTime =
    String(timeBuf);

  ntpTimeValid = true;

  Serial.println();
  Serial.println(
    "========== NTP / RTC SYNC ==========");

  Serial.print(
    "RTC Date: ");

  Serial.println(
    rtcDate);

  Serial.print(
    "RTC Time: ");

  Serial.println(
    rtcTime);

  Serial.println(
    "NTP valid: true");

  Serial.println(
    "====================================");

  return true;
}

// ============================================================
// AT COMMANDS
// ============================================================

static void startModemCheck() {
  beginAT(
    "AT",
    "OK",
    GSM_AT_TIMEOUT);
}

// ============================================================

static void startSIMCheck() {
  beginAT(
    "AT+CPIN?",
    "+CPIN: READY",
    GSM_AT_TIMEOUT);
}

// ============================================================

static void startGNSS() {
  beginAT(
    "AT+CGNSSPWR=1",
    "OK",
    7000);
}

// ============================================================

static void startNetworkCheck() {
  beginAT(
    "AT+CEREG?",
    "OK",
    GSM_NETWORK_TIMEOUT);
}

// ============================================================

static void startSignalCheck() {
  beginAT(
    "AT+CSQ",
    "OK",
    5000);
}

// ============================================================

static void startAPN() {
  char cmd[128];

  snprintf(
    cmd,
    sizeof(cmd),
    "AT+CGDCONT=1,\"IP\",\"%s\"",
    GSM_APN);

  beginAT(
    cmd,
    "OK",
    5000);
}

// ============================================================

static void startAttach() {
  beginAT(
    "AT+CGATT=1",
    "OK",
    GSM_PDP_TIMEOUT);
}

// ============================================================

static void startPDPCheck() {
  beginAT(
    "AT+CGACT?",
    "OK",
    5000);
}

// ============================================================

static void startPDPActivate() {
  beginAT(
    "AT+CGACT=1,1",
    "OK",
    GSM_PDP_TIMEOUT);
}

// ============================================================

static void startIPCheck() {
  beginAT(
    "AT+CGPADDR=1",
    "OK",
    5000);
}

// ============================================================

static void startNTPConfig() {
  /*
     * India UTC +05:30
     *
     * 22 = 22 x 15 minutes
     */
  beginAT(
    "AT+CNTP=\"pool.ntp.org\",22",
    "OK",
    5000);
}

// ============================================================

static void startNTPRequest() {
  beginAT(
    "AT+CNTP",
    "+CNTP: 0",
    GSM_NTP_TIMEOUT);
}

// ============================================================

static void startNTPClock() {
  beginAT(
    "AT+CCLK?",
    "OK",
    5000);
}

// ============================================================

static void startMQTTService() {
  beginAT(
    "AT+CMQTTSTART",
    "+CMQTTSTART: 0",
    GSM_MQTT_TIMEOUT);
}

// ============================================================

static void startMQTTAcquire() {
  char cmd[180];

  snprintf(
    cmd,
    sizeof(cmd),
    "AT+CMQTTACCQ=0,\"%s\",0",
    MQTT_CLIENT_ID);

  beginAT(
    cmd,
    "OK",
    5000);
}

// ============================================================

static void startMQTTConnect() {
  char cmd[320];

  snprintf(
    cmd,
    sizeof(cmd),
    "AT+CMQTTCONNECT=0,\"tcp://%s:%d\",60,1,\"%s\",\"%s\"",
    MQTT_SERVER,
    MQTT_PORT,
    MQTT_USERNAME,
    MQTT_PASSWORD);

  beginAT(
    cmd,
    "+CMQTTCONNECT: 0,0",
    GSM_MQTT_TIMEOUT);
}

// ============================================================

static void startMQTTDisconnect() {
  beginAT(
    "AT+CMQTTDISC=0,60",
    "OK",
    10000);
}

// ============================================================

static void startMQTTRelease() {
  beginAT(
    "AT+CMQTTREL=0",
    "OK",
    10000);
}

// ============================================================

static void startMQTTStop() {
  beginAT(
    "AT+CMQTTSTOP",
    "OK",
    15000);
}

// ============================================================
// FULL CELLULAR RECOVERY
// ============================================================

static void retryGSM(
  unsigned long delayMs =
    GSM_RETRY_INTERVAL) {
  Serial.println();
  Serial.println(
    "====================================");

  Serial.println(
    "A7672S: FULL CELLULAR RECOVERY");

  Serial.println(
    "====================================");

  cellularConnected = false;
  mqttConnected = false;

  mqttServiceStarted = false;
  mqttClientAcquired = false;

  /*
   * A new cellular/MQTT connection must start a fresh LIVE
   * publishing cycle: wait for a valid GPS fix, then 30 seconds.
   */
  mqttFirstPublishPending = true;
  mqttFirstPublishAt = 0;
  gsmLastPublish = 0;

  ntpSyncedThisConnection = false;

  gsmIPAddress = "";
  gsmRSSI = 0;

  gsmRetryAt =
    millis() + delayMs;

  clearATResult();

  gsmState =
    GSM_RETRY_WAIT;
}

// ============================================================
// MQTT-ONLY RECOVERY
// ============================================================

static void requestMQTTRecovery() {
  mqttConnected = false;

  /*
   * MQTT is being rebuilt. The next successful connection must
   * perform the normal GPS-fix + 30-second first LIVE sequence.
   */
  mqttFirstPublishPending = true;
  mqttFirstPublishAt = 0;

  mqttRecoveryRequested = true;

  clearATResult();

  Serial.println();
  Serial.println(
    "A7672S: MQTT RECOVERY REQUESTED");

  /*
     * If MQTT client exists, clean it.
     */
  if (mqttClientAcquired) {
    startMQTTDisconnect();

    gsmState =
      GSM_MQTT_DISCONNECT;

    return;
  }

  /*
     * If MQTT service exists, stop it.
     */
  if (mqttServiceStarted) {
    startMQTTStop();

    gsmState =
      GSM_MQTT_STOP;

    return;
  }

  /*
     * Otherwise simply start it.
     */
  startMQTTService();

  gsmState =
    GSM_MQTT_START;
}

// ============================================================
// INITIALIZATION
// ============================================================

void initGSM() {
  GSM.begin(
    GSM_BAUD,
    SERIAL_8N1,
    16,
    17);

  gsmInitialized = false;

  cellularConnected = false;
  mqttConnected = false;

  mqttServiceStarted = false;
  mqttClientAcquired = false;

  ntpTimeValid = false;
  ntpSyncedThisConnection = false;

  gsmRSSI = 0;
  gsmIPAddress = "";

  mqttFailureCount = 0;
  modemFailureCount = 0;

  gsmNextGPS =
    millis() + 5000UL;

  gsmLastHealthCheck =
    millis();

  mqttFirstPublishPending = true;
  mqttFirstPublishAt = 0;
  gsmLastPublish = 0;

  ntpRetryAt =
    millis();

  clearATResult();

  gsmState =
    GSM_BOOT;

  Serial.println();
  Serial.println(
    "A7672S: GSM + GNSS + MQTT initialized");
}

// ============================================================
// MAIN GSM TASK
// ============================================================

void gsmTask() {
  /*
     * ALWAYS process modem data first.
     */
  pollAT();

  unsigned long now =
    millis();

  // ========================================================
  // BACKGROUND GPS
  // ========================================================
  //
  // GPS ONLY runs when:
  //
  //   GSM connected
  //   MQTT connected
  //   no other AT command is running
  //
  // GPS is NOT required for MQTT.
  //
  // ========================================================

  if (
    gsmInitialized && cellularConnected && mqttConnected && !atBusy && gsmState == GSM_READY && (long)(now - gsmNextGPS) >= 0) {
    requestGPS();

    gsmNextGPS =
      now + GSM_GPS_INTERVAL;

    gsmState =
      GSM_GPS_READ;
  }

  // ========================================================
  // GPS RESPONSE
  // ========================================================

  if (
    gsmState == GSM_GPS_READ) {
    if (atDone()) {
      processGPSResult();

      gsmState =
        GSM_READY;
    }

    return;
  }

  // ========================================================
  // AT COMMAND BUSY
  // ========================================================

  if (atBusy)
    return;

  // ========================================================
  // STATE MACHINE
  // ========================================================

  switch (gsmState) {
      // ====================================================
      // BOOT
      // ====================================================

    case GSM_BOOT:
      {
        startModemCheck();

        gsmState =
          GSM_WAIT_MODEM;

        break;
      }

      // ====================================================
      // MODEM
      // ====================================================

    case GSM_WAIT_MODEM:
      {
        if (!atDone())
          break;

        if (!atOK()) {
          modemFailureCount++;

          Serial.println(
            "A7672S: MODEM NOT RESPONDING");

          if (
            modemFailureCount >= GSM_MODEM_FAILURE_LIMIT) {
            Serial.println(
              "A7672S: repeated modem failure");

            modemFailureCount = 0;
          }

          retryGSM();

          break;
        }

        modemFailureCount = 0;

        gsmInitialized = true;

        clearATResult();

        startSIMCheck();

        gsmState =
          GSM_WAIT_SIM;

        break;
      }

      // ====================================================
      // SIM
      // ====================================================

    case GSM_WAIT_SIM:
      {
        if (!atDone())
          break;

        if (!atOK()) {
          Serial.println(
            "A7672S: SIM NOT READY");

          retryGSM(10000UL);

          break;
        }

        clearATResult();

        /*
             * GNSS is optional.
             */
        startGNSS();

        gsmState =
          GSM_START_GNSS;

        break;
      }

      // ====================================================
      // GNSS START
      // ====================================================

    case GSM_START_GNSS:
      {
        if (!atDone())
          break;

        if (atOK()) {
          Serial.println(
            "A7672S: GNSS STARTED");
        } else {
          /*
                 * VERY IMPORTANT:
                 *
                 * GNSS failure does NOT stop GSM.
                 */
          Serial.println(
            "A7672S: GNSS START FAILED");

          Serial.println(
            "A7672S: GSM/MQTT CONTINUE");
        }

        clearATResult();

        startNetworkCheck();

        gsmState =
          GSM_NETWORK_CHECK;

        break;
      }

      // ====================================================
      // NETWORK
      // ====================================================

    case GSM_NETWORK_CHECK:
      {
        if (!atDone())
          break;

        if (
          !atOK() || !networkRegistered()) {
          Serial.println(
            "A7672S: NETWORK NOT REGISTERED");

          cellularConnected = false;
          mqttConnected = false;

          retryGSM(
            GSM_NETWORK_RETRY_INTERVAL);

          break;
        }

        /*
             * Network is registered.
             *
             * Read signal but do not fail if CSQ is unavailable.
             */
        clearATResult();

        startSignalCheck();

        gsmState =
          GSM_SET_APN;

        break;
      }

      // ====================================================
      // SIGNAL -> APN
      // ====================================================

    case GSM_SET_APN:
      {
        if (!atDone())
          break;

        parseRSSI();

        clearATResult();

        startAPN();

        gsmState =
          GSM_ATTACH;

        break;
      }

      // ====================================================
      // ATTACH
      // ====================================================

    case GSM_ATTACH:
      {
        if (!atDone())
          break;

        if (!atOK()) {
          Serial.println(
            "A7672S: CGATT FAILED");

          retryGSM();

          break;
        }

        /*
             * IMPORTANT:
             *
             * CGATT=1 succeeded.
             *
             * Do NOT call CGATT again based on CGACT?.
             *
             * Now check PDP contexts.
             */
        Serial.println(
          "A7672S: PACKET ATTACHED");

        clearATResult();

        startPDPCheck();

        gsmState =
          GSM_PDP_CHECK;

        break;
      }

      // ====================================================
      // PDP CHECK
      // ====================================================

    case GSM_PDP_CHECK:
      {
        if (!atDone())
          break;

        if (!atOK()) {
          Serial.println(
            "A7672S: CGACT? FAILED");

          retryGSM();

          break;
        }

        /*
             * Your exact case:
             *
             * +CGACT: 1,1
             * +CGACT: 8,1
             *
             * CID 1 is active.
             *
             * CID 8 is simply another active context.
             *
             * Therefore:
             *
             *   pdpActive() == TRUE
             *
             * and we go directly to CGPADDR.
             */
        if (pdpActive()) {
          Serial.println(
            "A7672S: CID 1 PDP ACTIVE");

          clearATResult();

          startIPCheck();

          gsmState =
            GSM_IP_CHECK;
        } else {
          Serial.println(
            "A7672S: CID 1 PDP NOT ACTIVE");

          clearATResult();

          startPDPActivate();

          gsmState =
            GSM_PDP_ACTIVATE;
        }

        break;
      }

      // ====================================================
      // PDP ACTIVATE
      // ====================================================

    case GSM_PDP_ACTIVATE:
      {
        if (!atDone())
          break;

        if (!atOK()) {
          Serial.println(
            "A7672S: PDP ACTIVATION FAILED");

          retryGSM();

          break;
        }

        Serial.println(
          "A7672S: PDP ACTIVATED");

        clearATResult();

        startPDPCheck();

        gsmState =
          GSM_PDP_CHECK;

        break;
      }

      // ====================================================
      // IP
      // ====================================================

    case GSM_IP_CHECK:
      {
        if (!atDone())
          break;

        if (
          !atOK() || !parseIPAddress()) {
          Serial.println(
            "A7672S: CID 1 HAS NO IP");

          cellularConnected = false;
          mqttConnected = false;

          retryGSM();

          break;
        }

        cellularConnected = true;

        Serial.println(
          "A7672S: CELLULAR INTERNET READY");

        ntpSyncedThisConnection =
          false;

        clearATResult();

        /*
             * NTP is optional.
             */
        startNTPConfig();

        gsmState =
          GSM_NTP_CONFIG;

        break;
      }

      // ====================================================
      // NTP CONFIG
      // ====================================================

    case GSM_NTP_CONFIG:
      {
        if (!atDone())
          break;

        if (!atOK()) {
          Serial.println(
            "NTP: CONFIG FAILED");

          Serial.println(
            "NTP: MQTT WILL CONTINUE");

          clearATResult();

          if (ntpOnlyRecovery) {
            ntpOnlyRecovery = false;

            gsmState =
              GSM_READY;
          } else {
            startMQTTService();

            gsmState =
              GSM_MQTT_START;
          }

          break;
        }

        clearATResult();

        startNTPRequest();

        gsmState =
          GSM_NTP_REQUEST;

        break;
      }

      // ====================================================
      // NTP REQUEST
      // ====================================================

    case GSM_NTP_REQUEST:
      {
        if (!atDone())
          break;

        if (!atOK()) {
          Serial.println(
            "NTP: SYNC FAILED");

          Serial.println(
            "NTP: MQTT WILL CONTINUE");

          ntpOnlyRecovery = false;

          clearATResult();

          startMQTTService();

          gsmState =
            GSM_MQTT_START;

          break;
        }

        clearATResult();

        startNTPClock();

        gsmState =
          GSM_NTP_CLOCK;

        break;
      }

      // ====================================================
      // NTP CLOCK
      // ====================================================

    case GSM_NTP_CLOCK:
      {
        if (!atDone())
          break;

        if (
          atOK() && writeNTPClockToRTC()) {
          ntpSyncedThisConnection =
            true;
        } else {
          Serial.println(
            "NTP: RTC UPDATE FAILED");
        }

        clearATResult();

        /*
             * If MQTT was already connected,
             * do NOT restart MQTT.
             */
        if (ntpOnlyRecovery) {
          ntpOnlyRecovery = false;

          gsmState =
            GSM_READY;
        } else {
          startMQTTService();

          gsmState =
            GSM_MQTT_START;
        }

        break;
      }

      // ====================================================
      // MQTT START
      // ====================================================

    case GSM_MQTT_START:
      {
        if (!atDone())
          break;

        /*
         * A7672S MQTT service behavior:
         *
         *   AT+CMQTTSTART
         *   OK
         *   +CMQTTSTART: 0
         *
         * If the MQTT service is ALREADY running, the modem can
         * return a plain ERROR. This commonly happens after a
         * cellular recovery because the ESP32 resets its software
         * flags while the modem keeps the MQTT service alive.
         *
         * IMPORTANT:
         * Do NOT repeatedly send AT+CMQTTSTART on a plain ERROR.
         * Treat a plain ERROR here as "service may already be
         * running" and let CMQTTACCQ/CONNECT verify the stack.
         */

        bool startConfirmed =
          gsmATResponse.indexOf(
            "+CMQTTSTART: 0")
          >= 0;

        bool alreadyRunning =
          !startConfirmed &&
          atFailed &&
          gsmATResponse.indexOf(
            "ERROR")
          >= 0;

        if (!atOK() &&
            !startConfirmed &&
            !alreadyRunning) {

          Serial.println(
            "A7672S: MQTT SERVICE START FAILED");

          Serial.print(
            "A7672S: MQTT START RESPONSE: ");

          Serial.println(
            gsmATResponse);

          mqttServiceStarted =
            false;

          /*
           * Do one clean MQTT-stack rebuild instead of hammering
           * AT+CMQTTSTART forever.
           */
          clearATResult();

          startMQTTStop();

          gsmState =
            GSM_MQTT_STOP;

          break;
        }

        Serial.print("MQTT START RESPONSE: ");
        Serial.println(gsmATResponse);

        if (startConfirmed) {
          Serial.println(
            "A7672S: MQTT SERVICE STARTED");
        } else if (alreadyRunning) {
          Serial.println(
            "A7672S: MQTT SERVICE ALREADY RUNNING");
        }

        mqttServiceStarted =
          true;

        clearATResult();

        startMQTTAcquire();

        gsmState =
          GSM_MQTT_ACQUIRE;

        break;
      }

      // ====================================================
      // MQTT ACQUIRE
      // ====================================================

    case GSM_MQTT_ACQUIRE:
      {
        if (!atDone())
          break;

        Serial.print("MQTT ACCQ RESPONSE: ");
        Serial.println(gsmATResponse);

        if (!atOK()) {
          Serial.println(
            "A7672S: MQTT ACCQ FAILED");

          Serial.print(
            "A7672S: MQTT ACCQ RESPONSE: ");

          Serial.println(
            gsmATResponse);

          /*
           * The client may already exist after a recovery.
           * In that case ACCQ can return ERROR, while CONNECT
           * can still use the existing client.
           */
          mqttClientAcquired =
            true;
        } else {
          mqttClientAcquired =
            true;
        }

        clearATResult();

        startMQTTConnect();

        gsmState =
          GSM_MQTT_CONNECT;

        break;
      }

      // ====================================================
      // MQTT CONNECT
      // ====================================================

    case GSM_MQTT_CONNECT:
      {
        if (!atDone())
          break;

        Serial.print("MQTT CONNECT RESPONSE: ");
        Serial.println(gsmATResponse);

        if (
          !atOK() || gsmATResponse.indexOf("+CMQTTCONNECT: 0,0") < 0) {
          Serial.println(
            "A7672S: MQTT CONNECT FAILED");

          mqttConnected = false;

          mqttFailureCount++;

          /*
                 * First failures:
                 * keep cellular connection.
                 */
          if (
            mqttFailureCount < GSM_MQTT_FAILURE_LIMIT) {
            Serial.println(
              "A7672S: RETRYING MQTT");

            clearATResult();

            startMQTTConnect();

            gsmState =
              GSM_MQTT_CONNECT;
          } else {
            /*
                     * Rebuild MQTT stack.
                     */
            Serial.println(
              "A7672S: REBUILDING MQTT");

            mqttFailureCount = 0;

            clearATResult();

            if (
              mqttClientAcquired) {
              startMQTTDisconnect();

              gsmState =
                GSM_MQTT_DISCONNECT;
            } else {
              startMQTTStop();

              gsmState =
                GSM_MQTT_STOP;
            }
          }

          break;
        }

        mqttConnected = true;

        cellularConnected = true;

        mqttFailureCount = 0;

        mqttRecoveryRequested = false;

        // ----------------------------------------------------
        // MQTT STARTUP PUBLISH TIMER
        // ----------------------------------------------------
        // MQTT is connected now.
        // GPS will continue running independently.
        // We wait until a valid GPS fix is available,
        // then wait another 30 seconds before the first LIVE.
        // ----------------------------------------------------

        mqttFirstPublishPending = true;
        mqttFirstPublishAt = 0;
        gsmLastPublish = 0;

        Serial.println();
        Serial.println(
          "====================================");

        Serial.println(
          "A7672S: MQTT CONNECTED");

        Serial.println(
          "A7672S: MQTT READY");

        Serial.println(
          "A7672S: Waiting for GPS FIX");

        Serial.println(
          "A7672S: First LIVE will be sent 30 seconds after GPS FIX");

        Serial.println(
          "====================================");

        clearATResult();

        gsmNextGPS = millis();

        gsmLastHealthCheck = millis();

        gsmState = GSM_READY;

        break;
      }

      // ====================================================
      // READY
      // ====================================================

    case GSM_READY:
      {
        /*
             * CELLULAR LOST
             */
        if (!cellularConnected) {
          retryGSM();

          break;
        }

        /*
             * MQTT lost but cellular is alive.
             */
        if (
          !mqttConnected && !atBusy) {
          requestMQTTRecovery();

          break;
        }

        // ====================================================
        // LIVE GPS + MQTT
        // ====================================================
        // GPS is requested once every 5 minutes.
        // A valid GPS sample starts a 30-second delay, then the
        // latest LIVE payload is published through MQTT.
        // ====================================================

        // ----------------------------------------------------
        // NON-BLOCKING MQTT PUBLISH
        // ----------------------------------------------------
        // Start only once; mqttPublishTask() advances one small
        // modem transaction per loop. This prevents a modem that
        // stops responding from freezing the ESP32.
        if (
          mqttConnected &&
          cellularConnected &&
          !mqttPublishBusy &&
          mqttFirstPublishPending &&
          realGPSActive &&
          mqttFirstPublishAt != 0 &&
          (long)(millis() - mqttFirstPublishAt) >= 0) {

          String payload = buildLivePayload();
          startMQTTPublishAsync(TOPIC_STATUS, payload.c_str());
        }

        mqttPublishTask();

        // Do not start a health transaction while MQTT publish is active.
        if (mqttPublishBusy)
          break;

        /*
             * Periodic health check.
             */
        if (
          (long)(now - gsmLastHealthCheck) >= GSM_HEALTH_INTERVAL) {
          gsmLastHealthCheck =
            now;

          clearATResult();

          startNetworkCheck();

          gsmState =
            GSM_HEALTH_NETWORK;

          break;
        }

        break;
      }

      // ====================================================
      // HEALTH NETWORK
      // ====================================================

    case GSM_HEALTH_NETWORK:
      {
        if (!atDone())
          break;

        if (
          !atOK() || !networkRegistered()) {
          Serial.println(
            "A7672S: NETWORK LOST");

          cellularConnected =
            false;

          mqttConnected =
            false;

          retryGSM();

          break;
        }

        clearATResult();

        startPDPCheck();

        /*
             * IMPORTANT:
             *
             * Health check should verify PDP too.
             */
        gsmState =
          GSM_HEALTH_PDP;

        break;
      }

      // ====================================================
      // HEALTH IP/PDP
      // ====================================================
    case GSM_HEALTH_PDP:
      {
        if (!atDone())
          break;

        if (!atOK()) {
          retryGSM();
          break;
        }

        if (!pdpActive()) {
          Serial.println(
            "A7672S: CID 1 PDP LOST");

          cellularConnected = false;
          mqttConnected = false;

          retryGSM();
          break;
        }

        clearATResult();

        startIPCheck();

        gsmState = GSM_HEALTH_IP;

        break;
      }

    case GSM_HEALTH_IP:
      {
        if (!atDone())
          break;

        if (!atOK() || !parseIPAddress()) {
          Serial.println(
            "A7672S: CELLULAR IP LOST");

          cellularConnected = false;
          mqttConnected = false;

          retryGSM();

          break;
        }

        cellularConnected = true;

        clearATResult();

        if (!ntpSyncedThisConnection && (long)(now - ntpRetryAt) >= 0) {
          ntpOnlyRecovery = true;

          ntpRetryAt =
            now + GSM_NTP_RETRY_INTERVAL;

          startNTPConfig();

          gsmState =
            GSM_NTP_CONFIG;
        } else {
          gsmState =
            GSM_READY;
        }

        break;
      }

      // ====================================================
      // GPS
      // ====================================================

    case GSM_GPS_READ:
      {
        /*
             * Normally consumed before switch().
             */
        break;
      }

      // ====================================================
      // MQTT DISCONNECT
      // ====================================================

    case GSM_MQTT_DISCONNECT:
      {
        if (!atDone())
          break;

        mqttConnected = false;
        mqttClientAcquired = false;

        clearATResult();

        startMQTTRelease();

        gsmState =
          GSM_MQTT_RELEASE;

        break;
      }

      // ====================================================
      // MQTT RELEASE
      // ====================================================

    case GSM_MQTT_RELEASE:
      {
        if (!atDone())
          break;

        mqttClientAcquired =
          false;

        clearATResult();

        startMQTTStop();

        gsmState =
          GSM_MQTT_STOP;

        break;
      }

      // ====================================================
      // MQTT STOP
      // ====================================================

    case GSM_MQTT_STOP:
      {
        if (!atDone())
          break;

        mqttServiceStarted =
          false;

        clearATResult();

        /*
             * If cellular is still alive,
             * restart MQTT only.
             */
        if (cellularConnected) {
          startMQTTService();

          gsmState =
            GSM_MQTT_START;
        } else {
          retryGSM();
        }

        break;
      }

      // ====================================================
      // RETRY
      // ====================================================

    case GSM_RETRY_WAIT:
      {
        if (
          (long)(now - gsmRetryAt) >= 0) {
          clearATResult();

          gsmInitialized =
            false;

          startModemCheck();

          gsmState =
            GSM_WAIT_MODEM;
        }

        break;
      }

      // ====================================================
      // DEFAULT
      // ====================================================

    default:
      {
        clearATResult();

        gsmState =
          GSM_BOOT;

        break;
      }
  }
}

// ============================================================
// NON-BLOCKING MQTT PUBLISH
// ============================================================
// Each call performs only a small amount of work. There are NO
// timeout while-loops here. If the A7672S stops responding, the
// current stage expires and the normal GSM recovery state machine
// takes over.
// ============================================================

static void mqttPublishFail(const char *reason)
{
  Serial.println();
  Serial.print("MQTT ASYNC ERROR: ");
  Serial.println(reason);

  mqttPublishBusy = false;
  mqttPublishStage = MQTT_PUB_IDLE;
  mqttPublishDeadline = 0;
  mqttPublishResponse = "";
  mqttPublishTopic = "";
  mqttPublishPayload = "";

  mqttFailureCount++;
  mqttConnected = false;

  if (mqttFailureCount >= GSM_MQTT_FAILURE_LIMIT) {
    mqttFailureCount = 0;
    mqttRecoveryRequested = true;
    Serial.println("MQTT ASYNC: recovery requested");
  }
}

static bool startMQTTPublishAsync(const char *topic, const char *payload)
{
  if (mqttPublishBusy || atBusy || !mqttConnected || !cellularConnected)
    return false;

  if (!topic || !payload)
    return false;

  mqttPublishTopic = topic;
  mqttPublishPayload = payload;
  mqttPublishResponse = "";

  char cmd[128];
  snprintf(cmd, sizeof(cmd), "AT+CMQTTTOPIC=0,%u",
           (unsigned)mqttPublishTopic.length());

  clearGSMBuffer();
  GSM.println(cmd);

  mqttPublishBusy = true;
  mqttPublishStage = MQTT_PUB_WAIT_TOPIC_PROMPT;
  mqttPublishDeadline = millis() + 5000UL;

  Serial.println("MQTT ASYNC: topic command started");
  return true;
}

static bool responseHasError(const String &response)
{
  return response.indexOf("+CME ERROR") >= 0 ||
         response.indexOf("+CMS ERROR") >= 0 ||
         response.indexOf("\r\nERROR\r\n") >= 0 ||
         response.indexOf("\nERROR\r\n") >= 0 ||
         response.indexOf("ERROR") >= 0;
}

static void mqttPublishTask()
{
  if (!mqttPublishBusy)
    return;

  unsigned long now = millis();

  // Consume only the data belonging to this publish transaction.
  while (GSM.available()) {
    char c = (char)GSM.read();
    Serial.write(c);

    if (mqttPublishResponse.length() < 2200)
      mqttPublishResponse += c;
  }

  switch (mqttPublishStage) {

    case MQTT_PUB_WAIT_TOPIC_PROMPT:
      if (mqttPublishResponse.indexOf(">") >= 0) {
        GSM.print(mqttPublishTopic);
        GSM.write('\r');
        mqttPublishResponse = "";
        mqttPublishStage = MQTT_PUB_WAIT_TOPIC_OK;
        mqttPublishDeadline = now + 5000UL;
        return;
      }
      if (responseHasError(mqttPublishResponse)) {
        mqttPublishFail("topic prompt rejected");
        return;
      }
      break;

    case MQTT_PUB_WAIT_TOPIC_OK:
      if (responseHasError(mqttPublishResponse)) {
        mqttPublishFail("topic data rejected");
        return;
      }
      if (mqttPublishResponse.indexOf("OK") >= 0) {
        char cmd[128];
        snprintf(cmd, sizeof(cmd), "AT+CMQTTPAYLOAD=0,%u",
                 (unsigned)mqttPublishPayload.length());
        clearGSMBuffer();
        GSM.println(cmd);
        mqttPublishResponse = "";
        mqttPublishStage = MQTT_PUB_WAIT_PAYLOAD_PROMPT;
        mqttPublishDeadline = now + 5000UL;
        return;
      }
      break;

    case MQTT_PUB_WAIT_PAYLOAD_PROMPT:
      if (mqttPublishResponse.indexOf(">") >= 0) {
        GSM.print(mqttPublishPayload);
        GSM.write('\r');
        mqttPublishResponse = "";
        mqttPublishStage = MQTT_PUB_WAIT_PAYLOAD_OK;
        mqttPublishDeadline = now + 5000UL;
        return;
      }
      if (responseHasError(mqttPublishResponse)) {
        mqttPublishFail("payload prompt rejected");
        return;
      }
      break;

    case MQTT_PUB_WAIT_PAYLOAD_OK:
      if (responseHasError(mqttPublishResponse)) {
        mqttPublishFail("payload data rejected");
        return;
      }
      if (mqttPublishResponse.indexOf("OK") >= 0) {
        clearGSMBuffer();
        GSM.println("AT+CMQTTPUB=0,1,60");
        mqttPublishResponse = "";
        mqttPublishStage = MQTT_PUB_WAIT_RESULT;
        mqttPublishDeadline = now + GSM_PUBLISH_TIMEOUT;
        return;
      }
      break;

    case MQTT_PUB_WAIT_RESULT:
      if (mqttPublishResponse.indexOf("+CMQTTPUB: 0,0") >= 0) {
        Serial.println("MQTT ASYNC: SERVER PUBLISH SUCCESS");

        mqttPublishBusy = false;
        mqttPublishStage = MQTT_PUB_IDLE;
        mqttPublishDeadline = 0;
        mqttPublishResponse = "";
        mqttPublishTopic = "";
        mqttPublishPayload = "";

        mqttConnected = true;
        cellularConnected = true;
        mqttFailureCount = 0;
        mqttFirstPublishPending = false;
        mqttFirstPublishAt = 0;
        gsmLastPublish = millis();
        return;
      }

      if (responseHasError(mqttPublishResponse)) {
        mqttPublishFail("publish command error");
        return;
      }
      break;

    default:
      mqttPublishFail("invalid publish state");
      return;
  }

  if ((long)(now - mqttPublishDeadline) >= 0) {
    mqttPublishFail("modem response timeout");
  }
}

// Compatibility API. It now only starts the asynchronous transaction;
// completion is handled by mqttPublishTask().
bool gsmMQTTPublish(const char *topic, const char *payload)
{
  return startMQTTPublishAsync(topic, payload);
}

// ============================================================
// COMPATIBILITY API
// ============================================================

bool gsmMQTTReconnect() {
  mqttConnected = false;

  if (
    cellularConnected && !atBusy) {
    requestMQTTRecovery();

    return false;
  }

  retryGSM(0);

  return false;
}

// ============================================================

bool gsmRecoverConnection() {
  mqttConnected = false;
  cellularConnected = false;

  mqttServiceStarted = false;
  mqttClientAcquired = false;

  ntpSyncedThisConnection =
    false;

  clearATResult();

  gsmState =
    GSM_BOOT;

  return false;
}

// ============================================================

void checkCellular() {
  gsmTask();
}

// ============================================================

bool gsmInternetOFF() {
  return !cellularConnected;
}

// ============================================================

bool gsmInternetON() {
  return cellularConnected;
}

// ============================================================

bool gsmInternetReset() {
  mqttConnected = false;
  cellularConnected = false;

  mqttServiceStarted = false;
  mqttClientAcquired = false;

  ntpSyncedThisConnection =
    false;

  clearATResult();

  gsmState =
    GSM_BOOT;

  return true;
}

// ============================================================

bool gsmMQTTStart() {
  return mqttServiceStarted;
}

// ============================================================

bool gsmMQTTAcquire() {
  return mqttClientAcquired;
}

// ============================================================

bool gsmMQTTConnect() {
  return mqttConnected;
}

// ============================================================

bool gsmMQTTEnsureConnected() {
  if (mqttConnected)
    return true;

  /*
     * Non-blocking recovery.
     */
  if (
    cellularConnected && !atBusy) {
    requestMQTTRecovery();
  }

  return false;
}

// ============================================================
// GPS PAYLOAD
// ============================================================

void addGPSData(
  JsonDocument &doc) {
  /*
     * GPS is independent from MQTT.
     */

  doc["gps_fix"] =
    realGPSActive;

  if (realGPSActive) {
    doc["live_latitude"] =
      liveLatitude;

    doc["live_longitude"] =
      liveLongitude;

    doc["altitude"] =
      altitude;

    doc["speed"] =
      speedKmph;

    doc["satellites"] =
      satellites;

    if (
      gpsHDOP > 0.0f) {
      doc["hdop"] =
        gpsHDOP;
    } else {
      doc["hdop"] =
        nullptr;
    }
  } else {
    /*
         * No GPS fix yet.
         */
    doc["live_latitude"] = 0;
    doc["live_longitude"] = 0;

    doc["altitude"] = 0;
    doc["speed"] = 0;

    doc["satellites"] = 0;

    doc["hdop"] =
      nullptr;
  }
}

// ============================================================
// GPS COMPATIBILITY API
// ============================================================

void initGPS() {
  resetGPSValues();

  Serial.println(
    "GPS: A7672S GNSS interface ready");
}

// ============================================================

void updateGPS() {
  /*
     * GPS is handled by gsmTask().
     */
}

#endif